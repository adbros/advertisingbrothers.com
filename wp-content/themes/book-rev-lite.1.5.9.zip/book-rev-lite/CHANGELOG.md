

### 1.5.4 - 25/01/2015

 Changes: 


 * improved description


### 1.5.4 - 25/01/2015

 Changes: 


 * Update style.css
 * Fixed #5, Fixed #6, plus other modifications

Fixed #5, Fixed #6, Fixed overall minor design flaws, Made general
design improvements (added design for: tables, tags, link pages, ordered
lists, definition lists, address).
 * Merge pull request #7 from vncatalin/development

Fixed #5, Fixed #6, plus other modifications
 * Update style.css
 * Fixed: #8 #9 #10 #11

Fixed: #8 #9 #10 #11
 * Update style.css
 * Merge branch 'development' of https://github.com/vncatalin/bookrev-lite into vncatalin-development

Conflicts:
	style.css
r
 * Merge branch 'vncatalin-development' into development
 * Update style.css
 * Update style.css
 * Fixed #9

Fixed #9 - Slider responsive content display issue.
 * Merge pull request #13 from vncatalin/development

Fixed #9
 * Update style.css


### 1.5.4 - 29/12/2014

 Changes: 


 * Fixed wp review, recreate book_rev_lite_numeric_pagination function, delete function book_rev_lite_doWPQ
 * Changed function for categories, and post thumbnail
 * added post navigation, forum, documentation, ad upgrade links, upsell in customizer, default widgets in sidebar
 * Added default bottom ligo and default footer widgets


### 1.5 - 25/11/2014

 Changes: 


 * wp.org fixes and fixed fatall error from wp product review
 * fixed wp title and tgm plugin error
 * Added pot file
 * replaced hardcoded search
 * Fixed checking for wp product review plugin
 * Fixed part of wp.org review, translations, and other fixes
 * Changed fonts selection from customizer, and enqueue


### 1.0 - 21/10/2014

 Changes: 


 * First version of theme
 * Responsive fixes
 * Small responsive fixes
