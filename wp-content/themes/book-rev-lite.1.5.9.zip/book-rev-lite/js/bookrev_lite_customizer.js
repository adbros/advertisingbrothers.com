jQuery(document).ready(function() {

	jQuery('.wp-full-overlay-sidebar-content').prepend('<a style="margin-top: 5px;margin-bottom: 5px; margin-left: 93px;"href="https://themeisle.com/bookrev-lite-documentation" class="button" target="_blank">Documentation</a>');
    jQuery('.wp-full-overlay-sidebar-content').prepend('<a style="margin-top: 5px;margin-bottom: 5px; margin-left: 87px;"href="https://themeisle.com/themes/bookrev/" class="button" target="_blank">View PRO version</a>');

});
