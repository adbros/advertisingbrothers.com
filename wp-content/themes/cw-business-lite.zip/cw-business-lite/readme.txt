=== CW Business Lite ===
Contributors:		themeisle
Tags:				 white, yellow, light, black, dark, one-column, two-columns, right-sidebar, custom-menu, featured-images, post-formats, sticky-post, translation-ready, responsive-layout, custom-colors, editor-style, full-width-template, theme-options, threaded-comments
Requires at least:	3.3.0
Tested up to:		4.0
CW Business
== Description ==
Clean and modern free business theme, built with responsive design in mind using latest css/html techniques, CW Business let you easily build a responsive wordpress site for your business.

= License =
CW Business Lite WordPress theme, Copyright (C) 2014 ThemeIsle.com
CW Business Lite WordPress theme is licensed under the GPL3.

Unless otherwise specified, all the theme files, scripts and images are licensed under GNU General Public Licemse.
The exceptions to this license are as follows:

jquery.carouFredsel.js
License: Distributed under the terms of The MIT License (MIT)
Copyright: Copyright (c) 2013 Fred Heusschen

Roboto font
License: Distributed under the terms of Apache License ( http://www.apache.org/licenses/LICENSE-2.0 )
Copyright: Christian Robertson