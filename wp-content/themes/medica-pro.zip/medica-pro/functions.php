<?php

/**
 *	Require Once
 */
require_once ( 'includes/custom-functions.php' ); // Custom Functions
require_once ( 'includes/custom-widgets.php' ); // Custom Widgets
require_once ( 'includes/metaboxes/example-functions.php' ); // Example Functions
require_once ( 'includes/customizer.php' ); // Customizer

/**
 *  Content Width
 */
if ( ! isset( $content_width ) ) $content_width = 634;

/**
 *	WP Enqueue Style Medica
 */
function wp_enqueue_style_medica() {

    wp_enqueue_style( 'style', get_stylesheet_uri(), array(), '1.3' );
    wp_enqueue_style( 'font-family-raleway', 'http://fonts.googleapis.com/css?family=Raleway:400,100,200,300,500,600,700,800,900', array(), '1.0' );
    wp_enqueue_style( 'font-family-roboto', 'http://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,900italic,900,700italic,700,500italic,500', array(), '1.0' );
    wp_enqueue_style( 'fancybox', get_template_directory_uri() . '/css/jquery.fancybox.css', array(), '1.0' );
    if ( is_singular() ) wp_enqueue_script( "comment-reply" );

    if ( is_rtl() ) {
        wp_enqueue_style( 'rtl', get_template_directory_uri() . '/css/rtl.css', array(), '1.0' );
    }

}
add_action( 'wp_enqueue_scripts', 'wp_enqueue_style_medica' );

/**
 *	WP Enqueue Scripts Medica
 */
function wp_enqueue_scripts_medica() {
    wp_enqueue_script( 'jquery');
    wp_enqueue_script( 'carouFredSel', get_template_directory_uri() . '/js/jquery.carouFredSel-6.2.1-packed.js', array( 'jquery' ), '6.2.1', true );
    wp_enqueue_script( 'fancybox', get_template_directory_uri() . '/js/jquery.fancybox.js', array( 'jquery' ), '1.0', true );
    wp_enqueue_script( 'masonry', get_template_directory_uri() . '/js/jquery.masonry.js', array( 'jquery' ), '1.0', true );
    wp_enqueue_script( 'scripts', get_template_directory_uri() . '/js/scripts.js', array( 'jquery' ), '1.0', true );
}
add_action( 'wp_enqueue_scripts', 'wp_enqueue_scripts_medica' );

/**
 *	Header Navigation
 */
function header_navigation() {

	$locations = array(
		'header-navigation' => __( 'This menu will appear in header.', 'ti' ),
	);
	register_nav_menus( $locations );

}
add_action( 'init', 'header_navigation' );

/**
 *  Footer Navigation
 */
function footer_navigation() {

    $locations = array(
        'footer-navigation' => __( 'This menu will appear in footer.', 'ti' ),
    );
    register_nav_menus( $locations );

}
add_action( 'init', 'footer_navigation' );

/**
 *	Add Theme Support
 */
add_theme_support( 'post-thumbnails' ); // Post Thumbnails
add_theme_support( 'automatic-feed-links' ); // Automatic Feed Links

/**
 *  General Sidebar
 */
function general_sidebar() {

    $args = array(
        'id'            => 'general-sidebar',
        'name'          => __( 'General Sidebar', 'ti' ),
        'description'   => __( 'Use this sidebar to display widgets in your website, including posts and pages.', 'ti' ),
        'before_title'  => '<div class="title-widget">',
        'after_title'   => '</div>',
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
    );
    register_sidebar( $args );

}
add_action( 'widgets_init', 'general_sidebar' );

/**
 *  Custom Post Type: Testimonials
 */
function testimonials() {

    $labels = array(
        'name'                => _x( 'Testimonials', 'Post Type General Name', 'ti' ),
        'singular_name'       => _x( 'Testimonial', 'Post Type Singular Name', 'ti' ),
        'menu_name'           => __( 'Testimonials', 'ti' ),
        'parent_item_colon'   => __( 'Parent Testimonial:', 'ti' ),
        'all_items'           => __( 'All Testimonials', 'ti' ),
        'view_item'           => __( 'View Testimonial', 'ti' ),
        'add_new_item'        => __( 'Add New Testimonial', 'ti' ),
        'add_new'             => __( 'Add New Testimonial', 'ti' ),
        'edit_item'           => __( 'Edit Testimonial', 'ti' ),
        'update_item'         => __( 'Update Testimonial', 'ti' ),
        'search_items'        => __( 'Search Testimonial', 'ti' ),
        'not_found'           => __( 'Not found Testimonial', 'ti' ),
        'not_found_in_trash'  => __( 'Not found Testimonial in Trash', 'ti' ),
    );
    $args = array(
        'label'               => __( 'testimonials', 'ti' ),
        'description'         => __( 'Description for testimonials.', 'ti' ),
        'labels'              => $labels,
        'supports'            => array( 'title', 'editor', 'custom-fields', ),
        'taxonomies'          => array(),
        'hierarchical'        => false,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'show_in_nav_menus'   => true,
        'show_in_admin_bar'   => true,
        'menu_position'       => 5,
        'menu_icon'           => 'dashicons-admin-comments',
        'can_export'          => true,
        'has_archive'         => true,
        'exclude_from_search' => false,
        'publicly_queryable'  => true,
        'capability_type'     => 'page',
    );
    register_post_type( 'testimonials', $args );

}
add_action( 'init', 'testimonials', 0 );

/**
 *  Custom POst Type: Doctors
 */
function doctors() {

    $labels = array(
        'name'                => _x( 'Doctors', 'Post Type General Name', 'ti' ),
        'singular_name'       => _x( 'Doctor', 'Post Type Singular Name', 'ti' ),
        'menu_name'           => __( 'Doctors', 'ti' ),
        'parent_item_colon'   => __( 'Parent Doctor:', 'ti' ),
        'all_items'           => __( 'All Doctors', 'ti' ),
        'view_item'           => __( 'View Doctor', 'ti' ),
        'add_new_item'        => __( 'Add New Doctor', 'ti' ),
        'add_new'             => __( 'Add New Doctor', 'ti' ),
        'edit_item'           => __( 'Edit Doctor', 'ti' ),
        'update_item'         => __( 'Update Doctor', 'ti' ),
        'search_items'        => __( 'Search Doctor', 'ti' ),
        'not_found'           => __( 'Not found Doctor', 'ti' ),
        'not_found_in_trash'  => __( 'Not found Doctor in Trash', 'ti' ),
    );
    $args = array(
        'label'               => __( 'doctors', 'ti' ),
        'description'         => __( 'Description for doctors.', 'ti' ),
        'labels'              => $labels,
        'supports'            => array( 'title', 'editor', 'custom-fields', 'thumbnail' ),
        'taxonomies'          => array(),
        'hierarchical'        => false,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'show_in_nav_menus'   => true,
        'show_in_admin_bar'   => true,
        'menu_position'       => 5,
        'menu_icon'           => 'dashicons-admin-users',
        'can_export'          => true,
        'has_archive'         => true,
        'exclude_from_search' => false,
        'publicly_queryable'  => true,
        'capability_type'     => 'page',
    );
    register_post_type( 'doctors', $args );

}

add_action( 'init', 'doctors', 0 );

/**
 *  Taxonomy: Services Categories
 */
function doctors_categories() {
    $labels = array(
        'name'              => _x( 'Services', 'taxonomy general name', 'ti' ),
        'singular_name'     => _x( 'Services', 'taxonomy singular name', 'ti' ),
        'search_items'      => __( 'Search Services', 'ti' ),
        'all_items'         => __( 'All Services', 'ti' ),
        'parent_item'       => __( 'Parent Service', 'ti' ),
        'parent_item_colon' => __( 'Parent Service:', 'ti' ),
        'edit_item'         => __( 'Edit Service', 'ti' ),
        'update_item'       => __( 'Update Service', 'ti' ),
        'add_new_item'      => __( 'Add New Service', 'ti' ),
        'new_item_name'     => __( 'New Service', 'ti' ),
        'menu_name'         => __( 'Services', 'ti' ),
        'rewrite' => array('slug' => 'services', 'with_front' => true),
    );
    $args = array(
        'labels' => $labels,
        'hierarchical' => true,
        'public' => true,
        'show_ui'           => true,
        'exclude_from_search' => false,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => false
    );
    register_taxonomy( 'services', 'doctors', $args );
}
add_action( 'init', 'doctors_categories', 0 );

 require 'inc/cwp-update.php'; 

