		<?php
		/**
		 *  The template for displaying Front Page.
		 *
		 *  @package ThemeIsle.
		 */
		get_header();

		if ( 'posts' == get_option( 'show_on_front' ) ) {

			if ( get_theme_mod( 'ti_features_article_title' ) || get_theme_mod( 'ti_features_article_content' ) || get_theme_mod( 'ti_features_box1_image' ) || get_theme_mod( 'ti_features_box1_title' ) || get_theme_mod( 'ti_features_box1_content' ) || get_theme_mod( 'ti_features_box2_image' ) || get_theme_mod( 'ti_features_box2_title' ) || get_theme_mod( 'ti_features_box2_content' ) || get_theme_mod( 'ti_features_box3_image' ) || get_theme_mod( 'ti_features_box3_title' ) || get_theme_mod( 'ti_features_box3_content' ) || get_theme_mod( 'ti_features_box4_image' ) || get_theme_mod( 'ti_features_box4_title' ) || get_theme_mod( 'ti_features_box4_content' ) || get_theme_mod( 'ti_features_box4_button_text' ) ) { ?>

				<section id="features" class="cf">
					<div class="wrapper cf">
						<?php
						if ( get_theme_mod( 'ti_features_article_title' ) ) {
							echo '<h3>'. get_theme_mod( 'ti_features_article_title' ) .'</h3>';
						}

						if ( get_theme_mod( 'ti_features_article_content' ) ) {
							echo '<p>'. get_theme_mod( 'ti_features_article_content' ) .'</p>';
						}
						?>
						<ul class="cf">
							<?php
							if ( get_theme_mod( 'ti_features_box1_image' ) || get_theme_mod( 'ti_features_box1_title' ) || get_theme_mod( 'ti_features_box1_content' ) ) { ?>

								<li class="cf">
									<div class="icon-div">
										<?php
										if ( get_theme_mod( 'ti_features_box1_image' ) ) {

											if ( get_theme_mod( 'ti_features_box1_titlelink' ) ) {
												echo '<a href="'. get_theme_mod( 'ti_features_box1_titlelink' ) .'" title="'. get_theme_mod( 'ti_features_box1_title' ) .'"><img src="'. get_theme_mod( 'ti_features_box1_image' ) .'" alt="'. get_theme_mod( 'ti_features_box1_title' ) .'" /></a>';
											} else {
												echo '<i><img src="'. get_theme_mod( 'ti_features_box1_image' ) .'" alt="'. get_theme_mod( 'ti_features_box1_title' ) .'" /></i>';
											}

										} else {

											if ( get_theme_mod( 'ti_features_box1_titlelink' ) ) {
												echo '<a href="'. get_theme_mod( 'ti_features_box1_titlelink' ) .'" class="heart"></a>';
											} else {
												echo '<i class="heart"></i>';
											}

										}
										?>
									</div> <!-- s/div .icon-div -->
									<div class="info-div">
										<?php
										if ( get_theme_mod( 'ti_features_box1_title' ) ) {

											if ( get_theme_mod( 'ti_features_box1_titlelink' ) ) {
												echo '<a href="'. get_theme_mod( 'ti_features_box1_titlelink' ) .'" title="'. get_theme_mod( 'ti_features_box1_title' ) .'">'. get_theme_mod( 'ti_features_box1_title' ) .'</a>';
											} else {
												echo '<span>'. get_theme_mod( 'ti_features_box1_title' ) .'</span>';
											}

										}

										if ( get_theme_mod( 'ti_features_box1_content' ) ) {
											echo '<p>'. get_theme_mod( 'ti_features_box1_content' ) .'</p>';
										} else {
											echo '<p>'. __( 'Go to Appearance - Customize, to add content.', 'ti' ) .'</p>';
										}
										?>
									</div><!-- /div .info-div -->
								</li>

							<?php }

							if ( get_theme_mod( 'ti_features_box2_image' ) || get_theme_mod( 'ti_features_box2_title' ) || get_theme_mod( 'ti_features_box2_content' ) ) { ?>

								<li class="cf">
									<div class="icon-div">
										<?php
										if ( get_theme_mod( 'ti_features_box2_image' ) ) {

											if ( get_theme_mod( 'ti_features_box2_titlelink' ) ) {
												echo '<a href="'. get_theme_mod( 'ti_features_box2_titlelink' ) .'" title="'. get_theme_mod( 'ti_features_box2_title' ) .'"><img src="'. get_theme_mod( 'ti_features_box2_image' ) .'" alt="'. get_theme_mod( 'ti_features_box2_title' ) .'" /></a>';
											} else {
												echo '<i><img src="'. get_theme_mod( 'ti_features_box2_image' ) .'" alt="'. get_theme_mod( 'ti_features_box2_title' ) .'" /></i>';
											}

										} else {

											if ( get_theme_mod( 'ti_features_box2_titlelink' ) ) {
												echo '<a href="'. get_theme_mod( 'ti_features_box2_titlelink' ) .'" class="medic"></a>';
											} else {
												echo '<i class="medic"></i>';
											}

										}
										?>
									</div> <!-- s/div .icon-div -->
									<div class="info-div">
										<?php
										if ( get_theme_mod( 'ti_features_box2_title' ) ) {

											if ( get_theme_mod( 'ti_features_box2_titlelink' ) ) {
												echo '<a href="'. get_theme_mod( 'ti_features_box2_titlelink' ) .'" title="'. get_theme_mod( 'ti_features_box2_title' ) .'">'. get_theme_mod( 'ti_features_box2_title' ) .'</a>';
											} else {
												echo '<span>'. get_theme_mod( 'ti_features_box2_title' ) .'</span>';
											}

										}

										if ( get_theme_mod( 'ti_features_box2_content' ) ) {
											echo '<p>'. get_theme_mod( 'ti_features_box2_content' ) .'</p>';
										} else {
											echo '<p>'. __( 'Go to Appearance - Customize, to add content.', 'ti' ) .'</p>';
										}
										?>
									</div><!-- /div .info-div -->
								</li>

							<?php }

							if ( get_theme_mod( 'ti_features_box3_image' ) || get_theme_mod( 'ti_features_box3_title' ) || get_theme_mod( 'ti_features_box3_content' ) ) { ?>

								<li class="cf">
									<div class="icon-div">
										<?php
										if ( get_theme_mod( 'ti_features_box3_image' ) ) {

											if ( get_theme_mod( 'ti_features_box3_titlelink' ) ) {
												echo '<a href="'. get_theme_mod( 'ti_features_box3_titlelink' ) .'" title="'. get_theme_mod( 'ti_features_box3_title' ) .'"><img src="'. get_theme_mod( 'ti_features_box3_image' ) .'" alt="'. get_theme_mod( 'ti_features_box3_title' ) .'" /></a>';
											} else {
												echo '<i><img src="'. get_theme_mod( 'ti_features_box3_image' ) .'" alt="'. get_theme_mod( 'ti_features_box3_title' ) .'" /></i>';
											}

										} else {

											if ( get_theme_mod( 'ti_features_box3_titlelink' ) ) {
												echo '<a href="'. get_theme_mod( 'ti_features_box3_titlelink' ) .'" class="stethoscope"></a>';
											} else {
												echo '<i class="stethoscope"></i>';
											}

										}
										?>
									</div> <!-- s/div .icon-div -->
									<div class="info-div">
										<?php
										if ( get_theme_mod( 'ti_features_box3_title' ) ) {

											if ( get_theme_mod( 'ti_features_box3_titlelink' ) ) {
												echo '<a href="'. get_theme_mod( 'ti_features_box3_titlelink' ) .'" title="'. get_theme_mod( 'ti_features_box3_title' ) .'">'. get_theme_mod( 'ti_features_box3_title' ) .'</a>';
											} else {
												echo '<span>'. get_theme_mod( 'ti_features_box3_title' ) .'</span>';
											}

										}

										if ( get_theme_mod( 'ti_features_box3_content' ) ) {
											echo '<p>'. get_theme_mod( 'ti_features_box3_content' ) .'</p>';
										} else {
											echo '<p>'. __( 'Go to Appearance - Customize, to add content.', 'ti' ) .'</p>';
										}
										?>
									</div><!-- /div .info-div -->
								</li>

							<?php }

							if ( get_theme_mod( 'ti_features_box4_image' ) || get_theme_mod( 'ti_features_box4_title' ) || get_theme_mod( 'ti_features_box4_content' ) ) { ?>

								<li class="cf">
									<div class="icon-div">
										<?php
										if ( get_theme_mod( 'ti_features_box4_image' ) ) {

											if ( get_theme_mod( 'ti_features_box4_titlelink' ) ) {
												echo '<a href="'. get_theme_mod( 'ti_features_box4_titlelink' ) .'" title="'. get_theme_mod( 'ti_features_box4_title' ) .'"><img src="'. get_theme_mod( 'ti_features_box4_image' ) .'" alt="'. get_theme_mod( 'ti_features_box4_title' ) .'" /></a>';
											} else {
												echo '<i><img src="'. get_theme_mod( 'ti_features_box4_image' ) .'" alt="'. get_theme_mod( 'ti_features_box4_title' ) .'" /></i>';
											}

										} else {

											if ( get_theme_mod( 'ti_features_box4_titlelink' ) ) {
												echo '<a href="'. get_theme_mod( 'ti_features_box4_titlelink' ) .'" class="doctor"></a>';
											} else {
												echo '<i class="doctor"></i>';
											}

										}
										?>
									</div> <!-- s/div .icon-div -->
									<div class="info-div">
										<?php
										if ( get_theme_mod( 'ti_features_box4_title' ) ) {

											if ( get_theme_mod( 'ti_features_box4_titlelink' ) ) {
												echo '<a href="'. get_theme_mod( 'ti_features_box4_titlelink' ) .'" title="'. get_theme_mod( 'ti_features_box4_title' ) .'">'. get_theme_mod( 'ti_features_box4_title' ) .'</a>';
											} else {
												echo '<span>'. get_theme_mod( 'ti_features_box4_title' ) .'</span>';
											}

										}

										if ( get_theme_mod( 'ti_features_box4_content' ) ) {
											echo '<p>'. get_theme_mod( 'ti_features_box4_content' ) .'</p>';
										} else {
											echo '<p>'. __( 'Go to Appearance - Customize, to add content.', 'ti' ) .'</p>';
										}
										?>
									</div><!-- /div .info-div -->
								</li>

							<?php }
							?>
						</ul> <!-- /ul -->
						<?php
						if ( get_theme_mod( 'ti_features_box4_button_text' ) ) {
							echo '<a href="'. get_theme_mod( 'ti_features_box4_button_link' ) .'" id="view-more">'. get_theme_mod( 'ti_features_box4_button_text' ) .'</a>';
						}
						?>

					</div><!--/div .wrapper-->
				</section><!--/section #features-->

			<?php }
			?>
			<section id="content">
				<div class="wrapper cf">
					<div id="latest-news">
						<?php
						if ( get_theme_mod( 'ti_features_latestnews_title' ) ) {
							echo '<h3>'. get_theme_mod( 'ti_features_latestnews_title' ) .'</h3>';
						}
						?>
						<?php

						if ( get_theme_mod( 'ti_features_latestnews_numberofarticles' ) ) {
							$latestnews_numberofarticles =  get_theme_mod( 'ti_features_latestnews_numberofarticles' );
						} else {
							$latestnews_numberofarticles = '2';
						}

						$args = array (
							'post_type'				=> 'post',
							'posts_per_page'		=> $latestnews_numberofarticles,
							'ignore_sticky_posts'	=> true
						);

						$wp_query = new WP_Query( $args );

						if ( $wp_query->have_posts() ) {
							while ( $wp_query->have_posts() ) {
								$wp_query->the_post();
								$featured_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'single-post-thumbnail' ); ?>

								<div class="news cf">

									<?php
									if ( $featured_image ) { ?>

										<div class="img-div">
											<div class="news-image" style="background-image: url(<?php echo $featured_image[0]; ?>);">
											</div> <!-- /div .news-image -->
											<div class="link-img-news">
												<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"></a>
											</div> <!-- /div link-img-news -->
										</div> <!-- /div img-div -->

									<?php }
									?>

									<div class="info-news">
										<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
										<span><?php echo get_the_date(); ?></span>
										<p><?php echo excerpt_limit(25); ?></p>
									</div><!-- /div info-news -->
								</div><!-- /div .news -->

								<?php }
						} else {
							_e( 'No posts found', 'ti' );
						}

						wp_reset_postdata();
						?>

					</div><!-- /div latest-news -->
					<div class="content-testimonials">
						<div class="testimonials-title">
							<?php
							if ( get_theme_mod( 'ti_features_testimonials_title' ) ) {
								echo get_theme_mod( 'ti_features_testimonials_title' );
							}
							?>
						</div><!--/div .testimonials-title-->
						<div class="list_carousel">
							<ul id="foo2">
								<?php
								$testimonials_numberofarticles = get_theme_mod( 'ti_features_testimonials_numberofarticles' );
								$args = array (
									'post_type'			=> 'testimonials',
									'posts_per_page'	=> $testimonials_numberofarticles
								);

								$wp_query = new WP_Query( $args );

								if ( $wp_query->have_posts() ) {
									while ( $wp_query->have_posts() ) {
										$wp_query->the_post();
										$testimonials_company_name = get_post_meta($post->ID, 'ti_testimonials_company_name', true); ?>

										<li>
											<div class="list_carousel_entry">
												<?php the_excerpt(); ?>
											</div><!--/div .list_carousel_entry-->
											<div class="list_carousel_customer">
												<span><?php the_title(); ?>  </span><?php echo $testimonials_company_name; ?>
											</div><!--/div .list_carousel_customer-->
										</li><!--/li-->

										<?php }
								} else {
									_e( 'No posts found', 'ti' );
								}

								wp_reset_postdata();
								?>
							</ul><!--/ul-->
							<div class="clearfix"></div>
							<a id="prev2" class="prev"></a>
							<a id="next2" class="next"></a>
						</div><!--/div .list_carousel-->
					</div><!--/div .content-testimonials-->
					<div class="cf"></div>
					<?php

					$args = array (
						'post_type'			=> 'doctors'
					);

					$show_doctors = new WP_Query( $args );

					if ( $show_doctors->have_posts() ) { ?>

						<div class="our-doctors-prevew">
							<div class="doctors-index-title">
								<?php
								if ( get_theme_mod( 'ti_features_ourdoctors_title' ) ) {
									echo get_theme_mod( 'ti_features_ourdoctors_title' );
								}
								?>
							</div><!--/div .doctors-prev-title-->
							<ul class="list-doctors-index">

								<?php
									$args = array (
										'post_type'			=> 'doctors',
										'posts_per_page'	=> '4'
									);

									$wp_query = new WP_Query( $args );

									if ( $wp_query->have_posts() ) {
										while ( $wp_query->have_posts() ) {
											$wp_query->the_post();
											$featured_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'single-post-thumbnail' );
											$doctors_facebook_link = get_post_meta($post->ID, 'ti_doctors_facebook_link', true);
											$doctors_twitter_link = get_post_meta($post->ID, 'ti_doctors_twitter_link', true);
											$doctors_skype_link = get_post_meta($post->ID, 'ti_doctors_skype_link', true);
											$doctors_linkedin_link = get_post_meta($post->ID, 'ti_doctors_linkedin_link', true); ?>

											<li class="cf">

												<?php
												if ( $featured_image ) { ?>
													<div class="doctor-image" style="background-image: url('<?php echo $featured_image[0]; ?>');">
													</div>
												<?php } else { ?>
													<div class="doctor-image" style="background-image: url('<?php echo get_template_directory_uri(); ?>/images/no-image.png');">
													</div>
												<?php }
												?>

												<div class="link-img">
													<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"></a>
												</div><!--/div .link-img-->
												<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" class="doctor-name">
													<?php the_title(); ?>
												</a><!--/a .doctor-name-->
												<?php
												echo get_the_term_list( $post->ID, 'services', '', ', ' );

												if ( $doctors_facebook_link || $doctors_twitter_link || $doctors_skype_link || $doctors_linkedin_link ) { ?>

													<hr/>

													<div class="doctor-social">
														<?php
														if ( $doctors_facebook_link ) { ?>
															<a href="<?php echo $doctors_facebook_link; ?>" title="Facebook" class="social-button icon-facebook" target="_blank">
															</a><!--/.social-button .icon-facebook-->
														<?php }

														if ( $doctors_twitter_link ) { ?>
															<a href="<?php echo $doctors_twitter_link; ?>" title="Twitter" class="social-button icon-twitter" target="_blank">
															</a><!--/.social-button .icon-twitter-->
														<?php }

														if ( $doctors_skype_link ) { ?>
															<a href="<?php echo $doctors_skype_link; ?>" title="Skype" class="social-button icon-skype" target="_blank">
															</a><!--/.social-button .icon-skype-->
														<?php }

														if ( $doctors_linkedin_link ) { ?>
															<a href="<?php echo $doctors_linkedin_link; ?>" title="LinkedIn" class="social-button icon-in" target="_blank">
															</a><!--/.social-button .icon-in-->
														<?php }
														?>
													</div><!-- /div .doctor-social -->

												<?php } else {
													echo '<div class="no-doctor-social"></div>';
												}
												?>
											</li>

											<?php }
									} else {
										_e( 'No posts found', 'ti' );
									}

									wp_reset_postdata();
								?>

							</ul> <!-- /div list-doctors-index -->


						</div><!--/div .our-doctors-prevew-->

					<?php }
					?>
				</div><!--/div .wrapper-->
			</section><!--/section #content-->
		<?php get_footer();

		} else {
		    include( get_page_template() );
		}
		?>