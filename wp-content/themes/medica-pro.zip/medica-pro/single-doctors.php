			<?php get_header(); ?>
			<div class="wide-nav">
				<div class="wrapper">
					<h3>
						<?php _e( 'Our Doctor', 'ti' ); ?>
					</h3><!--/h3-->
				</div><!--/div .wrapper-->
			</div><!--/div .wide-nav-->
		</header><!--/header-->
		<section id="content">
			<div class="wrapper cf">
				<?php
				if ( have_posts() ) {
						while ( have_posts() ) {
							the_post();
							$featured_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'single-post-thumbnail' );
							$doctors_facebook_link = get_post_meta($post->ID, 'ti_doctors_facebook_link', true);
							$doctors_twitter_link = get_post_meta($post->ID, 'ti_doctors_twitter_link', true);
							$doctors_skype_link = get_post_meta($post->ID, 'ti_doctors_skype_link', true);
							$doctors_linkedin_link = get_post_meta($post->ID, 'ti_doctors_linkedin_link', true);
							$doctors_speciality_link = get_post_meta($post->ID, 'ti_doctors_speciality_link', true);
							$doctors_education_link = get_post_meta($post->ID, 'ti_doctors_education_link', true);
							$doctors_work_link = get_post_meta($post->ID, 'ti_doctors_work_link', true); ?>

							<div id="profile-our-resume" class="cf">
								<div id="info-doctor">
									<h2 class="doctor-title">
										<?php the_title(); ?>
									</h2>

									<?php the_content(); ?>

									<div class="cf"></div>
								</div><!-- /div #info-doctor -->
								<div id="photo-doctor">
									<?php
									if ( $featured_image ) { ?>
										<div class="image-doctor" style="background-image: url('<?php echo $featured_image[0]; ?>');">
										</div><!--/.image-doctor-->
									<?php } else { ?>
										<div class="image-doctor" style="background-image: url('<?php echo get_template_directory_uri(); ?>/images/no-image.png');">
										</div><!--/.image-doctor-->
									<?php }
									?>
									<h2><?php the_title(); ?></h2>
									<h3><?php echo get_the_term_list( $post->ID, 'services', '', ', ' ); ?></h3>
									<ul class="skills">
										<?php
										if ( $doctors_speciality_link ) { ?>
											<li>
												<span><?php _e( 'Speciality', 'ti' ); ?></span>
												<?php echo $doctors_speciality_link; ?>
											</li>
										<?php }

										if ( $doctors_education_link ) { ?>
											<li>
												<span><?php _e( 'Education', 'ti' ); ?></span>
												<?php echo $doctors_education_link; ?>
											</li>
										<?php }

										if ( $doctors_work_link ) { ?>
											<li>
												<span><?php _e( 'Work', 'ti' ); ?></span>
												<?php echo $doctors_work_link; ?>
											</li>
										<?php }
										?>
									</ul><!-- /ul .skills -->
									<div class="doctor-social">
										<?php
										if ( $doctors_facebook_link ) { ?>
											<a href="<?php echo $doctors_facebook_link; ?>" title="Facebook" class="social-button icon-facebook" target="_blank">
											</a><!--/.social-button .icon-facebook-->
										<?php }

										if ( $doctors_twitter_link ) { ?>
											<a href="<?php echo $doctors_twitter_link; ?>" title="Twitter" class="social-button icon-twitter" target="_blank">
											</a><!--/.social-button .icon-twitter-->
										<?php }

										if ( $doctors_skype_link ) { ?>
											<a href="<?php echo $doctors_skype_link; ?>" title="Skype" class="social-button icon-skype" target="_blank">
											</a><!--/.social-button .icon-skype-->
										<?php }

										if ( $doctors_linkedin_link ) { ?>
											<a href="<?php echo $doctors_linkedin_link; ?>" title="LinkedIn" class="social-button icon-in" target="_blank">
											</a><!--/.social-button .icon-in-->
										<?php }
										?>
									</div><!-- /div .doctor-social -->
								</div><!-- /div #photo-doctor -->
							</div><!-- /div #profile-our-resume -->

							<?php }
					} else {
						_e( 'No posts found', 'ti' );
					}
				?>

			</div><!--/div .wrapper-->
		</section><!--/section #content-->
		<?php get_footer(); ?>