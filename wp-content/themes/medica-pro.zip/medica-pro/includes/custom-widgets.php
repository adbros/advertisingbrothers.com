<?php

/**
 *	Our Doctors Widget
 */
add_action( 'widgets_init', 'ourdoctors_widgets' );

function ourdoctors_widgets() {
    register_widget( 'ourdoctors_widgets' );
}

class ourdoctors_widgets extends WP_Widget {

    function ourdoctors_widgets() {
        $widget_ops = array( 'classname' => 'example', 'description' => __('A widget that displays the latest doctors.', 'ti') );

        $control_ops = array( 'width' => 300, 'height' => 350, 'id_base' => 'ourdoctors_widgets' );

        $this->WP_Widget( 'ourdoctors_widgets', __('Our Doctors', 'ti'), $widget_ops, $control_ops );
    }

    function widget( $args, $instance ) {
        extract( $args );

        //Our variables from the widget settings.
        $title = apply_filters('widget_title', $instance['title'] );
        $ourlawyers_number_posts = $instance['ourlawyers_number_posts'];

        echo $before_widget;

        // Display the widget title
        if ( $title )
            echo $before_title . $title . $after_title; ?>

        <div class="widget-our-lawyers cf">

            <?php
                $args = array (
                    'post_type'              => 'doctors',
                    'posts_per_page'         => $ourlawyers_number_posts,
                    'ignore_sticky_posts'    => true,
                    'paged'                  => $paged,
                );

                $wp_query = new WP_Query( $args );

                if ( $wp_query->have_posts() ) : while ( $wp_query->have_posts() ) : $wp_query->the_post();
                $featured_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'single-post-thumbnail' );
            ?>

            <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" class="lawyer">
            	<?php
            	if ( $featured_image ) { ?>
            		<div class="lawyer-image" style="background-image: url('<?php echo $featured_image[0]; ?>');">
					</div><!--/.lawyer-image-->
            	<?php } else { ?>
            		<div class="lawyer-image" style="background-image: url('<?php echo get_template_directory_uri(); ?>/images/no-image.png');">
					</div><!--/.lawyer-image-->
            	<?php }
            	?>
				<div class="lawyer-image-overlay">
				</div><!--/div .lawyer-image-overlay-->
			</a><!--/a.lawyer .lawyer-margin-left-->

            <?php endwhile; else: ?>
                <p><?php _e('Sorry, no posts matched your criteria.', 'ti'); ?></p>
            <?php endif; ?>
            <?php wp_reset_postdata(); ?>

        </div><!--/div .widget-our-lawyers-->

        <?php echo $after_widget;
    }

    //Update the widget

    function update( $new_instance, $old_instance ) {
        $instance = $old_instance;

        //Strip tags from title and name to remove HTML
        $instance['title'] = strip_tags( $new_instance['title'] );
        $instance['ourlawyers_number_posts'] = strip_tags( $new_instance['ourlawyers_number_posts'] );

        return $instance;
    }


    function form( $instance ) {

        //Set up some default widget settings.
        $defaults = array( 'title' => __('Our Doctors', 'ti'), 'ourlawyers_number_posts' => __('4', 'ti') );
        $instance = wp_parse_args( (array) $instance, $defaults ); ?>

        <p>
            <label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e('Title:', 'ti'); ?></label>
            <input id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" style="width:100%;" />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id( 'ourlawyers_number_posts' ); ?>"><?php _e('Number of posts:', 'ti'); ?></label>
            <input id="<?php echo $this->get_field_id( 'ourlawyers_number_posts' ); ?>" name="<?php echo $this->get_field_name( 'ourlawyers_number_posts' ); ?>" value="<?php echo $instance['ourlawyers_number_posts']; ?>" style="width:100%;" />
        </p>

    <?php
    }
}

/**
 *  Services
 */
add_action( 'widgets_init', 'services_widget' );


function services_widget() {
    register_widget( 'services_widget' );
}

class services_widget extends WP_Widget {

    function services_widget() {
        $widget_ops = array( 'classname' => 'example', 'description' => __('A widget that displays the Services.', 'ti') );

        $control_ops = array( 'width' => 300, 'height' => 350, 'id_base' => 'services_widget' );

        $this->WP_Widget( 'services_widget', __('Services', 'ti'), $widget_ops, $control_ops );
    }

    function widget( $args, $instance ) {
        extract( $args );

        //Our variables from the widget settings.
        $title = apply_filters('widget_title', $instance['title'] );

        echo $before_widget;

        // Display the widget title
        if ( $title )
            echo $before_title . $title . $after_title; ?>

        <div class="widget-practice-area">
            <ul>
                <?php
                    $get_taxonomy = get_terms( 'services' );
                    foreach ( $get_taxonomy as $taxonomy_category ) {
                        $taxonomy_category = sanitize_term( $taxonomy_category, 'doctors' );
                        $term_link = get_term_link( $taxonomy_category, 'doctors' ); ?>
                        <li>
							<a href="<?php echo esc_url( $term_link ); ?>" title="<?php echo $taxonomy_category->name; ?>" class="tooltip">
								<?php echo $taxonomy_category->name; ?>
							</a><!--/a-->
						</li><!--/li-->
                    <?php } ?>
                <?php ?>
            </ul><!--/ul-->
        </div><!--/div .widget-practice-area-->

        <?php echo $after_widget;
    }

    //Update the widget

    function update( $new_instance, $old_instance ) {
        $instance = $old_instance;

        //Strip tags from title and name to remove HTML
        $instance['title'] = strip_tags( $new_instance['title'] );

        return $instance;
    }


    function form( $instance ) {

        //Set up some default widget settings.
        $defaults = array( 'title' => __('Services', 'ti') );
        $instance = wp_parse_args( (array) $instance, $defaults ); ?>

        <p>
            <label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e('Title:', 'ti'); ?></label>
            <input id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" style="width:100%;" />
        </p>

    <?php
    }
}

/**
 *  Testimonials Widget
 */
add_action( 'widgets_init', 'testimonials_widget' );

function testimonials_widget() {
    register_widget( 'Testimonials_Widget' );
}

class Testimonials_Widget extends WP_Widget {

    function Testimonials_Widget() {
        $widget_ops = array( 'classname' => 'example', 'description' => __('A widget that displays the latest testimonials.', 'ti') );

        $control_ops = array( 'width' => 300, 'height' => 350, 'id_base' => 'testimonials_widget' );

        $this->WP_Widget( 'testimonials_widget', __('Testimonials', 'ti'), $widget_ops, $control_ops );
    }

    function widget( $args, $instance ) {
        extract( $args );

        //Our variables from the widget settings.
        $title = apply_filters('widget_title', $instance['title'] );
        $testimonials_number_posts = $instance['testimonials_number_posts'];

        echo $before_widget;

        // Display the widget title
        if ( $title )
            echo $before_title . $title . $after_title; ?>

        <div class="widget-testimonials cf">
            <div class="list_carousel">
                <ul id="foo2">
                    <?php
                        $args = array (
                            'post_type'              => 'testimonials',
                            'posts_per_page'         => $testimonials_number_posts,
                            'ignore_sticky_posts'    => true,
                            'paged'                  => $paged,
                        );

                        $testimonials = new WP_Query( $args );

                        if ( $testimonials->have_posts() ) : while ( $testimonials->have_posts() ) : $testimonials->the_post();
                        global $post;

                        $testimonials_company_name = get_post_meta($post->ID, 'ti_testimonials_company_name', true);

                        ?>
                    <li>
						<div class="list_carousel_entry">
							<?php the_excerpt(); ?>
						</div><!--/div .list_carousel_entry-->
						<div class="list_carousel_customer">
							<span><?php the_title(); ?></span><br />
							<?php echo $testimonials_company_name; ?>
						</div><!--/div .list_carousel_customer-->
					</li><!--/li-->

                    <?php endwhile; else: ?>
                        <p><?php _e('Sorry, no posts matched your criteria.', 'ti'); ?></p>
                    <?php endif; ?>
                    <?php wp_reset_postdata(); ?>
                </ul><!--/ul-->
                <div class="clearfix"></div>
                <a id="prev2" class="prev" href="#"></a>
                <a id="next2" class="next" href="#"></a>
            </div><!--/div .list_carousel-->

        </div><!--/div .widget-testimonials-->

        <?php echo $after_widget;
    }

    //Update the widget

    function update( $new_instance, $old_instance ) {
        $instance = $old_instance;

        //Strip tags from title and name to remove HTML
        $instance['title'] = strip_tags( $new_instance['title'] );
        $instance['testimonials_number_posts'] = strip_tags( $new_instance['testimonials_number_posts'] );

        return $instance;
    }


    function form( $instance ) {

        //Set up some default widget settings.
        $defaults = array( 'title' => __('Testimonials', 'ti'), 'testimonials_number_posts' => __('2', 'ti') );
        $instance = wp_parse_args( (array) $instance, $defaults ); ?>

        <p>
            <label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e('Title:', 'ti'); ?></label>
            <input id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" style="width:100%;" />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id( 'testimonials_number_posts' ); ?>"><?php _e('Number of testimonials:', 'ti'); ?></label>
            <input id="<?php echo $this->get_field_id( 'testimonials_number_posts' ); ?>" name="<?php echo $this->get_field_name( 'testimonials_number_posts' ); ?>" value="<?php echo $instance['testimonials_number_posts']; ?>" style="width:100%;" />
        </p>

    <?php
    }
}

?>