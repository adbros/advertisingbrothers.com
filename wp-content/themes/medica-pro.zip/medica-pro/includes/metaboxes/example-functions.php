<?php
/**
 * Include and setup custom metaboxes and fields.
 *
 * @category YourThemeOrPlugin
 * @package  Metaboxes
 * @license  http://www.opensource.org/licenses/gpl-license.php GPL v2.0 (or later)
 * @link     https://github.com/webdevstudios/Custom-Metaboxes-and-Fields-for-WordPress
 */

add_filter( 'cmb_meta_boxes', 'cmb_sample_metaboxes' );
/**
 * Define the metabox and field configurations.
 *
 * @param  array $meta_boxes
 * @return array
 */
function cmb_sample_metaboxes( array $meta_boxes ) {

	// Start with an underscore to hide fields from custom fields list
	$prefix = 'ti_';

	$meta_boxes['testimonials_details_metabox'] = array(
		'id'         => 'testimonials_details',
		'title'      => __( 'Testimonials - Details', 'ti' ),
		'pages'      => array( 'testimonials', ),
		'context'    => 'normal',
		'priority'   => 'high',
		'show_names' => true,
		'fields'     => array(
			array(
				'name' => __( 'Company Name:', 'ti' ),
				'desc' => __( 'Type the company name (example: ThemeIsle, L.L.C., Google L.L.C., etc.).', 'ti' ),
				'id'   => $prefix . 'testimonials_company_name',
				'type' => 'text_medium',
			),
		),
	);

	$meta_boxes['doctors_details_metabox'] = array(
		'id'         => 'doctors_details',
		'title'      => __( 'Doctors - Details', 'ti' ),
		'pages'      => array( 'doctors', ),
		'context'    => 'normal',
		'priority'   => 'high',
		'show_names' => true,
		'fields'     => array(
			array(
				'name' => __( 'Facebook link:', 'ti' ),
				'desc' => __( 'Type your Facebook address.', 'ti' ),
				'id'   => $prefix . 'doctors_facebook_link',
				'type' => 'text_medium',
			),
			array(
				'name' => __( 'Twitter link:', 'ti' ),
				'desc' => __( 'Type your Twitter address.', 'ti' ),
				'id'   => $prefix . 'doctors_twitter_link',
				'type' => 'text_medium',
			),
			array(
				'name' => __( 'Skype link:', 'ti' ),
				'desc' => __( 'Type your Skype address.', 'ti' ),
				'id'   => $prefix . 'doctors_skype_link',
				'type' => 'text_medium',
			),
			array(
				'name' => __( 'LinkedIn link:', 'ti' ),
				'desc' => __( 'Type your LinkedIn address.', 'ti' ),
				'id'   => $prefix . 'doctors_linkedin_link',
				'type' => 'text_medium',
			),
			array(
				'name' => __( 'Speciality:', 'ti' ),
				'desc' => __( 'Your speciality.', 'ti' ),
				'id'   => $prefix . 'doctors_speciality_link',
				'type' => 'text_medium',
			),
			array(
				'name' => __( 'Education:', 'ti' ),
				'desc' => __( 'Your education.', 'ti' ),
				'id'   => $prefix . 'doctors_education_link',
				'type' => 'text_medium',
			),
			array(
				'name' => __( 'Work:', 'ti' ),
				'desc' => __( 'Your work.', 'ti' ),
				'id'   => $prefix . 'doctors_work_link',
				'type' => 'text_medium',
			),
		),
	);

	return $meta_boxes;
}

add_action( 'init', 'cmb_initialize_cmb_meta_boxes', 9999 );
/**
 * Initialize the metabox class.
 */
function cmb_initialize_cmb_meta_boxes() {

	if ( ! class_exists( 'cmb_Meta_Box' ) )
		require_once 'init.php';

}
