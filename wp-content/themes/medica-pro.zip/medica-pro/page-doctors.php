			<?php
			/**
			 *  The template for displaying Page Doctors.
			 *
			 *  @package ThemeIsle.
			 *
			 *	Template Name: Doctors
			 */
			get_header();
			?>
			<div class="wide-nav">
				<div class="wrapper">
					<h3>
						<?php the_title(); ?>
					</h3><!--/h3-->
				</div><!--/div .wrapper-->
			</div><!--/div .wide-nav-->
		</header><!--/header-->
		<section id="content">
			<div class="wrapper cf">
				<div id="our-doctors" class="cf">
					<div class="our-doctors-content cf">

						<?php
						$numberofposts = get_theme_mod( 'ti_doctorspage_articles_numberofposts' );
						$args = array (
							'post_type'			=> 'doctors',
							'posts_per_page'	=> $numberofposts
						);

						$wp_query = new WP_Query( $args );

						if ( $wp_query->have_posts() ) {
							while ( $wp_query->have_posts() ) {
								$wp_query->the_post();
								$featured_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'single-post-thumbnail' );
								$doctors_facebook_link = get_post_meta($post->ID, 'ti_doctors_facebook_link', true);
								$doctors_twitter_link = get_post_meta($post->ID, 'ti_doctors_twitter_link', true);
								$doctors_skype_link = get_post_meta($post->ID, 'ti_doctors_skype_link', true);
								$doctors_linkedin_link = get_post_meta($post->ID, 'ti_doctors_linkedin_link', true); ?>

									<div class="doctor">
										<?php
										if ( $featured_image ) { ?>
											<div class="doctor-image" style="background-image: url('<?php echo $featured_image[0]; ?>');">
											</div><!--/div .lawyer-image-->
										<?php } else { ?>
											<div class="doctor-image" style="background-image: url('<?php echo get_template_directory_uri(); ?>/images/no-image.png');">
											</div><!--/div .lawyer-image-->
										<?php }
										?>
										<div class="link-img cf">
												<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"></a>
										</div><!--/div .link-img-->
										<div class="doctor-content">
											<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" class="doctor-name">
												<?php the_title(); ?>
											</a><!--/a .doctor-name-->
											<a href="" class="doctor-function cf">
												<?php echo get_the_term_list( $post->ID, 'services', '', ', ' ); ?>
											</a><!-- /a .doctor-function -->
											<?php
											if ( excerpt_limit(15) ) {
												echo '<p class="doctor-entry">';
												echo excerpt_limit(15);
												echo '</p>';
											}
											?>
											<div class="doctor-social">
												<?php
												if ( $doctors_facebook_link ) { ?>
													<a href="<?php echo $doctors_facebook_link; ?>" title="Facebook" class="social-button icon-facebook" target="_blank">
													</a><!--/.social-button .icon-facebook-->
												<?php }

												if ( $doctors_twitter_link ) { ?>
													<a href="<?php echo $doctors_twitter_link; ?>" title="Twitter" class="social-button icon-twitter" target="_blank">
													</a><!--/.social-button .icon-twitter-->
												<?php }

												if ( $doctors_skype_link ) { ?>
													<a href="<?php echo $doctors_skype_link; ?>" title="Skype" class="social-button icon-skype" target="_blank">
													</a><!--/.social-button .icon-skype-->
												<?php }

												if ( $doctors_linkedin_link ) { ?>
													<a href="<?php echo $doctors_linkedin_link; ?>" title="LinkedIn" class="social-button icon-in" target="_blank">
													</a><!--/.social-button .icon-in-->
												<?php }
												?>
											</div><!-- /div .doctor-social -->
										</div><!--/.doctor-content-->
									</div><!--/div .doctor-->

									<?php }
							} else {
								_e( 'No posts found', 'ti' );
							}

							wp_reset_postdata();
						?>

					</div><!--/div .doctors-content-doctors .cf-->
				</div><!--/div #doctors-content .cf-->
			</div><!--/div .wrapper-->
		</section><!--/section #content-->
		<?php get_footer(); ?>