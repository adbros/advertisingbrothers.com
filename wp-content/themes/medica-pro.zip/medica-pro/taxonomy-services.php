			<?php get_header(); ?>
			<div class="wide-nav">
				<div class="wrapper">
					<h3>
						<?php
						$taxonomy_category = $wp_query->queried_object;
						echo $taxonomy_category->name;
						?>
					</h3><!--/h3-->
				</div><!--/div .wrapper-->
			</div><!--/div .wide-nav-->
		</header><!--/header-->
		<section id="content">
			<div class="wrapper cf">
				<div id="our-doctors" class="cf">
					<div class="our-doctors-content cf">

						<?php

						if ( have_posts() ) {
							while ( have_posts() ) {
								the_post();
								$featured_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'single-post-thumbnail' ); ?>

								<div class="doctor">
									<?php
									if ( $featured_image ) { ?>
										<div class="doctor-image" style="background-image: url('<?php echo $featured_image[0]; ?>');">
										</div><!--/div .doctor-image-->
									<?php } else { ?>
										<div class="doctor-image" style="background-image: url('<?php echo get_template_directory_uri(); ?>/images/no-image.png');">
										</div><!--/div .doctor-image-->
									<?php }
									?>
									<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" class="doctor-name-services">
										<?php the_title(); ?>
									</a><!--/a .doctor-name-->
									<p class="doctor-entry-services">
										<?php echo excerpt_limit(20); ?>
									</p><!--/p .doctor-entry-->
									<a href="<?php the_permalink(); ?>" id="read-more"><?php _e( 'Read more', 'ti' ); ?></a>
								</div><!--/div .doctor-->

								<?php }
							} else {
								_e( 'No posts found', 'ti' );
							}
						?>

					</div><!--/div .doctors-content-doctors .cf-->
				</div><!--/div #doctors-content .cf-->
			</div><!--/div .wrapper-->
		</section><!--/section #content-->
		<?php get_footer(); ?>