= CWP Robi =
Contributors:
codeinwp

Tags: black, blue, white, gray, one-column, three-columns, right-sidebar, custom-menu, theme-options, translation-ready
Requires at least:	3.3.0

Tested up to:		3.5.2

CWP Robi

== Description ==
CWP Robi is a easily customizable WordPress Theme with numerous theme options and an elegant design.
= License =

Unless otherwise specified, all the theme files, scripts and images are licensed under GNU General Public Licemse.

The exceptions to this license are as follows:

* jQuery Masonry v2.1.01 Licensed under the MIT license. https://github.com/jquery/jquery/blob/master/MIT-LICENSE.txt
