<?php get_header(); ?>
<div id="error"></div>
<div id="searcherror">
<!--Search-->
<div class="notfound">	<?php get_search_form(); ?>
</div>
<!--Search-->
</div>
<?php get_footer(); ?>