= PlumBelt Lite =

Author: codeinwp

Author URI: Codeinwp.com

Tags: white, yellow, light, two-columns, right-sidebar, custom-menu, featured-images, sticky-post, translation-ready

Requires at least:	3.3.0
Tested up to:		4.0

PlumBelt Lite

== Description ==

PlumBelt is a free business wordpress theme, can be used for plumber, lawyer, dentist or other small business.Some of the major features of PlumBelt are responsive layout, featured images, custom menu, sticky posts and custom contact form. Match is also suitable for personal, portfolio, travel and photography.

= License =

Unless otherwise specified, all the theme files, scripts and images are licensed under GNU General Public License v2.

The exceptions to this license are as follows: 

	* fancybox:
	
		License: www.fancyapps.com/fancybox/#license
		
	* Archivo Narrow font:	
		
		http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL
	
	* Istok Web font:	
		
		http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL	
		
	* Source Sans Pro font:

		http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL	
				
	* jQuery Masonry v2.0.110517 beta
	
		Licensed under the MIT license.