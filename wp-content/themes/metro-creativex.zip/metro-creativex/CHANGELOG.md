

### 1.2.6 - 30/12/2014

 Changes: 


 * added tgm activation


### 1.2.5 - 08/12/2014

 Changes: 


 * Removed tinynav never used, fixed prefix issues
 * Removed tinynav
 * Added forum link in description and added sanitize for customizer
 * added text domain
 * increased vers


### 1.2.3 - 17/10/2014

 Changes: 


 * Update style.css


### 1.2.2 - 17/10/2014

 Changes: 


 * Update style.css


### 1.2.1 - 17/10/2014

 Changes: 


 * Update style.css
