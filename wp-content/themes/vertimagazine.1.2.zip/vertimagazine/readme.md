![VertiMagazine - Free Wordpress Theme](/screenshot.png)  

*VertiMagazine is a responsive WordPress Theme made for people who love beautiful typography.Along with the elegant design the theme is easily customizable with numerous theme options, for example you will be able to easily edit logo, menus.

# Installation
1. Upload the `vertimagazine` folder to the `/wp-content/themes/` directory
Activation and Use
1. Activate the Theme through the 'Themes' menu in WordPress
2. See Appearance -> Theme Options to change theme options


# License
Unless otherwise specified, all the theme files, scripts and images
are licensed under GNU General Public License version 2.
The exceptions to this license are as follows:
* Bootstrap by Twitter and the Glyphicon set are licensed under the GPL-compatible [http://www.apache.org/licenses/LICENSE-2.0 Apache License v2.0]
* The script tinynav is licensed under MIT licenses
* The script html5.js is Dual licensed under the MIT or GPL Version 2 licenses