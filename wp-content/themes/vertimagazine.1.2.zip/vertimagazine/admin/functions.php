<?php
		require( get_template_directory() . '/admin/inc/config.php' ); 
		require( get_template_directory() . '/admin/inc/adminOptionsValidator.php' );
		require( get_template_directory() . '/admin/inc/adminSanitizer.php' );
		require( get_template_directory() . '/admin/inc/render.php' ); 
		require( get_template_directory() . '/admin/inc/loader.php' );  
		
?>