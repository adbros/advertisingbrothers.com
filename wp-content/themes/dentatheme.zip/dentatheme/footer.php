		<footer>
			<div class="wrap">
				<div class="footer-top cf">

					<?php
					if ( get_theme_mod( 'ti_aboutus_title' ) || get_theme_mod( 'ti_aboutus_entry' ) ) { ?>

						<div class="footer-top-box1">
							<?php
							if ( get_theme_mod( 'ti_aboutus_title' ) ) {
								echo '<div class="footer-title">'. get_theme_mod( 'ti_aboutus_title' ) .'</div>';
							}

							if ( get_theme_mod( 'ti_aboutus_logo' ) ) {
								echo '<div class="footer-box1-logo"><img src="'. get_theme_mod( 'ti_aboutus_logo' ) .'" title="'. get_bloginfo( 'name' ) .'" alt="'. get_bloginfo( 'name' ) .'" /></div>';
							}

							if ( get_theme_mod( 'ti_aboutus_entry' ) ) {
								echo '<div class="footer-box1-entry">'. get_theme_mod( 'ti_aboutus_entry' ) .'</div>';
							}
							?>
						</div><!--/.footer-top-box1-->

					<?php }
					?>

					<div class="footer-top-box2">
						<div class="footer-title">
							<?php _e( 'Menu', 'ti' ); ?>
						</div><!--/.footer-title-->
						<?php
						wp_nav_menu( array(
								'theme_location'	=> 'footer_navigation',
								'container'			=> '',
								'container_class'	=> ''
							)
						);
						?>
					</div><!--/.footer-top-box2-->

					<?php
					if ( get_theme_mod( 'ti_contactus_title' ) || get_theme_mod( 'ti_contactus_entry' ) || get_theme_mod( 'ti_contactus_facebooklink' ) || get_theme_mod( 'ti_contactus_twitterlink' ) || get_theme_mod( 'ti_contactus_youtubelink' ) || get_theme_mod( 'ti_contactus_linkedinlink' ) ) { ?>

						<div class="footer-top-box3">
							<?php
							if ( get_theme_mod( 'ti_contactus_title' ) ) {
								echo '<div class="footer-title">'. get_theme_mod( 'ti_contactus_title' ) .'</div>';
							}

							if ( get_theme_mod( 'ti_contactus_entry' ) ) {
								echo '<div class="footer-box3-entry">'. htmlspecialchars_decode( get_theme_mod( 'ti_contactus_entry' ) ) .'</div>';
							}

							if ( get_theme_mod( 'ti_contactus_facebooklink' ) ) {
								echo '<a href="'. get_theme_mod( 'ti_contactus_facebooklink' ) .'" title="'. __( 'Facebook', 'ti' ) .'" target="_blank" class="facebook-icon"></a>';
							}

							if ( get_theme_mod( 'ti_contactus_twitterlink' ) ) {
								echo '<a href="'. get_theme_mod( 'ti_contactus_twitterlink' ) .'" title="'. __( 'Twitter', 'ti' ) .'" target="_blank" class="twitter-icon"></a>';
							}

							if ( get_theme_mod( 'ti_contactus_youtubelink' ) ) {
								echo '<a href="'. get_theme_mod( 'ti_contactus_youtubelink' ) .'" title="'. __( 'YouTube', 'ti' ) .'" target="_blank" class="youtube-icon"></a>';
							}

							if ( get_theme_mod( 'ti_contactus_linkedinlink' ) ) {
								echo '<a href="'. get_theme_mod( 'ti_contactus_linkedinlink' ) .'" title="LinkedIn" target="_blank" class="linkedin-icon"></a>';
							}
							?>
						</div><!--/.footer-top-box3-->

					<?php }
					?>

				</div><!--/.footer-top.cf-->
				<div class="footer-copyright">
					<?php
					if ( get_theme_mod( 'ti_copyright_entry' ) ) {
						echo htmlspecialchars_decode( get_theme_mod( 'ti_copyright_entry' ) );
					} else {
						echo __( 'Copyright &copy; ', 'ti' ) . '<a href="" title="'. __( 'DentaTheme', 'ti' ) .'">'. __( 'DentaTheme', 'ti' ) .'</a>. '. __( 'All rights reserved.', 'ti' ) .'';
					}
					?>
				</div><!--/.footer-copyright-->
			</div><!--/.wrap-->
		</footer>
		<?php wp_footer(); ?>
	</body>
</html>