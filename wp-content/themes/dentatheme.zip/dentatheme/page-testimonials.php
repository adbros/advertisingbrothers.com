<?php
/**
 *	Template Name: Testimonials
 *
 *	The template for displaying Testimonials.
 *
 *	@package ThemeIsle.
 */
get_header();
?>
<div class="wrap">
	<div class="fullwidth-page-title">
		<h3><?php the_title(); ?></h3>
	</div><!--/.fullwidth-page-title-->

	<?php

	if ( $wp_query->have_posts() ) {
		while ( $wp_query->have_posts() ) {
			$wp_query->the_post();
			$featured_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'single-post-thumbnail' ); ?>

			<div id="page-testimonials">
				<?php
				if ( $featured_image ) {
					echo '<div class="page-testimonials-image" style="background-image: url('. $featured_image[0] .'); ?>"></div>';
				}
				?>
				<div class="page-testimonials-entry">
					<?php the_content(); ?>
				</div><!--/.page-testimonials-entry-->
			</div><!--/#page-testimonials-->

		<?php }
	}
	?>
	<div class="page-testimonials-articles">
		<?php
		if ( get_theme_mod( 'ti_testimonialspage_subtitle' ) ) {
			echo '<div class="fullwidth-single-title"><h4>'. get_theme_mod( 'ti_testimonialspage_subtitle' ) .'</h4></div>';
		}

		$testimonialspage_numberofarticles = get_theme_mod( 'ti_testimonialspage_numberofarticles' );

		$args = array (
			'post_type'              => 'testimonials',
			'posts_per_page'         => $testimonialspage_numberofarticles,
			'ignore_sticky_posts'    => true,
		);

		$wp_query = new WP_Query( $args );

		if ( $wp_query->have_posts() ) {
			while ( $wp_query->have_posts() ) {
				$wp_query->the_post();
				$featured_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'single-post-thumbnail' );
				$testimonial_position = get_post_meta($post->ID, 'ti_testimonial_position', true);
				$testimonial_companyname = get_post_meta($post->ID, 'ti_testimonial_companyname', true);
				$testimonial_companylink = get_post_meta($post->ID, 'ti_testimonial_companylink', true); ?>

				<article class="testimonials-article cf">
					<div class="testimonials-article-left">
						<?php
						if ( $featured_image ) {
							echo '<div class="article-left-image" style="background-image: url('. $featured_image[0] .')"></div>';
						} else {
							echo '<div class="article-left-no-image">'. __( 'No image', 'ti' ) .'</div>';
						}
						?>
						<div class="article-left-title">
							<?php the_title(); ?>
						</div><!--/.article-left-title-->
						<div class="article-left-meta">
							<?php
								if ( $testimonial_position ) {
									echo $testimonial_position . __( ' at ', 'ti' );
								}

								if ( $testimonial_companylink ) {
									echo '<span><a href="'. $testimonial_companylink .'" title="'. $testimonial_companyname .'" target="_blank">'. $testimonial_companyname .'</a></span>';
								} else {
									echo '<span>'. $testimonial_companyname .'</span>';
								}
							?>
						</div><!--/.article-left-meta-->
					</div><!--/.testimonials-article-left-->
					<div class="testimonials-article-right">
						<?php the_excerpt(); ?>
					</div><!--/.testimonials-article-right-->
				</article><!--/.testimonials-article.cf-->

			<?php }
		} else {
			_e( 'No posts found.', 'ti' );
		}
			wp_reset_postdata();
		?>

	</div><!--/.page-testimonials-articles-->

</div><!--/.wrap-->
<?php get_footer(); ?>