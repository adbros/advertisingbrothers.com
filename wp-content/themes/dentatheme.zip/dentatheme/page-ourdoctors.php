<?php
/**
 *	Template Name: Our Doctors
 *
 *	The template for displaying Our Doctors.
 *
 *	@package ThemeIsle.
 */
get_header();
?>
<div class="wrap">
	<div id="ourdoctors">
		<div class="fullwidth-page-title">
			<h3><?php the_title(); ?></h3>
		</div><!--/.fullwidth-page-title-->
		<div class="ourdoctors-articles cf">

			<?php
			$ourdoctors_numberofarticles = get_post_meta($post->ID, 'ti_ourdoctors_numberofarticles', true);

			$args = array (
				'post_type'              => 'doctors',
				'posts_per_page'         => $ourdoctors_numberofarticles,
				'ignore_sticky_posts'    => true,
			);

			$wp_query = new WP_Query( $args );

			if ( $wp_query->have_posts() ) {
				while ( $wp_query->have_posts() ) {
					$wp_query->the_post();
					$featured_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'single-post-thumbnail' );
					$doctors_facebook = get_post_meta($post->ID, 'ti_doctors_facebook', true);
					$doctors_twitter = get_post_meta($post->ID, 'ti_doctors_twitter', true);
					$doctors_googleplus = get_post_meta($post->ID, 'ti_doctors_googleplus', true);
					$doctors_linkedin = get_post_meta($post->ID, 'ti_doctors_linkedin', true);

					if ( $doctors_facebook || $doctors_twitter || $doctors_googleplus || $doctors_linkedin ) {
						$ourdoctors_article_entry_class =  'ourdoctors-article-entry';
					} else {
						$ourdoctors_article_entry_class =  'ourdoctors-article-entry2';
					} ?>

					<div class="ourdoctors-article">
						<?php
						if ( $featured_image ) {
							echo '<div class="ourdoctors-article-image" style="background-image: url('. $featured_image[0] .');"></div>';
						} else {
							echo '<div class="ourdoctors-article-no-image">'. __( 'No image', 'ti' ) .'</div>';
						}
						?>
						<div class="ourdoctors-article-title">
							<?php the_title(); ?>
						</div><!--/.ourdoctors-article-title-->
						<div class="ourdoctors-article-meta">
							<?php echo get_the_term_list( $post->ID, 'services', '', ', ' ); ?>
						</div><!--/.ourdoctors-article-meta-->
						<div class="<?php echo $ourdoctors_article_entry_class; ?>">
							<?php the_excerpt(); ?>
						</div><!--/.ourdoctors-article-entry-->

						<?php
						if ( $doctors_facebook || $doctors_twitter || $doctors_googleplus || $doctors_linkedin ) { ?>

							<div class="ourdoctors-article-socials">
								<?php
								if ( $doctors_facebook ) {
									echo '<a href="'. $doctors_facebook .'" title="'. __( 'Facebook', 'ti' ) .'" target="_blank"><i class="fa fa-facebook"></i></a>';
								}

								if ( $doctors_twitter ) {
									echo '<a href="'. $doctors_twitter .'" title="'. __( 'Twitter', 'ti' ) .'" target="_blank"><i class="fa fa-twitter"></i></a>';
								}

								if ( $doctors_googleplus ) {
									echo '<a href="'. $doctors_googleplus .'" title="'. __( 'Google+', 'ti' ) .'" target="_blank"><i class="fa fa-google-plus"></i></a>';
								}

								if ( $doctors_linkedin ) {
									echo '<a href="'. $doctors_linkedin .'" title="'. __( 'LinkedIn', 'ti' ) .'" target="_blank"><i class="fa fa-linkedin"></i></a>';
								}
								?>

							</div><!--/.ourdoctors-article-socials-->

						<?php }
						?>

					</div><!--/.ourdoctors-article-->

				<?php }
			} else {
				_e( 'No posts found.', 'ti' );
			}
			wp_reset_postdata();
			?>

		</div><!--/.ourdoctors-articles.cf-->
	</div><!--/#ourdoctors-->
</div><!--/.wrap-->
<?php get_footer(); ?>