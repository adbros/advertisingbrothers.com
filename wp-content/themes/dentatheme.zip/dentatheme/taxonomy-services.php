<?php
/**
 *	The template for displaying Taxonomy Services.
 *
 *	@package 9Pixels.
 */
get_header();
?>
<?php
if ( get_theme_mod( 'ti_servicespage_image' ) ) {
	$servicespage_image = get_theme_mod( 'ti_servicespage_image' );
} else {
	$servicespage_image = get_template_directory_uri() . '/images/services-image.png';
}
?>
<div id="services-title" style="background-image: url(<?php echo $servicespage_image; ?>);">
	<div class="service-title-color">
	</div><!--/.service-title-color-->
	<div class="wrap wrap-position-relative">
		<?php
		if ( get_theme_mod( 'ti_servicespage_title' ) ) {
			echo get_theme_mod( 'ti_servicespage_title' );
		} else {
			_e( 'Our Services', 'ti' );
		}
		?>
	</div><!--/.wrap.wrap-position-relative-->
</div><!--/#services-title-->
<div class="wrap">
	<div id="services" class="cf">
		<div class="services-left">
			<div class="services-title">
				<?php
				$taxonomy_services = $wp_query->queried_object;
				echo $taxonomy_services->name;
				?>
			</div>
			<div class="services-left-entry">
				<?php
				$taxonomy_services = $wp_query->queried_object;
				$taxonomy_services_description = $taxonomy_services->description;
				$taxonomy_services_name = $taxonomy_services->name;

				if ( $taxonomy_services_description ) {
					echo '<p>'. $taxonomy_services_description .'</p>';
				} else {
					echo '<p>'. __( 'To edit this content, go to Dashboard - Doctors - Services - ', 'ti' ) . $taxonomy_services_name . __( ' - Description.', 'ti' ) .'</p>';
				}
				?>
			</div><!--/.services-left-entry-->
		</div><!--/.services-left-->
		<div class="services-right">
			<div class="services-title">
				<?php
				if ( get_theme_mod( 'ti_servicespage_sidebartitle' ) ) {
					echo get_theme_mod( 'ti_servicespage_sidebartitle' );
				} else {
					_e( 'Featured', 'ti' );
				}
				?>
			</div><!--/.services-title-->

			<?php

			if ( $wp_query->have_posts() ) {
				while ( $wp_query->have_posts() ) {
					$wp_query->the_post();
					$featured_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'single-post-thumbnail' ); ?>

					<div class="services-right-article">
						<?php
						if ( $featured_image ) {
							echo '<div class="services-article-image" style="background-image: url('. $featured_image[0] .');"></div>';
						}
						?>
						<div class="services-article-title">
							<?php the_title(); ?>
						</div><!--/.services-article-title-->
						<div class="services-article-entry">
							<?php the_content(); ?>
						</div><!--/.services-article-entry-->
					</div><!--/.services-right-article-->

				<?php }
			} else {
				_e( 'No posts found.', 'ti' );
			}
			?>

		</div><!--/.services-right-->
	</div><!--/#services .cf-->
</div><!--/.wrap-->
<?php get_footer(); ?>