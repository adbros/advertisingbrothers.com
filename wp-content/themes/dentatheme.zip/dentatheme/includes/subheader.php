<?php
/**
 *	The template for displaying Subheader.
 *
 *	@package ThemeIsle.
 */

global $subheader_form_class;
global $subheader_class;

if ( ( get_theme_mod( 'ti_subheader_contactform7title' ) && get_theme_mod( 'ti_subheader_contactform7shortcode' ) ) == NULL ) {
	$subheader_class = 'class="no-subheader-form"';
}

if ( get_theme_mod( 'ti_subheader_title' ) == NULL ) {
	$subheader_form_class = 'class="no-subheader-entry"';
}

if ( get_theme_mod( 'ti_subheader_title' ) ) { ?>

	<section id="subheader" <?php echo $subheader_class; ?>>
		<div class="subheader-center cf">
			<div class="subheader-content">
				<?php
				if ( get_theme_mod( 'ti_subheader_title' ) ) {
					echo '<h3>'. get_theme_mod( 'ti_subheader_title' ) .'</h3>';
				}

				if ( get_theme_mod( 'ti_subheader_entry' ) ) {
					echo '<p>'. get_theme_mod( 'ti_subheader_entry' ) .'</p>';
				}

				if ( get_theme_mod( 'ti_subheader_buttonlink' ) ) {

					if ( get_theme_mod( 'ti_subheader_buttontext' ) ) {
						echo '<a href="'. get_theme_mod( 'ti_subheader_buttonlink' ) .'" title="'. get_theme_mod( 'ti_subheader_buttontext' ) .'" class="subheader-content-more">'. get_theme_mod( 'ti_subheader_buttontext' ) .'</a>';
					} else {
						echo '<a href="'. get_theme_mod( 'ti_subheader_buttonlink' ) .'" title="'. __( 'Read More', 'ti' ) .'" class="subheader-content-more">'. __( 'Read More', 'ti' ) .'</a>';
					}

				} else {
					echo '<div class="no-subheader-content-more"></div>';
				}
				?>
			</div><!--/.subheader-content-->
			<?php
			if ( get_theme_mod( 'ti_subheader_image' ) ) {
				echo '<img src="'. get_theme_mod( 'ti_subheader_image' ) .'" alt="'. get_bloginfo('name') .'" title="'. get_bloginfo('name') .'" class="subheader-image" />';
			} else {
				echo '<img src="'. get_template_directory_uri() .'/images/featured-image.png" alt="'. get_bloginfo('name') .'" title="'. get_bloginfo('name') .'" class="subheader-image" />';
			}
			?>
		</div><!--/.subheader-center.cf-->
	</section><!--/#subheader-->

<?php }
?>

<?php
if ( get_theme_mod( 'ti_subheader_contactform7title' ) && get_theme_mod( 'ti_subheader_contactform7shortcode' ) ) { ?>

	<div class="wrap cf">
		<section id="subheader-form" <?php echo $subheader_form_class; ?>>
			<div class="subheader-form-center">
				<?php
				if ( get_theme_mod( 'ti_subheader_contactform7title' ) ) {
					echo '<h4>'. get_theme_mod( 'ti_subheader_contactform7title' ) .'</h4>';
				}
				?>
				<?php echo do_shortcode( get_theme_mod( 'ti_subheader_contactform7shortcode' ) ); ?>
			</div><!--/.subheader-form-center-->
		</section><!--/#subheader-form-->
	</div><!--/.wrap.cf-->

<?php }
?>