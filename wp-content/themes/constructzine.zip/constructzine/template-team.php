<?php

/*
* 	Template Name: Our Team
*/

get_header();

?>
<div id="main-content">
	<div class="inner cf">
		<div class="blog-left  ti-cl-full-width">
			<article class="single-margin-top">
			<h1 class="post-title"><?php the_title(); ?></h1>
			<div class="our-team-description">
			<?php while ( have_posts() ) {
					the_post(); ?>
					<p><?php the_content();?></p>
			<?php } ?>
			</div>
			<ul class="full_team">
			<?php
					$args = array (
						'post_type'              => 'team_members',
					);
					
					$wp_query = new WP_Query( $args );
					$i = 0;
					if ( $wp_query->have_posts() ) {
						while ( $wp_query->have_posts() ) {
							$wp_query->the_post();
							
							$thumb_url = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
							$team_member_name = get_the_title();
							$team_member_position = get_post_meta($post->ID, 'ti_member_position', true);
							$team_member_description = get_the_content();
							$team_member_facebook = get_post_meta($post->ID, 'ti_member_social_facebook', true);
							$team_member_twitter = get_post_meta($post->ID, 'ti_member_social_twitter', true);
							$team_member_linkedin = get_post_meta($post->ID, 'ti_member_social_linkedin', true);
							$team_member_blog = get_post_meta($post->ID, 'ti_member_social_blog', true);
							
			?>
			
			<li class="team-member">
				<p class="member-link">
					<a href="<?php the_permalink();?>">
						<img src="<?php if(!empty($thumb_url)) echo $thumb_url;?>">
					</a>
				</p>
				<div class="team-member-description">
					<h3><a  href="<?php the_permalink();?>"><?php if(!empty($team_member_name)) echo $team_member_name;?></a></h3>
					<p class="worker-position" style="color:#000000"><?php if(!empty($team_member_position)) echo $team_member_position ?></p>
				</div>
				<div class="worker-description">
					<p>
						<?php 
						if (strlen($team_member_description) > 200) {
							$stringCut = substr($team_member_description, 0, 200);
							echo $stringCut;
						}else
							echo $team_member_description;
						?>
					</p>
				</div>
				<div class="socials-line">
					<ul class="team-member-socials">
						<?php if(!empty($team_member_facebook)){?>
						<li><a class="team-member-facebook" href="<?php echo $team_member_facebook; ?>" title="facebook"></a></li>
						<?php }?>
						<?php if(!empty($team_member_twitter)){?>
						<li><a class="team-member-twitter" href="<?php echo $team_member_twitter; ?>" title="twitter"></a></li>
						<?php }?>
						<?php if(!empty($team_member_linkedin)){?>
						<li><a class="team-member-linkedin" href="<?php echo $team_member_linkedin; ?>" title="linkedin"></a></li>
						<?php }?>
						<?php if(!empty($team_member_blog)){?>
						<li><a class="team-member-blog" href="<?php echo $team_member_blog; ?>" title="blog"></a></li>
						<?php }?>
					</ul>
				</div>
			</li>
			
			
			<?php
						}
			?>
			</ul>
			<?php
					}else{
					
					}
				
				wp_reset_postdata();
			?>
						
			</article><!--/article-->
		</div><!--/.blog-left-->
	</div>
</div>

<?php get_footer(); ?>