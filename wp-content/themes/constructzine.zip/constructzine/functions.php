<?php
/*
*	Includes Files
*/
require_once ( 'includes/custom-functions.php' );
require_once ( 'includes/custom-widgets.php' );
require_once ( 'includes/metaboxes/example-functions.php' );
require_once ( 'includes/customizer.php' );

/*
*	Content Width
*/
if ( ! isset( $content_width ) ) $content_width = 634;

/*
*	Constructzine Style
*/
function constructzine_style() {
	wp_enqueue_style( 'style', get_stylesheet_uri(), array(), '1.0', false );
	wp_enqueue_style( 'fancybox', get_template_directory_uri() . '/css/jquery.fancybox.css', array(), '1.0' );
	if ( is_singular() ) wp_enqueue_script( "comment-reply" );
}

add_action( 'wp_enqueue_scripts', 'constructzine_style' );

/*
*	WP Enqueue Script Constructzine
*/
function constructzine_script() {
    wp_enqueue_script( 'jquery');
    wp_enqueue_script( 'carouFredSel', get_template_directory_uri() . '/js/jquery.carouFredSel-6.2.1-packed.js', array( 'jquery' ), '6.2.1', true );
    wp_enqueue_script( 'fancybox', get_template_directory_uri() . '/js/jquery.fancybox.js', array( 'jquery' ), '1.0', true );
    wp_enqueue_script( 'masonry', get_template_directory_uri() . '/js/jquery.masonry.js', array( 'jquery' ), '1.0', true );
    wp_enqueue_script( 'custom', get_template_directory_uri() . '/js/custom.js', array( 'jquery' ), '1.0', true );
}

add_action( 'wp_enqueue_scripts', 'constructzine_script' );

/*
*	Post Thumbnails
*/
add_theme_support( 'post-thumbnails' );

/*
*	Automatic Feed Links
*/
add_theme_support( 'automatic-feed-links' );

/*
*	Custom Header
*/
$args = array(
	'default-image'          => get_template_directory_uri() . '/images/header.png',
	'random-default'         => false,
	'width'                  => 1903,
	'height'                 => 720,
	'flex-height'            => false,
	'flex-width'             => false,
	'default-text-color'     => '',
	'header-text'            => false,
	'uploads'                => true,
	'wp-head-callback'       => '',
	'admin-head-callback'    => '',
	'admin-preview-callback' => '',
);
add_theme_support( 'custom-header', $args );

/*
*	Navigation Menu
*/
function navigation_menu() {

	$locations = array(
		'top-menu' => __( 'Top Header', 'ti' ),
	);
	register_nav_menus( $locations );

}

add_action( 'init', 'navigation_menu' );

/*
*	General Sidebar
*/
function general_sidebar() {

	$args = array(
		'id'            => 'general_sidebar',
		'name'          => __( 'General Sidebar', 'ti' ),
		'description'   => __( 'This sidebar will appear in blog page.', 'ti' ),
		'before_title'  => '<div class="widget-title">',
		'after_title'   => '</div>',
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget'  => '</div>',
	);
	register_sidebar( $args );

}

add_action( 'widgets_init', 'general_sidebar' );

/*
*	Custom Post Type: Services
*/
function custom_post_type_services() {

	$labels = array(
		'name'                => _x( 'Services', 'Post Type General Name', 'ti' ),
		'singular_name'       => _x( 'Service', 'Post Type Singular Name', 'ti' ),
		'menu_name'           => __( 'Services', 'ti' ),
		'parent_item_colon'   => __( 'Parent Service:', 'ti' ),
		'all_items'           => __( 'All Services', 'ti' ),
		'view_item'           => __( 'View Service', 'ti' ),
		'add_new_item'        => __( 'Add New Service', 'ti' ),
		'add_new'             => __( 'Add New', 'ti' ),
		'edit_item'           => __( 'Edit Service', 'ti' ),
		'update_item'         => __( 'Update Service', 'ti' ),
		'search_items'        => __( 'Search Service', 'ti' ),
		'not_found'           => __( 'Not found', 'ti' ),
		'not_found_in_trash'  => __( 'Not found in Trash', 'ti' ),
	);
	$args = array(
		'label'               => __( 'services', 'ti' ),
		'description'         => __( 'Add the content about your services', 'ti' ),
		'labels'              => $labels,
		'supports'            => array( 'title', 'editor', 'custom-fields', ),
		'taxonomies'          => array(),
		'hierarchical'        => false,
		'public'              => true,
		'show_ui'             => true,
		'show_in_menu'        => true,
		'show_in_nav_menus'   => true,
		'show_in_admin_bar'   => true,
		'menu_position'       => 5,
		'can_export'          => true,
		'has_archive'         => true,
		'exclude_from_search' => false,
		'publicly_queryable'  => true,
		'capability_type'     => 'page',
		'menu_icon'			  => 'dashicons-portfolio'
	);
	register_post_type( 'services', $args );

}

add_action( 'init', 'custom_post_type_services', 0 );

/*
*	Custom Post Type: Testimonials
*/
function custom_post_type_testimonials() {

	$labels = array(
		'name'                => _x( 'Testimonials', 'Post Type General Name', 'ti' ),
		'singular_name'       => _x( 'Testimonial', 'Post Type Singular Name', 'ti' ),
		'menu_name'           => __( 'Testimonial', 'ti' ),
		'parent_item_colon'   => __( 'Parent Testimonial:', 'ti' ),
		'all_items'           => __( 'All Testimonials', 'ti' ),
		'view_item'           => __( 'View Testimonial', 'ti' ),
		'add_new_item'        => __( 'Add New Testimonial', 'ti' ),
		'add_new'             => __( 'Add New', 'ti' ),
		'edit_item'           => __( 'Edit Testimonial', 'ti' ),
		'update_item'         => __( 'Update Testimonial', 'ti' ),
		'search_items'        => __( 'Search Testimonial', 'ti' ),
		'not_found'           => __( 'Not found', 'ti' ),
		'not_found_in_trash'  => __( 'Not found in Trash', 'ti' ),
	);
	$args = array(
		'label'               => __( 'testimonials', 'ti' ),
		'description'         => __( 'Add the content about your services', 'ti' ),
		'labels'              => $labels,
		'supports'            => array( 'title', 'editor', 'custom-fields', ),
		'taxonomies'          => array(),
		'hierarchical'        => false,
		'public'              => true,
		'show_ui'             => true,
		'show_in_menu'        => true,
		'show_in_nav_menus'   => true,
		'show_in_admin_bar'   => true,
		'menu_position'       => 5,
		'can_export'          => true,
		'has_archive'         => true,
		'exclude_from_search' => false,
		'publicly_queryable'  => true,
		'capability_type'     => 'page',
		'menu_icon'			  => 'dashicons-admin-users'
	);
	register_post_type( 'testimonials', $args );

}

add_action( 'init', 'custom_post_type_testimonials', 0 );/**	Custom Post Type: Team Members*/function custom_post_type_team_members() {	$labels = array(		'name'                => _x( 'Team Members', 'Post Type General Name', 'ti' ),		'singular_name'       => _x( 'Team Member', 'Post Type Singular Name', 'ti' ),		'menu_name'           => __( 'Team Members', 'ti' ),		'parent_item_colon'   => __( 'Parent Team Members:', 'ti' ),		'all_items'           => __( 'All Team Members', 'ti' ),		'view_item'           => __( 'View Team Members', 'ti' ),		'add_new_item'        => __( 'Add New Team Member', 'ti' ),		'add_new'             => __( 'Add New', 'ti' ),		'edit_item'           => __( 'Edit Team Member', 'ti' ),		'update_item'         => __( 'Update Team Member', 'ti' ),		'search_items'        => __( 'Search Team Member', 'ti' ),		'not_found'           => __( 'Not found', 'ti' ),		'not_found_in_trash'  => __( 'Not found in Trash', 'ti' ),	);	$args = array(		'label'               => __( 'team_members', 'ti' ),		'description'         => __( 'Add the content about your services', 'ti' ),		'labels'              => $labels,		'supports'            => array( 'title', 'editor', 'custom-fields','thumbnail' ),		'taxonomies'          => array(),		'hierarchical'        => false,		'public'              => true,		'show_ui'             => true,		'show_in_menu'        => true,		'show_in_nav_menus'   => true,		'show_in_admin_bar'   => true,		'menu_position'       => 5,		'can_export'          => true,		'has_archive'         => true,		'exclude_from_search' => false,		'publicly_queryable'  => true,		'capability_type'     => 'page',		'menu_icon'			  => 'dashicons-admin-users'	);	register_post_type( 'team_members', $args );}add_action( 'init', 'custom_post_type_team_members', 0 );add_action('wp_print_scripts','constructzine_php_style');function constructzine_php_style() {	echo ' <style type="text/css">';		/* Footer section colors */		echo '	footer.cf { background: '. get_theme_mod('constructzine_footer_background') .' }';		echo '	.about-us p { color: '. get_theme_mod('constructzine_footer_text') .' }';		echo '	.contact-us p { color: '. get_theme_mod('constructzine_footer_text') .' }';		echo '	.about-us h3 { color: '. get_theme_mod('constructzine_footer_title') .' }';		echo '	.contact-us h3 { color: '. get_theme_mod('constructzine_footer_title') .' }';		echo '	.directions h3 { color: '. get_theme_mod('constructzine_footer_title') .' }';		/* General section colors */		echo '  .wpcf7-form input[type="submit"]  { background: '. get_theme_mod('constructzine_general_submit') .' }';		echo '  .blog-left article .post-title  { color: '. get_theme_mod('constructzine_post_title') .' }';	    echo '  .blog-left .post-entry p  { color: '. get_theme_mod('constructzine_post_text') .' }';		echo '  .sidebar .widget .widget-title  { color: '. get_theme_mod('constructzine_sidebar_title_color') .' }';		echo '  .sidebar .widget ul li a, .sidebar .widget ul li   { color: '. get_theme_mod('constructzine_sidebar_text_color') .' }';		/* Menu section color */		echo '  ul.navigation-socials { background: '. get_theme_mod('constructzine_ribbon_color') .' }';		echo '  .team-member-socials li a { background-color: '. get_theme_mod('constructzine_team_socials') .' }';		echo '  .team-member-socials li a:hover { background-color: '. get_theme_mod('constructzine_team_socials_hover') .' }';		echo '  .member-link img { border-color: '. get_theme_mod('constructzine_team_picture_border') .' }';		echo '</style>';};add_action('after_setup_theme', 'mytheme_setup');function mytheme_setup(){	$post = get_posts('post_type=team_members');		// Include image.php	require_once(ABSPATH . 'wp-admin/includes/image.php');	$func_array = array(__('Founder','ti'),__('Worker','ti'),__('Architect','ti'));				if (isset($_GET['activated']) && is_admin() && empty($post)){			/*Remove duplicate photos*/		global $wpdb;		$args = array(			'post_type'         => 'attachment',			'post_status'       => 'published',			'posts_per_page'    => -1,			'post_content'   => 'default_pic',		);				$attachments = new WP_Query($args);		$attachment_ids = array();		if($attachments->have_posts()) : while($attachments->have_posts()) : $attachments->the_post();				$attachment_ids[] = get_the_id();			endwhile;		endif;		wp_reset_postdata();				if(!empty($attachment_ids)) :			$delete_attachments_query = $wpdb->prepare('DELETE FROM %1$s WHERE %1$s.ID IN (%2$s)', $wpdb->posts, join(',', $attachment_ids));			$wpdb->query($delete_attachments_query);		endif;				$i=0;		$default_posts = array(			array(			  'post_title'    => 'Johnny Sims',			  'post_content'  => __('Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce hendrerit eget est sit amet rhoncus. Mauris mi sapien, porttitor ut pellentesque vitae, accumsan molestie nunc. Aenean pulvinar laoreet sem gravida vulputate.','ti'),			  'post_status'   => 'publish',			  'post_author'   => 1,			  'post_type'      => 'team_members'			),			array(			  'post_title'    => 'Timothy Spray',			  'post_content'  => __('Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce hendrerit eget est sit amet rhoncus. Mauris mi sapien, porttitor ut pellentesque vitae, accumsan molestie nunc. Aenean pulvinar laoreet sem gravida vulputate.','ti'),			  'post_status'   => 'publish',			  'post_author'   => 1,			  'post_type'      => 'team_members'			),			array(			  'post_title'    => 'Tonya Garcia',			  'post_content'  => __('Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce hendrerit eget est sit amet rhoncus. Mauris mi sapien, porttitor ut pellentesque vitae, accumsan molestie nunc. Aenean pulvinar laoreet sem gravida vulputate.','ti'),			  'post_status'   => 'publish',			  'post_author'   => 1,			  'post_type'      => 'team_members'			)		);				$upload_dir = wp_upload_dir(); // Set upload folder		foreach ($default_posts as $member) {					$i++;			$member_id = wp_insert_post( $member );			$image_url  = get_template_directory_uri().'/images/default'.$i.'.jpg'; // Define the image URL here			$image_data = file_get_contents($image_url); // Get image data			$filename   = basename($image_url); // Create image file name									// Check folder permission and define file location			if( wp_mkdir_p( $upload_dir['path'] ) ) {				$file = $upload_dir['path'] . '/' . $filename;			} else {				$file = $upload_dir['basedir'] . '/' . $filename;			}									// Create the image  file on the server			file_put_contents( $file, $image_data );						// Check image file type			$wp_filetype = wp_check_filetype( $filename, null );						// Set attachment data			$attachment = array(				'post_mime_type' => $wp_filetype['type'],				'post_title'     => sanitize_file_name( $filename ),				'post_content'   => 'default_pic',				'post_status'    => 'inherit'			);						// Create the attachment			$attach_id = wp_insert_attachment( $attachment, $file, $member_id );						// Define attachment metadata			$attach_data = wp_generate_attachment_metadata( $attach_id, $file );			// Assign metadata to attachment			wp_update_attachment_metadata( $attach_id, $attach_data );			// And finally assign featured image to post			set_post_thumbnail( $member_id, $attach_id );						add_post_meta($member_id, 'ti_member_position', $func_array[$i-1], false);			add_post_meta($member_id, 'ti_member_social_facebook', '#', false);			add_post_meta($member_id, 'ti_member_social_twitter', '#', false);			add_post_meta($member_id, 'ti_member_social_linkedin', '#', false);			add_post_meta($member_id, 'ti_member_social_blog', '#', false);		}	}}

 require 'inc/cwp-update.php'; 

