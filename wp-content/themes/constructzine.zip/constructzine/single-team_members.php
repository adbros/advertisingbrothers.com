<?php
get_header();
?>
<div id="main-content">
	<div class="inner cf">
		<div class="blog-left  ti-cl-full-width">
			<article class="single-margin-top">
			<?php
			while ( have_posts() ) {
				the_post(); 
			?>
			<h1 class="post-title"><?php the_title(); ?></h1>
			<div class="member-single-photo">
				<?php
					$thumb_url = wp_get_attachment_url( get_post_thumbnail_id() );
					$team_member_facebook = get_post_meta($post->ID, 'ti_member_social_facebook', true);
					$team_member_twitter = get_post_meta($post->ID, 'ti_member_social_twitter', true);
					$team_member_linkedin = get_post_meta($post->ID, 'ti_member_social_linkedin', true);
					$team_member_blog = get_post_meta($post->ID, 'ti_member_social_blog', true);					
				?>
				<?php if(!empty($thumb_url)) {?>
				<img src="<?php echo $thumb_url;?>"></img>
				<?php } ?>
				<div class="social-contact">
					<ul class="team-member-socials">
						<?php if(!empty($team_member_facebook)){?>
						<li><a class="team-member-facebook" href="<?php echo $team_member_facebook; ?>" title="facebook"></a></li>
						<?php }?>
						<?php if(!empty($team_member_twitter)){?>
						<li><a class="team-member-twitter" href="<?php echo $team_member_twitter; ?>" title="twitter"></a></li>
						<?php }?>
						<?php if(!empty($team_member_linkedin)){?>
						<li><a class="team-member-linkedin" href="<?php echo $team_member_linkedin; ?>" title="linkedin"></a></li>
						<?php }?>
						<?php if(!empty($team_member_blog)){?>
						<li><a class="team-member-blog" href="<?php echo $team_member_blog; ?>" title="blog"></a></li>
						<?php }?>
					</ul>
				</div>
			</div>
			<div class="member-single-full-description"><?php the_content();?></div>
		<?php
			}
		?>
			</div>
		</div><!--/.blog-left-->
	</div>
</div>
<?php get_footer(); ?>