

### 1.0.1 - 06/02/2015

 Changes: 


 * Customizer

Added custom colors
Added link in footer
 * Merge pull request #2 from DragosBubu/development

Customizer
 * this fixes #9
 * this fixes #15
 * this fixes #12 and some style issues
 * this fixes #17
 * this fixes #17
 * this fixes #16
 * this fixes #17
 * this fixes #13
 * this fixes #11
 * Larger font size for box, left align in sidebar
 * this fixes #8
 * this fixes #3
 * Merge pull request #18 from cristian-ungureanu/development

Development
 * this fixes #17
 * this fixes #12
 * Merge pull request #24 from cristian-ungureanu/development

this fixes #17
 * this fixes #17 - navigation menu responsive and responsive menu
 * this fixes #25 - invalid form display bug
 * this fixes #25 - nb 2 firefox issue
 * Merge pull request #26 from cristian-ungureanu/development

this fixes #17 - navigation menu responsive and responsive menu
 * this fixes #7 - our team template + responsive + wordpress + custom colors
 * this fixes #7 - fatal error fix + social links fix
 * Merge pull request #27 from cristian-ungureanu/development

this fixes #7 - our team template + responsive + wordpress + custom colo...
 * this fixes #29 - add colors panel
 * this fixes #36 - move our team in colors panel
 * this fixes #30 - conditional our team colors
 * this fixes #33 - rename contact in customizer and add conditional display
 * this fixes #33 - rename frontpage in customizer + change text domain in customizer from constructzine to ti
 * this fixes #34 -item order in customizer menu
 * this fixes #35 - add our clients area on homepage and add default posts to our team cpt on theme activation
 * this fixes #38 - add our team section in frontpage panel in customizer and make our team options customizable
 * this fixes #39 - conditional frontpage in customizer
 * Merge pull request #37 from cristian-ungureanu/development

Development
 * this fixes #40
 * Merge pull request #41 from cristian-ungureanu/development

this fixes #40


### 1.0 - 17/10/2014

 Changes: 


 * Theme first version
