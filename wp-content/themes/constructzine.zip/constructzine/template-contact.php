<?php
/** 	Template Name: Contact*/
get_header();
?>
<div id="main-content">
	<div class="inner cf">
		<?php
		if ( have_posts() ) {
			while ( have_posts() ) {
				the_post(); ?>
				<div class="blog-left">
					<div class="blog-left-title">
						<?php the_title(); ?>
					</div><!--/.blog-left-title-->
					<article>
						<div class="post-entry">
							<?php the_content(); ?>
						</div><!--/.post-entry-->
					</article>
				</div><!--/.blog-left-->
			<?php }
		} else {
			echo __( 'No posts found', 'ti' );
		}
		?>
		<div class="sidebar">
			<div class="widget">
				<div class="widget-title">
					<?php
					if ( get_theme_mod( 'ti_contact_contactus_title',__( 'Contact us', 'ti' )) != NULL )
						echo get_theme_mod( 'ti_contact_contactus_title',__( 'Contact us', 'ti' ) );
					?>
				</div><!--/.widget-title-->
				<?php
				if ( get_theme_mod( 'ti_contact_contactus_content',__( 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco labo ris nisi ut aliquip ex ea commodo consequat.', 'ti' ) ) != NULL )
					echo get_theme_mod( 'ti_contact_contactus_content',__( 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco labo ris nisi ut aliquip ex ea commodo consequat.', 'ti' ) );
				?>
			</div><!--/.widget-->
			<div class="widget">
				<?php
				if ( get_theme_mod( 'ti_footer_map_iframe','<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d48393.71012617254!2d-74.0047826738297!3d40.704654807499544!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c24fa5d33f083b%3A0xc80b8f06e177fe62!2sNew+York!5e0!3m2!1sro!2sro!4v1403183009785" width="600" height="450" frameborder="0" style="border:0"></iframe>' ) != NULL )
					echo get_theme_mod( 'ti_footer_map_iframe','<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d48393.71012617254!2d-74.0047826738297!3d40.704654807499544!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c24fa5d33f083b%3A0xc80b8f06e177fe62!2sNew+York!5e0!3m2!1sro!2sro!4v1403183009785" width="600" height="450" frameborder="0" style="border:0"></iframe>');
				?>
				<div class="iframe-mask"></div><!--/.iframe-mask-->
			</div><!--/.widget-->
			<div class="widget">
				<?php
					if ( get_theme_mod( 'ti_contact_phone','0 333 758 985' ) ) {
						echo __( 'Phone: ', 'ti' );
						echo '<a href="tel:'. get_theme_mod( 'ti_contact_phone','0 333 758 985' ) .'" title="'. get_theme_mod( 'ti_contact_phone','0 333 758 985' ) .'">'. get_theme_mod( 'ti_contact_phone','0 333 758 985' ) .'</a>';
					}
				?>				
				<br />				
				<?php
					if ( get_theme_mod( 'ti_contact_website',get_template_directory_uri() ) != NULL ) {
						echo __( 'Website: ', 'ti' );
						echo '<a href="'. get_theme_mod( 'ti_contact_website',get_template_directory_uri() ) .'" title="'. get_theme_mod( 'ti_contact_website',get_template_directory_uri() ) .'">'. get_theme_mod( 'ti_contact_website',get_template_directory_uri() ) .'</a>';
					}
				?>
				<br />
				<?php
					if ( get_theme_mod( 'ti_contact_email','contact@constructzine.com' ) != NULL ) {
						echo __( 'E-mail: ', 'ti' );
						echo __( '<a href="mailto:'. get_theme_mod( 'ti_contact_email','contact@constructzine.com' ) .'" title="'. get_theme_mod( 'ti_contact_email','contact@constructzine.com' ) .'">'. get_theme_mod( 'ti_contact_email','contact@constructzine.com' ) .'</a>', 'ti' );
					}
				?>
			</div><!--/.widget-->
		</div><!--/.sidebar-->
	</div>
</div>
<?php get_footer(); ?>