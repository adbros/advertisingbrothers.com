<?php

/**
 *  Prev Posts Link Class
 */
function ti_prev_posts_link_class() {
    return 'class="nav-left"';
}
add_filter('next_posts_link_attributes', 'ti_prev_posts_link_class');

/**
 *  Next Posts Link Class
 */
function ti_next_posts_link_class() {
    return 'class="nav-right"';
}
add_filter('previous_posts_link_attributes', 'ti_next_posts_link_class');

/**
 *  RoProfit Gallery
 */
add_filter('post_gallery', 'ti_roprofit_gallery', 10, 2);
function ti_roprofit_gallery($output, $attr) {
    global $post;

    if (isset($attr['orderby'])) {
        $attr['orderby'] = sanitize_sql_orderby($attr['orderby']);
        if (!$attr['orderby'])
            unset($attr['orderby']);
    }

    extract(shortcode_atts(array(
        'order' => 'ASC',
        'orderby' => 'menu_order ID',
        'id' => $post->ID,
        'itemtag' => 'dl',
        'icontag' => 'dt',
        'captiontag' => 'dd',
        'columns' => 3,
        'size' => 'thumbnail',
        'include' => '',
        'exclude' => ''
    ), $attr));

    $id = intval($id);
    if ('RAND' == $order) $orderby = 'none';

    if (!empty($include)) {
        $include = preg_replace('/[^0-9,]+/', '', $include);
        $_attachments = get_posts(array('include' => $include, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $order, 'orderby' => $orderby));

        $attachments = array();
        foreach ($_attachments as $key => $val) {
            $attachments[$val->ID] = $_attachments[$key];
        }
    }

    if (empty($attachments)) return '';
    // Here's your actual output, you may customize it to your need
    $output = "<div id='custom-gallery gallery-". $post->ID ."' class='gallery galleryid-". $post->ID ." gallery-columns-". $columns ."'>\n";

    // Now you loop through each attachment
    foreach ($attachments as $id => $attachment) {
        // Fetch the thumbnail (or full image, it's up to you)
//      $img = wp_get_attachment_image_src($id, 'medium');
//      $img = wp_get_attachment_image_src($id, 'my-custom-image-size');
        $img = wp_get_attachment_image_src($id, 'full');

        $output .= "<dl class='gallery-item gallery-columns-". $columns ."'>";
        $output .= "<a href=\"{$img[0]}\" rel='post-". $post->ID ."' class=\"fancybox\" title='". $attachment->post_excerpt ."'>\n";
        $output .= "<div class='gallery-item-thumb'><img src=\"{$img[0]}\" alt='". $attachment->post_excerpt ."' /></div>\n";
        $output .= "<div class='wp-caption-text'>";
        $output .= $attachment->post_excerpt;
        $output .= "</div>";
        $output .= "</a>\n";
        $output .= "</dl>";
    }

    $output .= "</div>\n";

    return $output;
}

/**
 *  Comments
 */
if ( ! function_exists( 'comments' ) ) :

function comments( $comment, $args, $depth ) {
    $GLOBALS['comment'] = $comment;
    switch ( $comment->comment_type ) :
        case 'pingback' :
        case 'trackback' :
    ?>
    <li class="post pingback">
        <p><?php _e( 'Pingback:', 'ti' ); ?> <?php comment_author_link(); ?><?php edit_comment_link( __( '(Edit)', 'ti' ), ' ' ); ?></p>
    <?php
            break;
        default :
    ?>
    <li <?php comment_class(); ?> id="li-comment-<?php comment_ID(); ?>">
        <article id="comment-<?php comment_ID(); ?>" class="comment cf">
            <div class="author-gravatar">
                <?php echo get_avatar( $comment, 72 ); ?>
                <?php comment_reply_link( array_merge( $args, array( 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?>
            </div><!--/.author-gravatar-->
            <div class="comment-right">
                <div class="comment-right-head">
                    <?php printf( __( '%s', 'ti' ), sprintf( '%s', get_comment_author_link() ) ); ?> <?php _e( '-', 'ti' ); ?>
                    <a href="<?php echo esc_url( get_comment_link( $comment->comment_ID ) ); ?>" class="comment-entry-head-date">
                        <time pubdate datetime="<?php comment_time( 'c' ); ?>">
                            <?php printf( __( '%1$s at %2$s', 'shape' ), get_comment_date(), get_comment_time() ); ?>
                        </time>
                    </a><!--/a .comment-entry-head-date-->
                    <?php edit_comment_link( __( 'Edit this comment', 'ti' ), '- ' ); ?>
                </div><!--/.comment-right-head-->
                <div class="comment-entry">
                    <?php comment_text(); ?>
                </div><!--/.comment-entry-->
                 <?php if ( $comment->comment_approved == '0' ) : ?>
                    <i class="awaiting-moderation cf"><?php _e( 'Your comment is awaiting moderation.', 'ti' ); ?></i><br />
                <?php endif; ?>
            </div><!--/.comment-right-->
        </article><!--/article-->

    <?php
            break;
    endswitch;
}
endif;

?>