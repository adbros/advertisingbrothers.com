<?php

function dentatheme_customizer( $wp_customize ) {
    $wp_customize->get_setting( 'blogname' )->transport = 'postMessage';
    $wp_customize->get_setting( 'blogdescription' )->transport = 'postMessage';
    $wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';
    $wp_customize->get_setting( 'background_color' )->transport = 'postMessage';

    /**
     *	General Settings
     */
    $wp_customize->add_section( 'general_settings' , array(
    	'title'       => __( 'General Settings', 'ti' ),
    	'priority'    => 200,
	) );

		/* Facebook - Link */
		$wp_customize->add_setting( 'ti_facebook_link' );
		$wp_customize->add_control( 'ti_facebook_link', array(
		    'label'    => __( 'Facebook - Link:', 'ti' ),
		    'section'  => 'general_settings',
		    'settings' => 'ti_facebook_link',
			'priority' => '1',
		) );

		/* Twitter - Link */
		$wp_customize->add_setting( 'ti_twitter_link' );
		$wp_customize->add_control( 'ti_twitter_link', array(
		    'label'    => __( 'Twitter - Link:', 'ti' ),
		    'section'  => 'general_settings',
		    'settings' => 'ti_twitter_link',
			'priority' => '2',
		) );

		/* Google+ - Link */
		$wp_customize->add_setting( 'ti_googleplus_link' );
		$wp_customize->add_control( 'ti_googleplus_link', array(
		    'label'    => __( 'Google+ - Link:', 'ti' ),
		    'section'  => 'general_settings',
		    'settings' => 'ti_googleplus_link',
			'priority' => '3',
		) );

		/* Logo - Image */
		$wp_customize->add_setting( 'ti_logo_image' );
		$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'ti_logo_image', array(
		    'label'    => __( 'Logo - Image:', 'ti' ),
		    'section'  => 'general_settings',
		    'settings' => 'ti_logo_image',
		    'priority' => '4',
		) ) );

		/* Footer - Copyright */
		$wp_customize->add_setting( 'ti_footer_copyright' );
		$wp_customize->add_control( new Example_Customize_Textarea_Control( $wp_customize, 'ti_footer_copyright', array(
		            'label' 	=> __( 'Footer - Copyright', 'ti' ),
		            'section' 	=> 'general_settings',
		            'settings' 	=> 'ti_footer_copyright',
		            'priority' 	=> '5'
		        )
		    )
		);

	$wp_customize->add_section( 'frontpage_settings' , array(
    	'title'       => __( 'Frontpage Settings', 'ti' ),
    	'priority'    => 250,
	) );

		/* Article - Title */
		$wp_customize->add_setting( 'ti_article_title' );
		$wp_customize->add_control( 'ti_article_title', array(
		    'label'    => __( 'Article - Title:', 'ti' ),
		    'section'  => 'frontpage_settings',
		    'settings' => 'ti_article_title',
			'priority' => '1',
		) );

		/* Article - Entry */
		$wp_customize->add_setting( 'ti_article_entry' );
		$wp_customize->add_control( new Example_Customize_Textarea_Control( $wp_customize, 'ti_article_entry', array(
		            'label' 	=> __( 'Article - Entry', 'ti' ),
		            'section' 	=> 'frontpage_settings',
		            'settings' 	=> 'ti_article_entry',
		            'priority' 	=> '2'
		        )
		    )
		);

		/* Products - Number of posts */
		$wp_customize->add_setting( 'ti_products_numberofposts' );
		$wp_customize->add_control( 'ti_products_numberofposts', array(
		    'label'    => __( 'Products - Number of posts:', 'ti' ),
		    'section'  => 'frontpage_settings',
		    'settings' => 'ti_products_numberofposts',
			'priority' => '3',
		) );

		/* Sidebar - Banner 300px X 300px */
		$wp_customize->add_setting( 'ti_sidebar_banner300pxx300px' );
		$wp_customize->add_control( new Example_Customize_Textarea_Control( $wp_customize, 'ti_sidebar_banner300pxx300px', array(
		            'label' 	=> __( 'Sidebar - Banner 300x300px:', 'ti' ),
		            'section' 	=> 'frontpage_settings',
		            'settings' 	=> 'ti_sidebar_banner300pxx300px',
		            'priority' 	=> '4'
		        )
		    )
		);

}
add_action( 'customize_register', 'dentatheme_customizer' );

if( class_exists( 'WP_Customize_Control' ) ):
	class Example_Customize_Textarea_Control extends WP_Customize_Control {
	    public $type = 'textarea';

	    public function render_content() { ?>

	        <label>
	        	<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
	        	<textarea rows="5" style="width:100%;" <?php $this->link(); ?>><?php echo esc_textarea( $this->value() ); ?></textarea>
	        </label>

	        <?php
	    }
	}
endif;

?>