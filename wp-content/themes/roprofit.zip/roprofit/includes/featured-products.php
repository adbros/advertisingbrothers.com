<?php
/**
 *	The template for displaying Featured Products.
 *
 *	@package ThemeIsle.
 */
?>
<section id="featured-products" class="cf">

	<?php

	$args = array (
		'post_type'				=> 'post',
		'posts_per_page'		=> '3',
		'ignore_sticky_posts'	=> true
	);

	$wp_query = new WP_Query( $args );

	if ( $wp_query->have_posts() ) {
		while ( $wp_query->have_posts() ) {
			$wp_query->the_post();
			$cwp_rev_product_image = get_post_meta($post->ID, "cwp_rev_product_image", true);
			$cwp_rev_price = get_post_meta($post->ID, "cwp_rev_price", true);
			$affiliate_text = get_post_meta($post->ID, "cwp_product_affiliate_text", true);
    		$affiliate_link = get_post_meta($post->ID, "cwp_product_affiliate_link", true); ?>

			<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
				<?php
				if ( $cwp_rev_product_image ) {
					echo '<div class="featured-product-image" style="background-image: url('. $cwp_rev_product_image .');"></div>';
				} else {
					echo '<div class="featured-product-image" style="background-image: url('. get_template_directory_uri() .'/images/no-image1.png);"></div>';
				}
				?>
				<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" class="featured-product-title">
					<?php the_title(); ?>
				</a><!--/a .featured-product-title-->
				<?php
				if ( $cwp_rev_price ) {
					echo '<span class="article-price">'. $cwp_rev_price .'</span>';
				}

				if ( !empty( $affiliate_text ) && !empty( $affiliate_link ) ) {
					echo '<div class="affiliate-button2 affiliate-button">';
					echo '<a href="'. $affiliate_link .'" rel="nofollow" target="_blank">';
					echo '<span>'. $affiliate_text .'</span>';
					echo '</a>';
					echo '</div>';
				}
				?>
			</article>

		<?php }
	} else {
		_e( 'No posts found.', 'ti' );
	}
	wp_reset_postdata();
	?>

</section><!--/#featured-products .cf-->