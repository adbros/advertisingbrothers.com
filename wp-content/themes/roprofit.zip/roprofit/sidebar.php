<?php
/**
 *	The template for displaying Sidebar.
 *
 *	@package ThemeIsle.
 */
?>
<aside class="sidebar-right">

	<?php
	if ( get_theme_mod( 'ti_sidebar_banner300pxx300px' ) ) {
		echo '<div class="sidebar-banner">';
		echo htmlspecialchars_decode( get_theme_mod( 'ti_sidebar_banner300pxx300px' ) );
		echo '</div>';
	}
	?>

	<?php
	if ( is_dynamic_sidebar( 'general_sidebar' ) ) {
		dynamic_sidebar( 'general_sidebar' );
	} else {

		$args = array(
			'title_li'	=> ''
		);

		echo '<div class="widget">';
		echo '<div class="widget-title">';
		echo __( 'Pages', 'ti' );
		echo '</div>';
		echo '<ul>';
		wp_list_pages( $args );
		echo '<ul>';
		echo '</div>';

	}
	?>

</aside><!--/aside .sidebar-right-->