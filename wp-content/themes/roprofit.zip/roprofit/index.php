<?php
/**
 *	The template for displaying Index.
 *
 *	@package ThemeIsle.
 */
get_header();
?>
<div class="wrapper cf">

	<?php get_template_part( 'includes/featured-products' ); ?>

	<div id="content" class="cf">
		<div class="content-left">
			<?php
			if ( get_theme_mod( 'ti_article_title' ) ) {
				echo '<div class="content-left-title content-left-title-frontpage">'. get_theme_mod( 'ti_article_title' ) .'</div>';
			}

			if ( get_theme_mod( 'ti_article_entry' ) ) {
				echo '<div class="content-left-entry content-left-entry-frontpage">'. get_theme_mod( 'ti_article_entry' ) .'</div>';
			}
			?>
			<div class="products-content cf">

				<?php

				$products_numberofposts = get_theme_mod( 'ti_products_numberofposts' );

				$args = array (
					'post_type'				=> 'post',
					'posts_per_page'		=> $products_numberofposts,
					'ignore_sticky_posts'	=> true,
					'paged'					=> $paged
				);

				$wp_query = new WP_Query( $args );

				if ( $wp_query->have_posts() ) {
					while ( $wp_query->have_posts() ) {
						$wp_query->the_post();
						$cwp_rev_product_image = get_post_meta($post->ID, "cwp_rev_product_image", true);
						$affiliate_text = get_post_meta($post->ID, "cwp_product_affiliate_text", true);
    					$affiliate_link = get_post_meta($post->ID, "cwp_product_affiliate_link", true);
						$option_1_grade = get_post_meta($post->ID, "option_1_grade", true);
						$option_2_grade = get_post_meta($post->ID, "option_2_grade", true);
						$option_3_grade = get_post_meta($post->ID, "option_3_grade", true);
						$option_4_grade = get_post_meta($post->ID, "option_4_grade", true);
						$option_5_grade = get_post_meta($post->ID, "option_5_grade", true);
						$option_overall_grade = ( $option_1_grade + $option_2_grade + $option_3_grade + $option_4_grade + $option_5_grade ) / 5;
						?>

						<div id="post-<?php the_ID(); ?>" <?php post_class( 'product1' ); ?>>
							<?php
							if ( $cwp_rev_product_image ) {
								echo '<div class="product1-image" style="background-image: url('. $cwp_rev_product_image .')"></div>';
							} else {
								echo '<div class="product1-image" style="background-image: url('. get_template_directory_uri() .'/images/no-image2.png)"></div>';
							}
							?>
							<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" class="product1-title">
								<?php the_title(); ?>
							</a><!--/a. product1-title-->
							<?php
							if ( $option_overall_grade ) {
								echo '<div class="product1-stars"><div class="stars_active" style="width: '. $option_overall_grade .'%;"></div></div>';
							}

							if ( !empty( $affiliate_text ) && !empty( $affiliate_link ) ) {
								echo '<div class="affiliate-button2 affiliate-button button-buy">';
								echo '<a href="'. $affiliate_link .'" rel="nofollow" target="_blank">';
								echo '<span>'. $affiliate_text .'</span>';
								echo '</a>';
								echo '</div>';
							}
							?>
						</div><!--/div .product1-->

					<?php }
				} else {
					_e( 'No posts found.', 'ti' );
				}

				// Restore original Post Data
				wp_reset_postdata();
				?>

			</div><!--/div .products-content .cf-->
			<div class="nav cf">
				<?php next_posts_link(esc_attr__('Prev', 'ti')); ?>
				<?php previous_posts_link(esc_attr__('Next', 'ti')); ?>
			</div><!--/.nav.cf-->

			<?php
			/*
			<div class="nav cf">
				<a href="" title="Pagina Anterioara" class="nav-left">
					Pagina Anterioara
				</a><!--/a .nav-left-->
				<a href="" title="Pagina Urmatoare" class="nav-right">
					Pagina Urmatoare
				</a><!--/a .nav-right-->
			</div><!--/div .nav .cf-->
			*/
			?>

		</div><!--/div .content-left-->

		<?php get_sidebar(); ?>

	</div><!--/div #content .cf-->

</div><!--/div .wrapper .cf-->
<?php get_footer(); ?>