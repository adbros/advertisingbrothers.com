<?php
/**
 *	The template for displaying Single.
 *
 *	@package ThemeIsle.
 */
get_header();
?>
<div class="wrapper cf">
	<?php

	if ( have_posts() ) {
		while ( have_posts() ) {
			the_post(); ?>

			<div id="single" class="cf">
				<div class="related-products">
					<div class="related-products-title">
						<?php the_title(); ?>
					</div><!--/div .related-products-title-->
					<div class="related-products-entry">
						<?php the_content(); ?>
					</div><!--/div .related-products-entry-->
					<?php
					wp_link_pages( array(
						'before'      => '<div class="single-article-pagination"><span class="article-pagination-title">' . __( 'Pages:', 'ti' ) . '</span>',
						'after'       => '</div>',
						'link_before' => '<span>',
						'link_after'  => '</span>',
					) );

					if ( has_tag() ) {
						echo '<div class="single-article-tags">';
						the_tags('<span>Tags:</span> ');
						echo '</div>';
					}
					?>
				</div><!--/div .related-products-->
			</div><!--/div #single .cf-->

		<?php }
	}

	comments_template();
	?>
	<div class="single-grap">
	</div><!--/.single-grap-->
</div><!--/div .wrapper .cf-->
<?php get_footer(); ?>