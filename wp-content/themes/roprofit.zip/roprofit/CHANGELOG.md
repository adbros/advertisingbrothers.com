

### 1.1 - 04/11/2014

 Changes: 


 * Update style.css


### 1.0 - 04/11/2014

 Changes: 


 * remove redundant files


### 1.0 - 04/11/2014

 Changes: 


 * Issue #26. Spatiu stelule/title issue fixed.
 * Issue #25. Stars issue fixed.
 * Issue #25. Stars issue fixed.
 * Issue #24. Line height issue fixed.
 * Issue #23. Spatiu buton issue fixed.
 * Cart icon issue #22 fixed.
 * quick aligment fixes

- for rating and button
 * Issue #27: mutare continut fixed

N-am reușit să adaug conținut sub secțiunea pros și cons dar am
modificat stilul la afișarea elementelor din plugin.
