<?php
/**
 *	The template for displaying Archive.
 *
 *	@package ThemeIsle
 */
get_header();
?>
<div class="wrapper">
	<div id="archive">
		<div class="archive-title">
			<?php
			$category_archive = get_the_category();
			$author_archive = get_the_author();
			$search_archive = get_search_query();

			if ( is_day() ) {
				printf( __( '%s', 'ti' ), get_the_date() );
			} elseif ( is_month() ) {
				printf( __( '%s', 'ti' ), get_the_date( _x( 'F Y', '', 'ti' ) ) );
			} elseif ( is_year() ) {
				printf( __( '%s.', 'ti' ), get_the_date( _x( 'Y', '', 'ti' ) ) );
			} elseif ( is_category() ) {
				echo single_cat_title();
			} elseif ( is_author() ) {
				echo $author_archive;
			} elseif ( is_tag() ) {
				echo single_tag_title();
			}
			?>
		</div><!--/.archive-title-->
		<div class="archive-posts cf">
			<?php

			if ( have_posts() ) {
				while ( have_posts() ) {
					the_post();
					$cwp_rev_product_image = get_post_meta($post->ID, "cwp_rev_product_image", true);
					$affiliate_text = get_post_meta($post->ID, "cwp_product_affiliate_text", true);
    				$affiliate_link = get_post_meta($post->ID, "cwp_product_affiliate_link", true);
    				$option_1_grade = get_post_meta($post->ID, "option_1_grade", true);
					$option_2_grade = get_post_meta($post->ID, "option_2_grade", true);
					$option_3_grade = get_post_meta($post->ID, "option_3_grade", true);
					$option_4_grade = get_post_meta($post->ID, "option_4_grade", true);
					$option_5_grade = get_post_meta($post->ID, "option_5_grade", true);
					$option_overall_grade = ( $option_1_grade + $option_2_grade + $option_3_grade + $option_4_grade + $option_5_grade ) / 5; ?>

					<div id="post-<?php the_ID(); ?>" <?php post_class( 'archive-post' ); ?>>
						<?php
						if ( $cwp_rev_product_image ) {
							echo '<div class="archive-post-image" style="background-image: url('. $cwp_rev_product_image .');"></div>';
						} else {
							echo '<div class="archive-post-image" style="background-image: url('. get_template_directory_uri() .'/images/no-image2.png);"></div>';
						}
						?>
						<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" class="archive-post-title">
							<?php the_title(); ?>
						</a>
						<?php
						if ( $option_overall_grade ) {
							echo '<div class="archive-post-stars">';
							echo '<div class="archive-post-stars-active" style="width: '. $option_overall_grade .'%;"></div>';
							echo '</div>';
						}

						if ( !empty( $affiliate_text ) && !empty( $affiliate_link ) ) {
							echo '<div class="affiliate-button2 affiliate-button">';
							echo '<a href="'. $affiliate_link .'" rel="nofollow" target="_blank">';
							echo '<span>'. $affiliate_text .'</span>';
							echo '</a>';
							echo '</div>';
						}
						?>
					</div><!--/.archive-post-->

				<?php }
			} else {
				_e( 'No posts found.', 'ti' );
			}
			?>
		</div><!--/.archive-posts.cf-->
		<div class="nav cf">
			<?php next_posts_link(esc_attr__('Prev', 'ti')); ?>
			<?php previous_posts_link(esc_attr__('Next', 'ti')); ?>
		</div><!--/.nav.cf-->
	</div><!--/#archive-->
</div><!--/.wrap-->
<?php get_footer(); ?>