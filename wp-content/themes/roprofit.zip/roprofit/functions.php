<?php

/**
 *	Require Once
 */
require_once( 'includes/custom-functions.php' ); // Custom Functions
require_once( 'includes/customizer.php' ); // Customizer
require_once( 'includes/tgm-plugin-activation/tgm-plugin-activation.php' ); // THM Plugin Activation

/**
 *	WP Enqueue Style RoProfit
 */
function ti_wp_enqueue_style_roprofit() {
    wp_enqueue_style( 'style', get_stylesheet_uri(), array(), '1.0' );
    wp_enqueue_style( 'font-awesome', get_template_directory_uri() . '/css/font-awesome.css', array(), '1.0' );
    wp_enqueue_style( 'fancybox', get_template_directory_uri() . '/css/jquery.fancybox.css', array(), '1.0' );
    if ( is_singular() ) wp_enqueue_script( "comment-reply" );
    if ( is_rtl() ) {
        wp_enqueue_style( 'rtl', get_template_directory_uri() . '/css/rtl.css', array(), '1.0' );
    }
}
add_action( 'wp_enqueue_scripts', 'ti_wp_enqueue_style_roprofit' );

/**
 *	WP Enqueue Scripts RoProfit
 */
function ti_wp_enqueue_scripts_roprofit() {
    wp_enqueue_script( 'jquery');
    wp_enqueue_script( 'fancybox', get_template_directory_uri() . '/js/jquery.fancybox.js', array( 'jquery' ), '1.0', true );
    wp_enqueue_script( 'masonry', get_template_directory_uri() . '/js/jquery.masonry.js', array( 'jquery' ), '1.0', true );
    wp_enqueue_script( 'scripts', get_template_directory_uri() . '/js/scripts.js', array( 'jquery' ), '1.0', true );
}
add_action( 'wp_enqueue_scripts', 'ti_wp_enqueue_scripts_roprofit' );

/**
 *	Top Navigation
 */
function ti_top_navigation() {

	$locations = array(
		'top-navigation' => __( 'Top Navigation', 'ti' ),
	);
	register_nav_menus( $locations );

}
add_action( 'init', 'ti_top_navigation' );

/**
 *	Header Navigation
 */
function ti_header_navigation() {

	$locations = array(
		'header-navigation' => __( 'Header Navigation', 'ti' ),
	);
	register_nav_menus( $locations );

}
add_action( 'init', 'ti_header_navigation' );

/**
 *	Add Theme Support
 */
add_theme_support( 'automatic-feed-links' ); // Automatic Feed Links

/**
 *  General Sidebar
 */
function ti_general_sidebar() {

    $args = array(
        'id'            => 'general_sidebar',
        'name'          => __( 'General Sidebar', 'ti' ),
        'description'   => __( 'Use this sidebar to display widgets on frontpage.', 'ti' ),
        'before_title'  => '<div class="widget-title">',
        'after_title'   => '</div>',
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
    );
    register_sidebar( $args );

}
add_action( 'widgets_init', 'ti_general_sidebar' );

/**
 *  Content Width
 */
if ( ! isset( $content_width ) ) $content_width = 944;

/**
 *  Unregister Widget
 */
function ti_unregister_widget() {
    unregister_widget('cwp_latest_products_widget'); // CWP Latest Products Widget
    unregister_widget('cwp_top_products_widget'); // CWP Top Products Widget
}

add_action( 'widgets_init', 'ti_unregister_widget' );

 require 'inc/cwp-update.php'; 

