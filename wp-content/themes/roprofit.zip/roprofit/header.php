<?php
/**
 *  The template for displaying Header.
 *
 *  @package ThemeIsle.
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
	<head>
		<meta charset="UTF-8">
		<title><?php wp_title('|', true, 'right'); bloginfo('name'); ?></title>
		<!--[if lt IE 9]>
			<script src="<?php echo get_template_directory_uri(); ?>/js/html5shiv.js"></script>
		<![endif]-->
		<?php wp_head(); ?>
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
	</head>
	<body <?php body_class(); ?>>
		<header>
			<div id="top-header">
				<div class="wrapper cf">
					<div class="openresponsivemenu-pages">
					</div><!--/.openresponsivemenu-pages-->
					<nav class="nav-pages">
						<?php
						wp_nav_menu( array(
								'theme_location'	=> 'top-navigation',
								'container'			=> '',
								'container_class'	=> ''
							)
						);
						?>
					</nav><!--/nav-pages-->
					<div class="align-right">
						<form role="search" method="get" id="searchform" class="form-search" action="<?php echo esc_url( home_url( '/' ) ); ?>">
							<div>
								<input type="text" value="<?php echo get_search_query(); ?>" name="s" class="input-text" />
								<input type="submit" class="input-submit" value="" />
							</div>
						</form>
						<?php
						/*
						<form action="" class="form-search">
							<input type="text" name="search" class="input-text">
							<input type="submit" name="submit" value="" class="input-submit">
						</form><!--/form-search-->
						*/
						?>
						<div class="socials-box">
							<?php
							if ( get_theme_mod( 'ti_facebook_link' ) ) {
								echo '<a href="'. get_theme_mod( 'ti_facebook_link' ) .'" title="'. __( 'Facebook', 'ti' ) .'" class="social-icon fa fa-facebook" target="_blank"></a>';
							}

							if ( get_theme_mod( 'ti_twitter_link' ) ) {
								echo '<a href="'. get_theme_mod( 'ti_twitter_link' ) .'" title="'. __( 'Twitter', 'ti' ) .'" class="social-icon fa fa-twitter" target="_blank"></a>';
							}

							if ( get_theme_mod( 'ti_googleplus_link' ) ) {
								echo '<a href="'.  get_theme_mod( 'ti_googleplus_link' ) .'" title="'. __( 'Google+', 'ti' ) .'" class="social-icon fa fa-google-plus" target="_blank"></a>';
							}
							?>
						</div><!--/div .socials-box-->
					</div><!--/div .align-right-->
				</div><!--/div .wrapper .cf-->
			</div><!--/div #top-header-->
			<div id="wide-header">
				<div class="wrapper cf">
					<a href="<?php echo home_url(); ?>" class="header-logo">
						<?php
						if ( get_theme_mod( 'ti_logo_image' ) ) {
							echo '<img src="'. get_theme_mod( 'ti_logo_image' ) .'" alt="'. get_bloginfo( 'name' ) .'" title="'. get_bloginfo( 'name' ) .'" />';
						} else {
							echo '<img src="'. get_template_directory_uri() .'/images/header-logo.png" alt="'. get_bloginfo( 'name' ) .'" title="'. get_bloginfo( 'name' ) .'" />';
						}
						?>
					</a><!--/a .header-logo-->
					<div class="openresponsivemenu-categories">
					</div><!--/.openresponsivemenu-categories-->
					<nav class="nav-categories cf">
						<?php
						wp_nav_menu( array(
							'theme_location'	=> 'header-navigation',
							'container'			=> '',
							'container_class'	=> ''
							)
						);
						?>
					</nav><!--/nav .nav-categories.cf-->
				</div><!--/div .wrapper .cf-->
			</div><!--/div #wide-header-->
		</header><!--/header-->