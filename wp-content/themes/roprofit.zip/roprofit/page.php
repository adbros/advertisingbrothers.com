<?php
/**
 *	The template for displaying Page.
 *
 *	@package ThemeIsle.
 */
get_header();
?>
<div class="wrapper cf">
	<?php

	if ( have_posts() ) {
		while ( have_posts() ) {
			the_post(); ?>

			<div id="single" class="cf">
				<div class="related-products">
					<div class="related-products-title">
						<?php the_title(); ?>
					</div><!--/div .related-products-title-->
					<div class="related-products-entry">
						<?php the_content(); ?>
					</div><!--/div .related-products-entry-->
				</div><!--/div .related-products-->
			</div><!--/div #single .cf-->

		<?php }
	}
	?>
</div><!--/div .wrapper .cf-->
<?php get_footer(); ?>