/**
 *	jQuery Scripts
 */
jQuery(document).ready(function($) {

	/* Fancybox */
	$(".fancybox").fancybox();

	/* Masonry */
	var $container = $('.gallery');

	$container.imagesLoaded( function(){
		$container.masonry({
			itemSelector : 'dl.gallery-item'
		});
	});

	/* Responsive Menu - Pages */
	$('.openresponsivemenu-pages').click(function() {
		$('.nav-pages').toggleClass("responsivemenu-pages cf");
	});

	/* Responsive Menu - Categories */
	$('.openresponsivemenu-categories').click(function() {
		$('.nav-categories').toggleClass("responsivemenu-categories cf");
	});

});

/**
 *	Limit: Top Navigation
 */
var full_width = 0;
jQuery(".nav-pages ul:first > li").each(function( index ) {
	if((jQuery(this).width() + full_width) > 400) {
		jQuery(this).remove();
	}
	full_width = full_width + jQuery(this).width();
});

/**
 *	Limit: Header Navigation
 */
var full_width = 0;
jQuery(".nav-categories ul:first > li").each(function( index ) {
	if((jQuery(this).width() + full_width) > 700) {
		jQuery(this).remove();
	}
	full_width = full_width + jQuery(this).width();
});