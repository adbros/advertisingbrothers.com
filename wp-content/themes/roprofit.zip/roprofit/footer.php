<?php
/**
 *  The template for displaying Footer.
 *
 *  @package ThemeIsle.
 */
?>
<footer id="footer">
	<div class="wrapper">
		<?php
		if ( get_theme_mod( 'ti_footer_copyright' ) ) {
			echo htmlspecialchars_decode( get_theme_mod( 'ti_footer_copyright' ) );
		} else {
			echo __( 'Copyright &copy; 2014 RoProfit. All rights reserved.', 'ti' );
		}
		?>
	</div><!--/div .wrapper-->
	<?php wp_footer(); ?>
</footer><!--/footer #footer-->