=== Book Rev Lite ===
Contributors:		ReadyThemes, Codeinwp
Tags:				brown,custom-menu, featured-images, one-column, post-formats, responsive-layout, sticky-post, translation-ready,green,white,light,right-sidebar,two-columns, fixed-layout, custom-background,custom-header,full-width-template,theme-options,translation-ready
Requires at least:	3.3.0
Tested up to:		4.0
Book Rev Lite
== Description ==
Book Rev Lite makes presenting and selling your books a piece of cake. The responsive design includes tools for presenting your books in a beautiful way. Book Rev Lite also includes tools to make downloading your book a breeze for buyers. This theme comes with different custom widgets and beautiful homepage template.

= License =
Book Rev Lite WordPress theme, Copyright (C) 2013 ReadyThemes.com
Book Rev Lite WordPress theme is licensed under the GPL3.

Unless otherwise specified, all the theme files, scripts and images are licensed under GNU General Public Licemse.
The exceptions to this license are as follows:

jquery.cycle.js
License: Distributed under the terms of The MIT License (MIT)
Copyright: Copyright (c) 2013 M. Alsup

superfish.js
License: Distributed under the terms of The MIT License (MIT)
Copyright: Copyright (c) 2013 Joel Birch

Font Awesome
License: Distributed under the terms of SIL Open Font License (OFL) ( http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL )
Copyright: Dave Gandy