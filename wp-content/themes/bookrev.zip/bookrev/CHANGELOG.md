

### 1.0.3 - 08/02/2015

 Changes: 


 * Multiple fixes and improvements

Multiple fixes and improvements among WooCommerce support, widgets,
fixed #6 and others.
 * Merge pull request #7 from vncatalin/development

Multiple fixes and improvements
 * Fixed: #6 #8 #9 #10 #11 #12

Multiple fixes.
 * Merge pull request #13 from vncatalin/development

Fixed: #6 #8 #9 #10 #11 #12
 * Fixed issues

Fixed issues
 * Merge pull request #14 from vncatalin/development

Fixed issues
 * Multiple fixes.

Multiple fixes.
 * Padding fix

Padding fix
 * Multiple fixes

Multiple fixes
 * Merge pull request #15 from vncatalin/development

Multiple fixes
 * removed wp prod pro zip

removed wp prod pro zip
 * eerge branch 'production' into development

Conflicts:
	CHANGELOG.md
