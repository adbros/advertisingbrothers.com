<?php 
if ( is_plugin_active( 'wp-product-review/wp-product-review.php' ) ) {

	class featured_reviews_widget extends WP_Widget {

		function __construct() {
			parent::__construct(
				'featured_reviews_widget',
				__('BookRev Featured Reviews', 'book-rev-pro'),
				array(
					'description' => __( 'This widget displays the latest reviews from a specific category.', 'book-rev-pro' )
					)
				);
		}

		// Creating widget front-end
		// This is where the action happens
		public function widget( $args, $instance ) {
			if (isset($instance['title']))
				$title = apply_filters( 'widget_title', $instance['title'] );
			if (isset($instance['no_items']))
				$no_items = apply_filters( 'widget_content', $instance['no_items'] );
			else
				$no_items = "";
			if (isset($instance['cwp_tp_category']))
				$cwp_tp_category = apply_filters( 'widget_content', $instance['cwp_tp_category'] );
			else
				$cwp_tp_category = "";




			echo $args['before_widget'];
			// before and after widget arguments are defined by themes
			echo "<div class='topbooks'>";

			if (!empty( $title )) echo $args['before_title'] . $title . $args['after_title'];

			// Loop to get the most popular posts, ordered by the author's final grade.
			$query_args = array(
				'posts_per_page'	=> $no_items, // limit it to the specified no of posts
				'post_type'			=> array('post'),
				'review_category' 	=> $cwp_tp_category, // limit it to the specified category
				'post__not_in'		=> get_option('sticky_posts'),
				'meta_key'			=> 'option_overall_score',
				'meta_query'       	=> array(
					array(
						'key'       => 'cwp_meta_box_check',
						'value'     => 'Yes',
					),
				),	
			);

			$cwp_query = new WP_Query($query_args);  

			echo "<ul>";

			while($cwp_query->have_posts()) : $cwp_query->the_post(); ?>

	                    <li class="book clearfix post_id_<?php get_the_ID(); ?>">
	                        <div class="feat-img">
	                            <div class="inner-feat-img">
	                                <a href="<?php the_permalink(); ?>"><img src="<?php echo get_post_meta($cwp_query->post->ID, 'cwp_rev_product_image', true); ?>"></a>
	                            </div><!-- end .inner-feat-img -->
	                        </div><!-- end .feat-img -->

	                        <div class="book-details">
	                            <h3 class="title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
	                            <div class="meta">
	                                <span class="categ"><?php the_category(' , '); ?></span>
	                                <span class="date">/ <?php the_time( get_option( 'date_format' ) ); ?></span>
	                            </div><!-- end .meta -->
								 <?php $grade = book_rev_lite_get_review_grade(get_the_ID()); ?>
	            				<span class="grade <?php echo book_rev_lite_display_review_class($grade); ?>"> <?php  if(isset($grade)) echo $grade . " / 10"; ?></span>
	                        </div><!-- end .book-details -->
	                    </li><!-- end .book -->

			<?php endwhile; ?>
			<?php wp_reset_postdata(); // reset the query 

			echo "</ul>";
						echo "</div>"; // end .topbooks
			echo $args['after_widget'];

		}

		// Widget Backend 
		public function form( $instance ) {
			if (isset($instance['title'])) {
				$title = $instance[ 'title' ];
				$no_items = $instance[ 'no_items' ];
				$cwp_tp_category = $instance[ 'cwp_tp_category' ];
			}
			else {
				$title = __( 'Featured Reviews', 'book-rev-pro' );
				$no_items = __( '3', 'book-rev-pro');
				$cwp_tp_category = "Select Category";
			}

			$cwp_tp_categ_array = get_categories('hide_empty=0');
			foreach ($cwp_tp_categ_array as $categs) {
				$cwp_tp_all_categories[$categs->slug] = $categs->name;
			}

		// Widget admin form
		?>


		<p>
		<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:', "cwp" ); ?></label> 
		<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
		</p>

		<p>
		<label for="<?php echo $this->get_field_id( 'no_items' ); ?>"><?php _e( 'Number of posts to show:', "cwp" ); ?></label> 
		<input id="<?php echo $this->get_field_id( 'no_items' ); ?>" name="<?php echo $this->get_field_name( 'no_items' ); ?>" size="3" type="text" value="<?php echo esc_attr( $no_items ); ?>" />
		</p>

		<p>
		<?php $cwp_tp_selected_categ = esc_attr( $cwp_tp_category ); ?>
		<label for="<?php echo $this->get_field_id( 'cwp_tp_category' ); ?>"><?php _e( 'Category:', "cwp" ); ?></label> 
		<select id="<?php echo $this->get_field_id( 'cwp_tp_category' ); ?>" name="<?php echo $this->get_field_name( 'cwp_tp_category' ); ?>">
		<?php foreach ($cwp_tp_all_categories as $categ_slug => $categ_name): ?>
				<?php if($categ_slug == $cwp_tp_selected_categ) {
					echo "<option selected>".$categ_slug."</option>";
				} elseif($categ_slug == "") {
					echo "<option>There are no categs</select>";
				} else { 
					echo "<option>".$categ_slug."</option>";
				} ?>
		<?php endforeach; ?>
		</select>
		</p>

		<?php }
		
		// Updating widget replacing old instances with new
		public function update( $new_instance, $old_instance ) {
			$instance = array();
			$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
			$instance['no_items'] = ( ! empty( $new_instance['no_items'] ) ) ? strip_tags( $new_instance['no_items'] ) : '';
			$instance['cwp_tp_category'] = ( ! empty( $new_instance['cwp_tp_category'] ) ) ? strip_tags( $new_instance['cwp_tp_category'] ) : '';
			return $instance;
		}

	} // end Class featured_reviews_widget


	// Register and load the widget
	function load_featured_reviews_widget() {
		register_widget( 'featured_reviews_widget' );
	}

	add_action( 'widgets_init', 'load_featured_reviews_widget' );

}
