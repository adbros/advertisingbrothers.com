<?php 

class latest_comments_widget extends WP_Widget {

	function __construct() {
		parent::__construct('latest_comments_widget', __('BookRev Latest Comments', 'cwp'), array( 'description' => __( 'This widget displays the latest comments.', 'cwp' )));
	}

	// Creating widget front-end
	// This is where the action happens
	public function widget( $args, $instance ) {
		if (isset($instance['title']))
			$title = apply_filters( 'widget_title', $instance['title'] );
		else
			$title = "";

		if (isset($instance['no_items']))
			$no_items = apply_filters( 'widget_content', $instance['no_items'] );
		else
			$no_items = "";

		// before and after widget arguments are defined by themes
		echo "<div class='latest-comments'>";
		echo $args['before_widget'];
		if (!empty($title)) echo $args['before_title'] . $title . $args['after_title'];
		echo "<ul>";

			$latest_comments = get_comments(array(
				'number'	=> $no_items,
				'status'	=> 'approve'
			));

			foreach ($latest_comments as $comment): ?>

                    <li class="comment clearfix">
                        <div class="author-avatar">
                            <a href="<?php echo get_permalink($comment->comment_post_ID); ?>">
                                <?php echo get_avatar($comment->user_id, 60, "http://www.gravatar.com/avatar");?>
                            </a>
                        </div><!-- end .author-avatar -->

                        <div class="comment-body">
                        	<?php $postname = "<a class='comment_article_link' href='" . get_permalink($comment->comment_post_ID) . "'>" . get_the_title($comment->comment_post_ID) . "</a>"; ?>
                            <h4><a href="<?php echo $comment->comment_author_url; ?>"><?php echo $comment->comment_author; ?></a> <?php _e("said on ", "cwp"); echo $postname; ?>:</h4>
                            <p><?php echo get_comment_excerpt($comment->comment_ID);  ?>
			
                        </p>
                        </div><!-- end .comment-body -->
                    </li><!-- end .comment -->

<?php 	endforeach;

		echo "</ul>";
		echo $args['after_widget'];
		echo "</div>"; // end .latest-comments
	}

	// Widget Backend 
	public function form( $instance ) {
		if (isset($instance['title'])) {
			$title = $instance[ 'title' ];
			$no_items = $instance[ 'no_items' ];
		}
		else {
			$title = __( 'Latest Comments', 'cwp' );
			$no_items = __( '3', 'cwp');
		}

	// Widget admin form
	?>
	<p>
	<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:', "cwp" ); ?></label> 
	<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
	</p>

	<p>
	<label for="<?php echo $this->get_field_id( 'no_items' ); ?>"><?php _e( 'Number of comments to show:', "cwp" ); ?></label> 
	<input id="<?php echo $this->get_field_id( 'no_items' ); ?>" name="<?php echo $this->get_field_name( 'no_items' ); ?>" size="3" type="text" value="<?php echo esc_attr( $no_items ); ?>" />
	</p>


	<?php }
	
	// Updating widget replacing old instances with new
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
		$instance['no_items'] = ( ! empty( $new_instance['no_items'] ) ) ? strip_tags( $new_instance['no_items'] ) : '';
		return $instance;
	}

} // end Class latest_comments_widget


// Register and load the widget
function load_latest_comments_widget() {
	register_widget( 'latest_comments_widget' );
}

add_action( 'widgets_init', 'load_latest_comments_widget' );