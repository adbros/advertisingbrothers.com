jQuery(document).ready(function() {
	jQuery('.wp-full-overlay-sidebar-content').prepend('<a style="margin-top: 5px;margin-bottom: 5px; margin-left: 93px;"href="https://themeisle.com/documentation-bookrev/" class="button" target="_blank">Documentation</a>');
});
