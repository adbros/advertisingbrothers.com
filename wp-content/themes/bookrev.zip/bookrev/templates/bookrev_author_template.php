        <div id="author-box" class="clearfix">

            <header>
                <h2>Author Details</h2>
            </header>
            <div class="clearfix"></div>
            <div class="author-box-inner clearfix">
                <div class="author-avatar">
                    <img src="assets/ionut.jpg">
                </div><!-- end .author-avatar -->

                <div class="author-details">
                    <h3 class="author-name"><a href="#">Ionut Neagu</a></h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repudiandae, aliquam praesentium quaerat voluptate numquam voluptas asperiores nam error impedit quam! Aspernatur, soluta ipsa optio nisi dolores libero iure voluptatibus laudantium?</p>
                </div><!-- end .author-details -->
            </div><!-- end .author-box-inner -->

        </div><!-- end .author-box -->