<?php

/**
 * Template: WooCommerce Homepage Product Slider
 */
?>


<div class="bookrev-lp-wrapper">
	<header>
		<h1><?php if(get_theme_mod('mp_wcslider_title') != '') { echo get_theme_mod('mp_wcslider_title'); } else { _e('Latest Products', 'bookrev'); } ?></h1>
 	</header>

<div class="bookrev-latest-products bookrev-carousel" data-cycle-log="false">
<?php

$wpq = new WP_Query(array('post_type' => 'product'));

if($wpq->have_posts()): ?>


	<ul class = "products-list">
		<?php while ($wpq->have_posts()) : $wpq->the_post(); ?>

			<?php woocommerce_get_template_part('content', 'product'); ?>

		<?php endwhile; // end of the loop.   ?>
	</ul>


<?php endif; ?>

<div class="navigation"></div>
<div class="next"></div>
<div class="prev"></div>


</div><!-- end .bookrev-latest-products -->
</div><!-- end .bookrev-lp-wrapper -->
