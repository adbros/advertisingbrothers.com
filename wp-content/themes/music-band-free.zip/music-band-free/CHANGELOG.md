

### 1.2 - 17/10/2014

 Changes: 


 * Small fix - correct metabox for song title 8
 * Updated theme uri, documentation link and forum link
 * fixes coding standard
 * fixed coding standard.
applied fixes that break the HTML validation
 * removed the header bottom border because when the title or description is too long doesn't look pretty.
 * fixed coding standard in functions.php
 * adapted more coding std
 * Merge pull request #2 from orbisius/development

Development
 * image optimization   small improvements
 * Improvements
 * Resolved ticket 19389 review
