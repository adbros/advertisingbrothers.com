<?php
/*
 * The Sidebar containing the main widget areas.
 *
 * @package music-band-lite
 */
if ( is_active_sidebar( 'sidebar-1' ) )	dynamic_sidebar( 'sidebar-1' ); ?>