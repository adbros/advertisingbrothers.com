= Music Band Lite =
Author: codeinwp
Tags: purple, pink, gray, white, two-columns, custom-background, custom-header, right-sidebar, responsive-layout, custom-menu, editor-style, featured-images, sticky-post, threaded-comments, translation-ready
Requires at least:	3.3.0
Tested up to:		4.0
Music Band Lite
== Description ==
Music Band Lite is a easily customizable WordPress Theme with an elegant design for your band.  
= License =
Unless otherwise specified, all the theme files, scripts and images are licensed under GNU General Public License v3.
The exceptions to this license are as follows: 
* SlidesJS	Licensed under the Apache License, Version 2.0 (the “License”);	you may not use this file except in compliance with the License.	You may obtain a copy of the License at	http://www.apache.org/licenses/LICENSE-2.0	Unless required by applicable law or agreed to in writing, software	distributed under the License is distributed on an “AS IS” BASIS,	WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.	See the License for the specific language governing permissions and	limitations under the License.
* Lato font is licensed under the SIL Open Font License, 1.1 http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL* jQuery Tools v1.2.7 - The missing UI library for the Web (tabs/tabs.js) - NO COPYRIGHTS OR LICENSES. DO WHAT YOU LIKE. http://flowplayer.org/tools/