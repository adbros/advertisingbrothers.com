<?php
/*
Template Name: Events page
*/
?>

<?php get_header(); ?>


<div class="full-content-body ">
            <div class="container">

			<?php if ( have_posts() ) : the_post(); ?>
			<header class="page-header">
				<h1 class="main-title">
					<?php the_title(); ?>
				</h1>
                <?php the_content('<div class="taxonomy-description">%s</div>');?>
       		<?php endif; ?>       
        
			</header><!-- .page-header -->
                        
					<?php
						$today = current_time('timestamp');
                
                        $paged = get_query_var('paged') ? get_query_var('paged') : 1;
                        $wp_query = new WP_Query(array(
                                                'post_type'         => 'events',
                                                'paged' 			=> $paged,
												'orderby'           => 'meta_value_num',
												'meta_key'          => '_cwp_date_time_events',
												'order'             => 'ASC',
	                                            'meta_query'		=> array(
                                                                            array(
                                                                                'key'		=> '_cwp_date_time_events',
                                                                                'value' 	=> $today,
                                                                                'type' 		=> 'numeric',
                                                                                'compare' 	=> '>=',
                                                                            )
                                                        				)
                                                )
                                        	);

                        while ($wp_query->have_posts()) : $wp_query->the_post();
                        
                            get_template_part( 'content', 'events' );
                                
                        endwhile;
                
                                if (function_exists("cwp_pagination")) {
                                    cwp_pagination();
                                } else{
                                    codeinwp_paging_nav();
                                } 
                                
                        wp_reset_query();		
                    ?>
            
                    </div><!-- .blog-content -->
				</div>

<?php get_footer(); ?>