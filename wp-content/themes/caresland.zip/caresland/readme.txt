= Caresland =

Author: codeinwp

Tags: orange, yellow, green, gray, light, one-column, right-sidebar, responsive-layout, custom-background, custom-header, editor-style, featured-images, sticky-post, threaded-comments, translation-ready

Requires at least:	3.3.0

Tested up to:		3.6

Caresland

== Description ==

Caresland is a a easily customizable WordPress Theme designed for kindergartens or other websites about activities with children.

= License =

Unless otherwise specified, all the theme files, scripts and images are licensed under GNU General Public License v2.

The exceptions to this license are as follows: 

* Scada font is licensed under SIL Open Font License (OFL)
	http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL

* Bootstrap is licensed under
	The MIT License (MIT)

Copyright (c) 2011-2014 Twitter, Inc

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

* flexislider is licensed under GPLv2 
	http://www.gnu.org/licenses/gpl-2.0.html
	
* tinynav is licensed under the MIT license.
	Copyright (c) 2011-2014 Viljami Salminen, http://viljamis.com/