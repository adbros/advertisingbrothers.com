<?php
/**
 * @package codeinwp
 */
?>

				<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

					<h1><?php the_title(); ?></h1>

                    <div class="events-info-page">
                        <?php 
							$events_date = get_post_meta( $post->ID, '_cwp_date_time_events', true );
							$events_address = trim(get_post_meta( get_the_ID(), '_cwp_address_event', true ));
						?>
                        <div class="event-info-wrap">
                            <div class="event-info-time-wrap">
                            	<?php
									$short_month = date( 'F', $events_date );
                                 	echo substr($short_month, 0, 3); 
								?>
                                <p class="event-info-time"><?php echo date( 'j', $events_date ); ?></p>
                            </div>
                            <div class="event-info-about">
                                <?php echo date( 'l', $events_date ); ?>
                         		<span>
									<?php 
										echo date( 'F j, Y', $events_date );
									?>
                                </span>
                                <span><?php echo date( 'g:i a', $events_date ); ?></span>
                            </div>
                            <div class="event-info-location">
                                <?php echo $events_address ?>
                            </div>
                        </div><!-- .event-info-wrap -->
                        
                    
					    <div class="events-map-wrap">

							<?php echo get_post_meta( get_the_ID(), '_cwp_google_map_event', true ); ?>

					    </div><!-- .events-map-wrap -->
					</div><!-- .events-info-page -->

						<?php the_content(); ?>

				</article><!-- #post-## -->