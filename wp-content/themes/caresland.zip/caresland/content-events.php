<?php
/**
 * The template used for displaying page content in events.php
 *
 * @package codeinwp
 */
?>

		<article id="post-<?php the_ID(); ?>" class="event-wrap-box">
                <div class="line-orange"></div>
                <div class="content-wrap">
                    <div class="content-inside-event">
                    
						<?php
							if(has_post_thumbnail()) { ?>
								<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_post_thumbnail('event-thumbnail'); ?></a> 
						<?php } ?>
                            
						<div class="events-box-content">                      
                            <a href="<?php the_permalink(); ?>" class="blog-box-title title-events" title="<?php the_title(); ?>"><?php the_title(); ?></a>
                            <?php the_excerpt(); ?>
                            <br>
                                    <?php
                                        wp_link_pages( array(
                                            'before' => '<div class="page-links">' . __( 'Pages:', 'caresland' ),
                                            'after'  => '</div>',
                                        ) );
                                    ?>

                        <?php 
							$events_date = get_post_meta( $post->ID, '_cwp_date_time_events', true );
							$events_address = trim(get_post_meta( get_the_ID(), '_cwp_address_event', true ));
						?>
                        <div class="event-info-wrap">
                            <div class="event-info-time-wrap">
                            	<?php
									$short_month = date( 'F', $events_date );
                                 	echo substr($short_month, 0, 3); 
								?>
                                <p class="event-info-time"><?php echo date( 'j', $events_date ); ?></p>
                            </div>
                            <div class="event-info-about">
                                <?php echo date( 'l', $events_date ); ?>
                         		<span>
									<?php 
										echo date( 'F j, Y', $events_date );
									?>
                                </span>
                                <span><?php echo date( 'g:i a', $events_date ); ?></span>
                            </div>
                            <div class="event-info-location">
                                <?php echo $events_address ?>
                            </div>
                        </div><!-- .event-info-wrap -->

                        <a href="<?php the_permalink(); ?>" class="btn-box-orange"><?php _e('Find out more','caresland'); ?></a>
                        <?php edit_post_link( __( 'Edit', 'caresland' ), '<footer class="entry-meta"><span class="edit-link">', '</span></footer>' ); ?>
                        </div><!-- .event-info-wrap -->
                        
                    </div><!-- .content-inside -->
                    <div class="botttom-box-shadow-center"></div>
                    <div class="botttom-box-shadow-left"></div>
                    <div class="botttom-box-shadow-right"></div>

                </div>
		</article><!-- .event-wrap-box -->