<?php
/**
 * codeinwp functions and definitions
 *
 * @package codeinwp
 */

/**
 * Set the content width based on the theme's design and stylesheet.
 */
if ( ! isset( $content_width ) ) {
	$content_width = 640; /* pixels */
}


function cwp_setup() {

	/*
	 * Make theme available for translation.
	 * Translations can be filed in the /languages/ directory.
	 * If you're building a theme based on codeinwp, use a find and replace
	 * to change 'caresland' to the name of your theme in all the template files
	 */
	 load_theme_textdomain( 'caresland', FALSE, basename( dirname( __FILE__ ) ) . '/languages/' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link http://codex.wordpress.org/Function_Reference/add_theme_support#Post_Thumbnails
	 */
	//add_theme_support( 'post-thumbnails' );

	// This theme uses wp_nav_menu() in one location.
	register_nav_menus( array(
		'my-primary' => __( 'The Primary Menu', 'caresland' ),
	) );

	// Enable support for Post Formats.
	add_theme_support( 'post-formats', array( 'aside', 'image', 'video', 'quote', 'link' ) );

	// Setup the WordPress core custom background feature.
	add_theme_support( 'custom-background', apply_filters( 'codeinwp_custom_background_args', array(
		'default-color' => 'ffffff',
		'default-image' => '',
	) ) );
	
	$args = array(
		'width'         => 980,
		'height'        => 60,
		'default-image' => '',
		'uploads'       => true,
	);
	add_theme_support( 'custom-header', $args );
}

add_action( 'after_setup_theme', 'cwp_setup' );

/**
 * Post thumbnails.
 */
add_theme_support( 'post-thumbnails' ); 

/**
 * Register widgetized area and update sidebar with default widgets.
 */
function codeinwp_widgets_init() {
	register_sidebar( array(
		'name'          => __( 'Sidebar', 'caresland' ),
		'id'            => 'sidebar-1',
		'before_widget' => '<aside id="%1$s" class="widget %2$s"><div class="line-orange"></div>',
		'after_widget'  => '<div class="bottom-shadow"></div></aside>',
		'before_title'  => '<h1 class="widget-title">',
		'after_title'   => '</h1>',
	) );
	register_sidebar( array(
		'name'          => __( 'Footer1', 'caresland' ),
		'id'            => 'footer-1',
		'before_widget' => '<div id="%1$s" class="footer-box-inside">',
		'after_widget'  => '</div>',
		'before_title'  => '<h1 class="footer-widget-title">',
		'after_title'   => '</h1>',
	) );
	register_sidebar( array(
		'name'          => __( 'Footer2', 'caresland' ),
		'id'            => 'footer-2',
		'before_widget' => '<div id="%1$s" class="footer-box-inside">',
		'after_widget'  => '</div>',
		'before_title'  => '<h1 class="footer-widget-title">',
		'after_title'   => '</h1>',
	) );
	register_sidebar( array(
		'name'          => __( 'Footer3', 'caresland' ),
		'id'            => 'footer-3',
		'before_widget' => '<div id="%1$s" class="footer-box-inside">',
		'after_widget'  => '</div>',
		'before_title'  => '<h1 class="footer-widget-title">',
		'after_title'   => '</h1>',
	) );
	register_sidebar( array(
		'name'          => __( 'Footer4', 'caresland' ),
		'id'            => 'footer-4',
		'before_widget' => '<div id="%1$s" class="footer-box-inside">',
		'after_widget'  => '</div>',
		'before_title'  => '<h1 class="footer-widget-title">',
		'after_title'   => '</h1>',
	) );	
}
add_action( 'widgets_init', 'codeinwp_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function codeinwp_scripts() {

	wp_enqueue_style( 'bootstrap-style', get_template_directory_uri() . '/css/bootstrap.min.css');

	wp_enqueue_style( 'flexslider-style', get_template_directory_uri() . '/css/flexslider.css');

	wp_enqueue_style( 'codeinwp-style', get_stylesheet_uri() );
	
	wp_style_add_data( 'codeinwp-style', 'rtl', 'replace' );

	wp_enqueue_script( 'jquery' );

	wp_enqueue_script( 'bootstrap', get_template_directory_uri() . '/js/bootstrap.min.js', array(), 'v3.0.3', true );

	wp_enqueue_script( 'tinynav', get_template_directory_uri() . '/js/tinynav.min.js', array(), 'v1.1', true );

	wp_enqueue_script( 'flexslider', get_template_directory_uri() . '/js/jquery.flexslider-min.js', array('jquery'), 'v2.2', true );
	
	wp_enqueue_script( 'custom-scrips', get_template_directory_uri() . '/js/functions.js', array('jquery'), 'v1.0', true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'codeinwp_scripts' );

/**
 * Implement the Custom Header feature.
 */
//require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Custom functions that act independently of the theme templates.
 */
require get_template_directory() . '/inc/extras.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
require get_template_directory() . '/inc/jetpack.php';

/**
 * Pretty Photo include
 */
require get_template_directory() . '/plugins/prettyphoto/prettyphoto.php';

/* no title */
add_filter( 'the_title', 'cwp_no_title'); 
function cwp_no_title ($title) { 
    if( $title == "" ){ 
        $title = "(No title)"; 
    } 
    return $title; 
}


/* pagination */
function cwp_pagination($pages = '', $range = 3)
{  
     $showitems = ($range * 2)+1;  
 
     global $paged;
     if(empty($paged)) $paged = 1;
 
     if($pages == '')
     {
         global $wp_query;
         $pages = $wp_query->max_num_pages;
         if(!$pages)
         {
             $pages = 1;
         }
     }   
 
     if(1 != $pages)
     {
         echo "<div class=\"pagination\">";
         if($paged > 1 && $showitems < $pages)
		 	echo "<a href='".get_pagenum_link($paged - 1)."' class=\"pagination-prev\"></a>";
			
		$ok_l = true;
		$ok_r = true;

         for ($i=1; $i <= $pages; $i++)
         {
             if (1 != $pages &&( !($i >= $paged+$range+1 || $i <= $paged-$range-1) || $pages <= $showitems )){	
			
			$border_left = '';
			$border_right = '';
			
				if($paged-$range <= 0) 
					$br1 = 1; 
				else 
					$br1 = $paged-$range;
				
				if ( $paged+$range >= $pages) 
					$br2 = $pages; 
				else 
					$br2 = $paged + $range; 
			 	
				if($i <= $br1 && $ok_l == true) { $border_left = 'border-left'; $ok_l = false; }
				if($i >= $br2 && $ok_r == true) { $border_right = 'border-right'; $ok_r = false;}
				
                echo ($paged == $i)? "<span class=\"".$border_left." ".$border_right." current\">".$i."</span>":"<a href='".get_pagenum_link($i)."' class=\"".$border_left." ".$border_right." inactive\">".$i."</a>";
             }
         }
 
         if ($paged < $pages && $showitems < $pages) echo "<a href=\"".get_pagenum_link($paged + 1)."\" class=\"pagination-next\"></a>";  
         echo "</div>\n";
     }
}

/* Set the image size by cropping the image */
add_image_size( 'event-thumbnail', 325, 200, true );
add_image_size( 'post-thumbnail', 315, 172, true );

/*
 * Post gallery
 */
add_filter( 'post_gallery', 'cwp_post_gallery', 10, 2 );
function cwp_post_gallery( $output, $attr) {
    global $post, $wp_locale;

    static $instance = 0;
    $instance++;

    // We're trusting author input, so let's at least make sure it looks like a valid orderby statement
    if ( isset( $attr['orderby'] ) ) {
        $attr['orderby'] = sanitize_sql_orderby( $attr['orderby'] );
        if ( !$attr['orderby'] )
            unset( $attr['orderby'] );
    }

    extract(shortcode_atts(array(
        'order'      => 'ASC',
        'orderby'    => 'menu_order ID',
        'id'         => $post->ID,
        'columns'    => 3,
        'size'       => 'thumbnail',
        'include'    => '',
        'exclude'    => ''
    ), $attr));

    $id = intval($id);
    if ( 'RAND' == $order )
        $orderby = 'none';

    if ( !empty($include) ) {
        $include = preg_replace( '/[^0-9,]+/', '', $include );
        $_attachments = get_posts( array('include' => $include, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $order, 'orderby' => $orderby) );

        $attachments = array();
        foreach ( $_attachments as $key => $val ) {
            $attachments[$val->ID] = $_attachments[$key];
        }
    } elseif ( !empty($exclude) ) {
        $exclude = preg_replace( '/[^0-9,]+/', '', $exclude );
        $attachments = get_children( array('post_parent' => $id, 'exclude' => $exclude, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $order, 'orderby' => $orderby) );
    } else {
        $attachments = get_children( array('post_parent' => $id, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $order, 'orderby' => $orderby) );
    }

    if ( empty($attachments) )
        return '';

    if ( is_feed() ) {
        $output = "\n";
        foreach ( $attachments as $att_id => $attachment )
            $output .= wp_get_attachment_link($att_id, $size, true) . "\n";
        return $output;
    }
	
    $selector = "gallery-{$instance}";
	
   		echo "<!-- see gallery_shortcode() in wp-includes/media.php -->
		<div id='$selector' class='gallery-wrap galleryid-{$id}'>";

    foreach ( $attachments as $id => $attachment ) {
//		$link = isset($attr['link']) && 'file' == $attr['link'] ? wp_get_attachment_link($id, $size, false, false) : wp_get_attachment_link($id, $size, true, false);
		$link = '<a href="'.wp_get_attachment_url( $id ).'" rel="prettyPhoto[4-col]"><img src="'.wp_get_attachment_thumb_url( $id ).'" alt="gallery"><span></span></a>'; 
        $output .= "$link";			
    }

    $output .= "
            <br style='clear: both;' />
        </div>\n";

    return $output;
}

/* events taxionomy */
add_action( 'init', 'cwp_create_post_type' );
function cwp_create_post_type() {
	register_post_type( 'events',
		array(
			'labels' => array(
				'name' => __( 'Events', 'caresland'),
				'singular_name' => __( 'Events', 'caresland' )
			),
		'has_archive'	=> true,
		'public' 		=> true,
		'supports' 		=> array('title','editor','thumbnail','custom-fields')
		)
	);
}
function cwp_events_init() {
		// create a new taxonomy
		register_taxonomy(
			'events_category',
			'events',
			array(
					'hierarchical'        => true, 
					'show_ui'             => true,
					'show_admin_column'   => true,
					'query_var'           => true,
					'rewrite'             => array( 'slug' => 'events_category' )
			)
		);
	}
add_action( 'init', 'cwp_events_init' );

/* 
 * Testimonial taxionomy 
 */
add_action( 'init', 'cwp_create_post_type_testimonials' );
function cwp_create_post_type_testimonials() {
	register_post_type( 'testimonials',
		array(
			'labels' => array(
				'name' => __( 'Testimonials', 'caresland'),
				'singular_name' => __( 'Testimonials', 'caresland' )
			),
		'has_archive'	=> true,
		'public' 		=> true,
		'supports' 		=> array('title','editor')
		)
	);
}


/*
 * Search only post
 */
function cwp_SearchFilter($query) {
	if ($query->is_search) {
		$query->set('post_type', 'post');
	}
	return $query;
}
add_filter('pre_get_posts','cwp_SearchFilter');




add_filter( 'cmb_meta_boxes', 'cwp_sample_metaboxes' );
/**
 * Define the metabox and field configurations.
 *
 * @param  array $meta_boxes
 * @return array
 */
function cwp_sample_metaboxes( array $meta_boxes ) {

	// Start with an underscore to hide fields from custom fields list
	$prefix = '_cwp_';


	$meta_boxes['event_metabox'] = array(
		'id'         => 'event_metabox',
		'title'      => __( 'Event details', 'caresland' ),
		'pages'      => array( 'events', ), // Post type
		'context'    => 'normal',
		'priority'   => 'high',
		'show_names' => true, // Show field names on the left
		
		'fields'     => array(
			array(
				'name' => __( 'Date / Time', 'caresland' ),
				'id'   => $prefix . 'date_time_events',
				'type' => 'text_datetime_timestamp',
			),						
			array(
				'name' => __( 'Address', 'caresland' ),
				'id'   => $prefix . 'address_event',
				'type' => 'text'
			),
			array(
				'name' => __( 'Google Map Code', 'caresland' ),
				'id'   => $prefix . 'google_map_event',
				'type' => 'textarea_code',
			),			
		),
	);


	// Add other metaboxes as needed

	return $meta_boxes;
}

add_action( 'init', 'cwp_initialize_cwp_meta_boxes', 9999 );
/**
 * Initialize the metabox class.
 */
function cwp_initialize_cwp_meta_boxes() {

	if ( ! class_exists( 'cmb_Meta_Box' ) )
		require_once get_template_directory() . '/plugins/custom-metaboxes/init.php';

}

function cwp_add_editor_styles() {
    add_editor_style( '/css/custom-editor-style.css' );
}
add_action( 'init', 'cwp_add_editor_styles' );

 require 'inc/cwp-update.php'; 

