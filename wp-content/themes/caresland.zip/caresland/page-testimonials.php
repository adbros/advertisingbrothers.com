<?php
/*
Template Name: Testimonials page
*/
?>

<?php get_header(); ?>


<div class="full-content-body ">
            <div class="container">

                <div class="line-orange"></div>

                <div class="content-wrap">
                    <div class="content-inside">

					<?php if ( have_posts() ) : the_post(); ?>
                    <header class="page-header">
                        <h1 class="main-title">
                            <?php the_title(); ?>
                        </h1>
                        <?php the_content('<div class="taxonomy-description">%s</div>'); ?>
                    <?php endif; ?>       
                
                    </header><!-- .page-header -->
        
                    <?php
                
                        $paged = get_query_var('paged') ? get_query_var('paged') : 1;
                        $wp_query = new WP_Query(array('post_type' => 'testimonials',
                                                 'paged' 			=> $paged,
												 )
                                           );
                        while ($wp_query->have_posts()) : $wp_query->the_post();
                        
                            get_template_part( 'content', 'testimonials' );
                                
                        endwhile;
                
                                if (function_exists("cwp_pagination")) {
                                    cwp_pagination();
                                } else{
                                    codeinwp_paging_nav();
                                } 
                                
                        wp_reset_query();		
                        ?>
                                </div><!-- .content-inside -->
                            <div class="botttom-box-shadow-center"></div>
                            <div class="botttom-box-shadow-left"></div>
                            <div class="botttom-box-shadow-right"></div>
        
                        </div>
             	</div><!-- .container -->
        </div>
<?php get_footer(); ?>