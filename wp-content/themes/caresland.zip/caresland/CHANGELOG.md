

### 1.0.5 - 13/11/2014

 Changes: 


 * Fix for update system.


### 1.0.4 - 11/11/2014

 Changes: 


 * added page with sidebar template and static frontpage with template
 * This fixes #3, remove link from footer


### 1.0.3 - 17/10/2014

 Changes: 


 * Create CHANGELOG
 * version change
 * version changes
 * Small fix - slider labels in customizer
 * Small fix - submit button width
 * Changed link in footer
 * Updated theme uri, documentation link and forum link
 * small fix, documentation link
 * i18n and l10n and rtl-support
