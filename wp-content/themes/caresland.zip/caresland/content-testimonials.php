<?php
/**
 * The template used for displaying page content in testimonials.php
 *
 * @package codeinwp
 */
?>

<article id="post-<?php the_ID(); ?>" class="testimonial-wrap">

    <div class="testimonial-box">
    	<p><span class="before"></span></p>
                <?php the_content(); ?>
        <p><span class="after"></span></p>
        <p class="author-test"><?php the_title(); ?></p>
    </div> 
 
</article><!-- .event-wrap-box -->