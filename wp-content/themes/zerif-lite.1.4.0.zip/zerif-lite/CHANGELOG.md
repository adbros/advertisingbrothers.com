

### 1.3.5 - 19/11/2014

 Changes: 


 * Update home.php
 * Update style.css


### 1.3.4 - 19/11/2014

 Changes: 


 * fixed form subject issue, added linkedin icon and icons for socials, our focus clickable, contact section button and email, link on read more
 * Added pro extra options in customizer
 * woocommerce , wpml and rtl support, fixed undefined index errors, changed description,  added more themes page and fixed front page
 * fixed wrong description, links and tagline

fixed wrong description, links and tagline
 * Fixed fotter and added woocommerce style
 * Frontpage template
 * Fixed wp.org fronpage and blog
 * Update home.php


### 1.1 - 23/10/2014

 Changes: 


 * Fixed dropdown menu
 * Updated theme version


### 1.0.9 - 21/10/2014

 Changes: 


 * Fixed fonts, added fontawesome   notification   footer links

Fixed fonts, added fontawesome   notification   footer links


### 1.0.7 - 21/10/2014

 Changes: 


 * removed widget customizer plugin
 * Update style.css


### 1.0.6 - 20/10/2014

 Changes: 


 * Update functions.php
 * fixed the font issue with https websites


### 1.0.5 - 17/10/2014

 Changes: 


 * First version
 * some fixes for responsive
 * I added <Product Rewiew> and <Tweet old post> plugin
 * removed error.log
 * sync with wp.org
