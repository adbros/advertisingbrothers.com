jQuery(document).ready(function() {

	jQuery('#mobilenavexpand').click(function() {

		if( jQuery('#mobilenav').hasClass('close_menu') )
			jQuery('#mobilenav').addClass('open_menu').removeClass('close_menu');
		else
			jQuery('#mobilenav').addClass('close_menu').removeClass('open_menu');

	});		
	

	var container = document.querySelector('#columns');

	var msnry = new Masonry( container, {

	  // options

	  columnWidth: 50,

	  itemSelector: '.posttwofull'

	});



	jQuery('#headernav li.home a').text("");



	jQuery(function() {

		jQuery('.toggle-title').click(function() {

			jQuery(this).siblings().slideToggle();

		});		

	});



	jQuery(function(){

	

		if(jQuery(".testimonial").length > 1) {

	

		  jQuery("#slides").slidesjs({

			width: 940,

			height: 300,

			navigation: {

			  active: false,

				// [boolean] Generates next and previous buttons.

				// You can set to false and use your own buttons.

				// User defined buttons must have the following:

				// previous button: class="slidesjs-previous slidesjs-navigation"

				// next button: class="slidesjs-next slidesjs-navigation"

			  effect: "slide"

				// [string] Can be either "slide" or "fade".

			},

			pagination: {

			  active: false,

				// [boolean] Create pagination items.

				// You cannot use your own pagination. Sorry.

			  effect: "slide"

				// [string] Can be either "slide" or "fade".

			},

			play: {

			  active: false,

				// [boolean] Generate the play and stop buttons.

				// You cannot use your own buttons. Sorry.

			  effect: "slide",

				// [string] Can be either "slide" or "fade".

			  interval: 5000,

				// [number] Time spent on each slide in milliseconds.

			  auto: true,

				// [boolean] Start playing the slideshow on load.

			  swap: false,

				// [boolean] show/hide stop and play buttons

			  pauseOnHover: false,

				// [boolean] pause a playing slideshow on hover

			  restartDelay: 2500

				// [number] restart delay on inactive slideshow

			}

		  });

	  }

    });



	jQuery('#searchicon').click(function() {

		if(jQuery('#searchexpand').hasClass('nod'))

			jQuery('#searchexpand').removeClass('nod');

		else

			jQuery('#searchexpand').addClass('nod');

	});	



	jQuery('#twitter').sharrre({

	  share: {

		twitter: true

	  },

	  enableHover: false,

	  enableTracking: true,

	  buttons: { twitter: {via: ''}},

	  click: function(api, options){

		api.simulateClick();

		api.openPopup('twitter');

	  }

	});

	jQuery('#facebook').sharrre({

	  share: {

		facebook: true

	  },

	  enableHover: false,

	  enableTracking: true,

	  click: function(api, options){

		api.simulateClick();

		api.openPopup('facebook');

	  }

	});

	jQuery('#googleplus').sharrre({

	  share: {

		googlePlus: true

	  },

	  urlCurl: jQuery('#hiddenSpan').text() + '/sharrre.php',

	  enableHover: false,

	  enableTracking: true,

	  click: function(api, options){

		api.simulateClick();

		api.openPopup('googlePlus');

	  }

	});

});