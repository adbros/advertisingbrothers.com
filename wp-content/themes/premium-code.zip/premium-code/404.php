<?php
/**
 * The template for displaying 404 pages (Not Found).
 *
 * @package premium-code
 */
get_header(); 

$title_404 = cwp('404page_title');
if(isset($title_404) && $title_404 != ''):
	echo '<div class="generalheadline">';
		echo '<h3>'.$title_404.'</h3>';
	echo '</div>';
endif;
?>
<div id="wrap">
	<div class="portfoliohead">
	<?php
		$text_404 = cwp('404page_text');
		if(isset($text_404) && $text_404 != '')
			echo '<p>'.$text_404.'</p>';
	?>
		<div class="ordernow"><a href="<?php echo home_url('/'); ?>"><?php _e('Go Home','premium-code-pro'); ?></a></div>
	</div><!--/portfoliohead-->
	<span class="erroror"><?php _e('or','premium-code-pro'); ?></span>
	<div class="sidebarsearch error-search">
		<?php get_search_form(); ?>
	</div><!--/sidebarsearch-->
</div><!--/wrap-->
<?php get_footer(); ?>