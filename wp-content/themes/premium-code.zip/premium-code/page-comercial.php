<?php
/**
 * Template Name: Comercial template
 */
get_header(); ?>
<?php
	$fp_slider = cwp('fp_slider');

	if (function_exists('putRevSlider') && isset($fp_slider) && $fp_slider == 'slider_yes') {
		putRevSlider( "front-page-slider" ); 
	}	
?>
<div id="wrap">
	<?php get_sidebar('comercial'); ?>
</div><!--/wrap-->
<?php get_footer(); ?>