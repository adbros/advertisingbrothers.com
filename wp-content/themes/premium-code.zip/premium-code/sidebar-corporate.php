<?php
	if ( is_active_sidebar( 'corporate-sidebar' ) ) :
		dynamic_sidebar( 'corporate-sidebar' ); 
	else:
		the_widget('featuresLargeWidget', 'title1='.__("First box","premium-code-pro").'&title2='.__("Second box","premium-code-pro").'&title3='.__("Third box","premium-code-pro").'&text1='.__("Text goes here","premium-code-pro").'&text2='.__("Text goes here",'premium-code-pro').'&text3='.__("Text goes here","premium-code-pro"));

		the_widget('aboutUsWidget', 'text='.__("As you may have gathered from our website, our team is focused exclusively on Wordpress. We work primarily with agency partners or freelancers such as yourself, acting as their remote development team, we are not the cheapest provider on the market , but what sets us apart is that:We have worked with clients like Qualtrics and we have released wordpress.org approved themes,We are fully transparent , you will work with people not with a website,We have reduced the cost of web-development in average with 60% for the agencies that we are working with and We charge just 50% upfront on first project compared with other agencies, because we understand that trust is important","premium-code-pro").'&left_tile='.__("What we provide for our customers","premium-code-pro").'&right_title='.__("About our services","premium-code-pro").'&left_title='.__("What we provide for our customers.","premium-code-pro").'&right_subtitle=');

		echo do_shortcode('[half_width title=""][tabs][tab title="tab1" content="content1"][/tab][tab title="tab2" content="content2"][/tab][/tabs][/half_width]');

		the_widget('testimonialsWidget', 'nr_of_testimonials=2');

		the_widget('ourWorkWidget', 'widget_text_latest='.__("It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using Content here, content here, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for lorem ipsum will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).","premium-code-pro"));

		the_widget('priceTablesWidget', 'widget_text=medicenter_turquoise');
	endif;
?>	