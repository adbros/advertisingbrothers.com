<?php
	class cwpConfig{
		public static $admin_page_menu_name ;
		public static  $admin_page_title 	;
		public static  $admin_page_header 	;
		public static  $admin_template_directory ;
		public static  $admin_template_directory_uri ;
		public static  $admin_uri 	;
		public static $admin_path  ;
		public static  $menu_slug 	;
		public static $structure;
		public static function init(){
			self::$admin_page_menu_name 	 = "Theme Options";
			self::$admin_page_title 		 = "Theme Options";
			self::$admin_page_header	 	 = "Theme Options";
			self::$admin_template_directory_uri  = get_template_directory_uri() . '/admin/layout';
			self::$admin_template_directory  = get_template_directory() . '/admin/layout';
			self::$admin_uri  		= 	get_template_directory_uri() . '/admin/'; 
			self::$admin_path 	 	= 	get_template_directory() . '/admin/';
			self::$menu_slug  		= 	"theme_options";
			self::$structure	= array(
						array(
							 "type"=>"tab",
							 "name"=>__("General options",'premium-code-pro'),
							 "options"=>array(
								array(
									"type"=>"input_text",
									"name"=>__("Title for 404 pages",'premium-code-pro'),
									"description"=>__("Enter a title to appear on the 404 pages.If you leave this empty, no title will appear.",'premium-code-pro'),
									"id"=>"404page_title",
									"default"=>__("Premium Code - 404 - Sorry, Page not found!",'premium-code-pro')
								),
								array(
									"type"=>"editor",
									"name"=>__("Text for 404 pages",'premium-code-pro'),
									"description"=>__("Enter some text to appear on the 404 pages.If you leave this empty, no text will appear.",'premium-code-pro'),
									"id"=>"404page_text",
									"default"=>__("We are sorry, the page you are looking is doesn't exist on this server.</h4><p>You're looking for something that doesn't actually exits... Try going to our page or search for what you need.",'premium-code-pro')
								),
								array(
									"type"=>"input_text",
									"name"=>__("Text after 'Leave a comment'",'premium-code-pro'),
									"description"=>__("Enter a text to appear after 'Leave a comment', before the comment form.If you leave this empty, no text will appear.",'premium-code-pro'),
									"id"=>"leave_comm_text",
									"default"=>""
								),
								
								array(
									"type"=>"image",
									"name"=>__("Header Logo",'premium-code-pro'),
									"description"=>__("Choose an image for the logo in the header",'premium-code-pro'),
									"id"=>"logo",
									"default"=>"/images/headerlogo.png" 
								),
								
								array(
									"type"=>"image",
									"name"=>__("Header Logo - for mobile",'premium-code-pro'),
									"description"=>__("Choose an image for the logo in the header on mobile devices",'premium-code-pro'),
									"id"=>"logo_mobile",
									"default"=>"/images/rwdlogo.png" 
								),
								
								array(
									"type"=>"select",
									"name"=>__("Layout for search page and archive page",'premium-code-pro'),
									"description"=>__("Select the layout for the search and archive pages",'premium-code-pro'),
									"id"=>"page_layout",
									"options"=>array(
												"select_opt1"=>__("1 column ( top image ) + sidebar",'premium-code-pro'),
												"select_opt2"=>__("1column ( left image ) + sidebar",'premium-code-pro'),
												"select_opt3"=>__("1column ( right image ) + sidebar",'premium-code-pro'),
												"select_opt4"=>__("1column ( left image ) no sidebar",'premium-code-pro'),
												"select_opt5"=>__("1column ( right image ) no sidebar",'premium-code-pro'),
												"select_opt6"=>__("2columns - no sidebar",'premium-code-pro'),
												"select_opt7"=>__("2columns - 2columns - with sidebar",'premium-code-pro')
											),
									"default"=>"select_opt1"
								),
								
							 )
						),
						
						array(
								"type"=>"tab",
								"name"=>__("Front page options",'premium-code-pro'),
								"options"=>array(
										array(
											"type"=>"select",
											"name"=>__("Front page slider",'premium-code-pro'),
											"description"=>__("Choose if you want a slider on the front page (You must have installed the Revolution Slider plugin and a slider with slider alias as 'front-page-slider')",'premium-code-pro'),
											"id"=>"fp_slider",
											"options"=>array(
												"slider_yes"=>__("Show",'premium-code-pro'),
												"slider_no"=>__("Hide",'premium-code-pro')
											),
											"default"=>"slider_yes"
										)
										
								)
							),
						
						array(
							 "type"=>"tab",
							 "name"=>__("Single post page options",'premium-code-pro'),
							 "options"=>array(
									 array(
										"type"=>"checkbox",
                                        "name"=>__("Post details",'premium-code-pro'),
                                        "description"=>__("Choose the details you want to show on the single posts page",'premium-code-pro'),
                                        "id"=>"post_details",
											"options"=>array(
													"post_details_date"=>__("Post date",'premium-code-pro'),
                                                    "post_details_comments"=>__("Number of comments",'premium-code-pro'),
                                                    "post_details_author"=>__("Post author name",'premium-code-pro'),
                                                    "post_details_category"=>__("Post category",'premium-code-pro'),
                                            ),
                                            "default"=>array("post_details_date","post_details_comments","post_details_author","post_details_category")
                                    ),
									array(
											"type"=>"select",
											"name"=>__("Featured image",'premium-code-pro'),
											"description"=>__("Choose if you want to display the featured image on single pages",'premium-code-pro'),
											"id"=>"featured_image_posts",
											"options"=>array(
												"featured_image_posts_yes"=>__("Show",'premium-code-pro'),
												"featured_image_posts_no"=>__("Hide",'premium-code-pro')
											),
											"default"=>"featured_image_posts_yes"
									),
									array(
											"type"=>"select",
											"name"=>__("Related posts",'premium-code-pro'),
											"description"=>__("Choose if you want to have a 'Related posts' section on single pages",'premium-code-pro'),
											"id"=>"related_posts",
											"options"=>array(
												"related_posts_yes"=>__("Show",'premium-code-pro'),
												"related_posts_no"=>__("Hide",'premium-code-pro')
											),
											"default"=>"related_posts_yes"
									),
									array(
											"type"=>"select",
											"name"=>__("About author",'premium-code-pro'),
											"description"=>__("Choose if you want to have a 'About author' section on single pages",'premium-code-pro'),
											"id"=>"about_author_posts",
											"options"=>array(
												"about_author_posts_yes"=>__("Show",'premium-code-pro'),
												"about_author_posts_no"=>__("Hide",'premium-code-pro')
											),
											"default"=>"about_author_posts_yes"
									),
									array(
											"type"=>"select",
											"name"=>__("Tags",'premium-code-pro'),
											"description"=>__("Choose if you want to show tags on single pages",'premium-code-pro'),
											"id"=>"tags_posts",
											"options"=>array(
												"tags_posts_yes"=>__("Show",'premium-code-pro'),
												"tags_posts_no"=>__("Hide",'premium-code-pro')
											),
											"default"=>"tags_posts_yes"
									),
									array(
											"type"=>"select",
											"name"=>"Facebook",
											"description"=>__("Choose if you want to have a facebook share button on single pages",'premium-code-pro'),
											"id"=>"facebook",
											"options"=>array(
												"facebook_yes"=>__("Show",'premium-code-pro'),
												"facebook_no"=>__("Hide",'premium-code-pro')
											),
											"default"=>"facebook_yes"
									),
									array(
											"type"=>"select",
											"name"=>"Twitter",
											"description"=>__("Choose if you want to have a twitter share button on single pages",'premium-code-pro'),
											"id"=>"twitter",
											"options"=>array(
												"twitter_yes"=>__("Show",'premium-code-pro'),
												"twitter_no"=>__("Hide",'premium-code-pro')
											),
											"default"=>"twitter_yes"
									),
									array(
											"type"=>"select",
											"name"=>"Google plus",
											"description"=>__("Choose if you want to have a google plus share button on single pages",'premium-code-pro'),
											"id"=>"google_plus",
											"options"=>array(
												"google_plus_yes"=>__("Show",'premium-code-pro'),
												"google_plus_no"=>__("Hide",'premium-code-pro')
											),
											"default"=>"google_plus_yes"
									)
									
									
							)
						),
						array(
							 "type"=>"tab",
							 "name"=>__("Single product page options",'premium-code-pro'),
							 "options"=>array(	
										array(
											"type"=>"select",
											"name"=>__("Related products",'premium-code-pro'),
											"description"=>__("Choose if you want to have a 'Related products' section on single product pages",'premium-code-pro'),
											"id"=>"related_products",
											"options"=>array(
												"related_products_yes"=>__("Show",'premium-code-pro'),
												"related_products_no"=>__("Hide",'premium-code-pro')
											),
											"default"=>"related_products_yes"
										),
										array(
											"type"=>"input_text",
											"name"=>__("Related products text",'premium-code-pro'),
											"description"=>__("Enter a text to appear in the related products section.If you leave this empty, no text will appear.",'premium-code-pro'),
											"id"=>"related_products_text",
											"default"=>__("awesome work done for our customers",'premium-code-pro')
										),	
										array(
											"type"=>"select",
											"name"=>__("Featured image",'premium-code-pro'),
											"description"=>__("Choose if you want to display the featured image on single product pages",'premium-code-pro'),
											"id"=>"featured_image_products",
											"options"=>array(
												"featured_image_products_yes"=>__("Show",'premium-code-pro'),
												"featured_image_products_no"=>__("Hide",'premium-code-pro')
											),
											"default"=>"featured_image_products_yes"
										)
							)
						),
						array(
							 "type"=>"tab",
							 "name"=>__("Footer options",'premium-code-pro'),
							 "options"=>array(	
										array(
											"type"=>"input_text",
											"name"=>__("Copyright",'premium-code-pro'),
											"description"=>__("Enter text for copyright",'premium-code-pro'),
											"id"=>"copyright",
											"default"=>__("All Rights Reserved.",'premium-code-pro')
										),
										array(
											"type"=>"image",
											"name"=>__("Footer Logo",'premium-code-pro'),
											"description"=>__("Choose an image for the logo in the footer",'premium-code-pro'),
											"id"=>"logo_footer",
											"default"=>"" 
										)
							)
						),
						array(
							 "type"=>"tab",
							 "name"=>__("Socials",'premium-code-pro'),
							 "options"=>array(	
										array(
											"type"=>"input_text",
											"name"=>"Facebook",
											"description"=>__("Enter your facebook link. If you leave this empty the Facebook button won't appear.",'premium-code-pro'),
											"id"=>"facebook_link",
											"default"=>"#"
										),
										array(
											"type"=>"input_text",
											"name"=>"Twitter",
											"description"=>__("Enter your twitter link. If you leave this empty the Twitter button won't appear.",'premium-code-pro'),
											"id"=>"twitter_link",
											"default"=>"#"
										),
										array(
											"type"=>"input_text",
											"name"=>"Pinterest",
											"description"=>__("Enter your pinterest link. If you leave this empty the Pinterest button won't appear.",'premium-code-pro'),
											"id"=>"pinterest_link",
											"default"=>"#"
										),
										array(
											"type"=>"input_text",
											"name"=>"Youtube",
											"description"=>__("Enter your youtube link. If you leave this empty the Youtube button won't appear.",'premium-code-pro'),
											"id"=>"youtube_link",
											"default"=>"#"
										),
										array(
											"type"=>"input_text",
											"name"=>"Linkedin",
											"description"=>__("Enter your linkedin link. If you leave this empty the Linkedin button won't appear.",'premium-code-pro'),
											"id"=>"linkedin_link",
											"default"=>"#"
										),
										array(
											"type"=>"input_text",
											"name"=>"Flickr",
											"description"=>__("Enter your flickr link. If you leave this empty the flickr button won't appear.",'premium-code-pro'),
											"id"=>"flickr_link",
											"default"=>"#"
										),
										array(
											"type"=>"input_text",
											"name"=>"Google plus",
											"description"=>__("Enter your google plus link. If you leave this empty the Google plus button won't appear.",'premium-code-pro'),
											"id"=>"googleplus_link",
											"default"=>"#"
										),
										array(
											"type"=>"input_text",
											"name"=>"RSS",
											"description"=>__("Enter your RSS link. If you leave this empty the RSS button won't appear.",'premium-code-pro'),
											"id"=>"rss_link",
											"default"=>"#"
										)
							)
						),
						array(
							 "type"=>"tab",
							 "name"=>__("Contact page",'premium-code-pro'),
							 "options"=>array(	
								array(
									"type"=>"input_text",
									"name"=>__("Phone number",'premium-code-pro'),
									"description"=>__("Enter the phone number",'premium-code-pro'),
									"id"=>"phone",
									"default"=>"703-858-5558"
								),
								array(
									"type"=>"input_text",
									"name"=>__("Email address",'premium-code-pro'),
									"description"=>__("Enter the email address",'premium-code-pro'),
									"id"=>"email",
									"default"=>""
								),
								array(
									"type"=>"input_text",
									"name"=>__("Address",'premium-code-pro'),
									"description"=>__("Enter the address",'premium-code-pro'),
									"id"=>"address",
									"default"=>""
								),
								array(
									"type"=>"input_text",
									"name"=>__("Google map address",'premium-code-pro'),
									"description"=>__("Enter an address for the google map.If you leave this empty the google map won't appear.",'premium-code-pro'),
									"id"=>"map_address",
									"default"=>__("Strada Fainari, Sector 2, Bucuresti, Romania",'premium-code-pro')
								)
							)
						)
					); 
			 
		}	 
	
	} 
