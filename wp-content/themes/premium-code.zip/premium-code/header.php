<?php

/**

 * The Header for our theme.

 *

 * Displays all of the <head> section and everything up till <main id="main">

 *

 * @package cwp

 */

?><!DOCTYPE html>

<html <?php language_attributes(); ?>>

<head>

<meta charset="<?php bloginfo( 'charset' ); ?>">

<meta name="viewport" content="width=device-width">

<title><?php wp_title( '|', true, 'right' ); ?></title>

<link rel="profile" href="http://gmpg.org/xfn/11">

<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">

<!--[if lt IE 9]>

	<script src="js/html5.js" type="text/javascript"></script>

	<link rel="stylesheet" type="text/css" href="ie.css" media="screen" />	

<![endif]-->



<?php wp_head(); ?>

</head>



	<?php

	$map_address = cwp('map_address');

	if(isset($map_address) & $map_address != '') {

	?>

		<body <?php body_class(); ?> onLoad="initialize();showAddress('<?php echo $map_address; ?>');">

	<?php

	}

	else {

	?>

		<body <?php body_class(); ?> >

	<?php

	}

	?>





	<span class="hiddenSpan"><?php echo get_template_directory_uri(); ?></span>	

		<header id="top">

			<div id="searchexpand" class="nod">

				<fieldset>


                    <form role="search" method="get" id="searchform" action="<?php echo home_url( '/' ); ?>">
                            <input type="text" value="" name="s" id="s" class="search" />
                            <input type="submit" id="searchsubmit" class="submit" value=" " />
                    </form>
				</fieldset>

			</div><!--/searchexpand-->

			<div id="topbar">

				<div id="topbarcenter">

					<nav id="headernav">

						<?php wp_nav_menu( array( 'theme_location' => 'primary' ) ); ?>

					</nav><!--/headernav-->

					<!-- Mobile -->

					<div id="mobilenavexpand" class="nod"></div><!--/mobile nav expand button-->

					<?php

					$logo_mobile = cwp('logo_mobile');

					if(isset($logo_mobile)):

						echo '<div id="rwdlogo" class="nod"><a href="'.esc_url( home_url( '/' ) ).'">';

						if($logo_mobile == '/images/rwdlogo.png'):

							echo '<img src="'.get_template_directory_uri().'/images/rwdlogo.png" alt="'.get_bloginfo('name').'">';

						else:

							echo '<img src="'.$logo_mobile.'" alt="'.get_bloginfo('name').'">';

						endif;

						echo '</a></div>';

					endif;

					?>

				

					

					<!-- Mobile -->

					<div id="searchicon">

						<div class="icon"></div>

						<div class="iconhover"></div>

					</div><!--/searchicon-->

				</div><!--/topbarcenter-->

			</div><!--/topbar-->

			<!-- Mobile -->

			<nav id="mobilenav" class="close_menu">
<!--
				<a href="">Pages</a>

				<a href="">Features</a>

				<a href="">Blog</a>

				<a href="">Contact</a>
-->

				<?php wp_nav_menu( array( 'theme_location' => 'primary' ) ); ?>

			</nav><!--/mobile menu-->

			<!-- Mobile -->

			<div id="headercenter">

				<?php

					$logo = cwp('logo');

					if(isset($logo)):

						echo '<div id="logo"><a href="'.esc_url( home_url( '/' ) ).'">';

						if($logo == '/images/headerlogo.png'):

							echo '<img src="'.get_template_directory_uri().'/images/headerlogo.png" alt="'.get_bloginfo('name').'">';

						else:

							echo '<img src="'.$logo.'" alt="'.get_bloginfo('name').'">';

						endif;

						echo '</a></div>';

					endif;

					

					

					$facebook_link = cwp('facebook_link');

					$twitter_link = cwp('twitter_link');

					$pinterest_link = cwp('pinterest_link');

					$youtube_link = cwp('youtube_link');

					$linkedin_link = cwp('linkedin_link');

					$flickr_link = cwp('flickr_link');

					$googleplus_link = cwp('googleplus_link');

					$rss_link = cwp('rss_link');

					

					if( (isset($facebook_link) && $facebook_link != '') || (isset($twitter_link) && $twitter_link != '') || (isset($pinterest_link) && $pinterest_link != '') || (isset($youtube_link) && $youtube_link != '') || (isset($linkedin_link) && $linkedin_link != '') || (isset($flickr_link) && $flickr_link != '') || (isset($googleplus_link) && $googleplus_link != '') || (isset($rss_link) && $rss_link != '')):

					

					echo '<div id="socialmedia">';

					if(isset($facebook_link) && $facebook_link != ''):

						echo '<a href="'.$facebook_link.'">';

							echo '<div class="item">';

							echo '<div class="icon facebook"></div>';

							echo '<div class="iconh facebookh"></div>';

						echo '</div></a>';

					endif;

					if(isset($twitter_link) && $twitter_link != ''):

						echo '<a href="'.$twitter_link.'">';

							echo '<div class="item">';

							echo '<div class="icon twitter"></div>';

							echo '<div class="iconh twitterh"></div>';

						echo '</div></a>';

					endif;

					if(isset($pinterest_link) && $pinterest_link != ''):

						echo '<a href="'.$pinterest_link.'">';

							echo '<div class="item">';

							echo '<div class="icon pinterest"></div>';

							echo '<div class="iconh pinteresth"></div>';

						echo '</div></a>';

					endif;

					if(isset($youtube_link) && $youtube_link != ''):

						echo '<a href="'.$youtube_link.'">';

							echo '<div class="item">';

							echo '<div class="icon youtube"></div>';

							echo '<div class="iconh youtubeh"></div>';

						echo '</div></a>';

					endif;

					if(isset($linkedin_link) && $linkedin_link != ''):

						echo '<a href="'.$linkedin_link.'">';

							echo '<div class="item">';

							echo '<div class="icon linkedin"></div>';

							echo '<div class="iconh linkedinh"></div>';

						echo '</div></a>';

					endif;

					if(isset($flickr_link) && $flickr_link != ''):

						echo '<a href="'.$flickr_link.'">';

							echo '<div class="item">';

							echo '<div class="icon flickr"></div>';

							echo '<div class="iconh flickrh"></div>';

						echo '</div></a>';

					endif;

					if(isset($googleplus_link) && $googleplus_link != ''):

						echo '<a href="'.$googleplus_link.'">';

							echo '<div class="item">';

							echo '<div class="icon googleplus"></div>';

							echo '<div class="iconh googleplush"></div>';

						echo '</div></a>';

					endif;

					if(isset($rss_link) && $rss_link != ''):

						echo '<a href="'.$rss_link.'">';

							echo '<div class="item">';

							echo '<div class="icon rss"></div>';

							echo '<div class="iconh rssh"></div>';

						echo '</div></a>';

					endif;

					echo '</div>';

					endif;

				?>

				

			</div><!--/headercenter-->

		</header>

		<img src="<?php header_image(); ?>" height="<?php echo get_custom_header()->height; ?>" width="<?php echo get_custom_header()->width; ?>" alt="" />



