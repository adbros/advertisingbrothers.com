

### 1.0.4 - 01/11/2014

 Changes: 


 * Fixed  theme options for wordpress 4.0
 * Update theme version to 1.0.4


### 1.0.3 - 17/10/2014

 Changes: 


 * Create CHANGELOG
 * Update CHANGELOG
 * Update style.css
 * Changed link in footer
 * am adaugat margina la boxul de About us pe homepage. La sectiunea Our work se vedeam prost imaginile, am aranjat putin search-ul din sidebar, pagina de portofoliu -> acum se poate adauga si text, contact page -> am reparat problema de la textarea
 * Updated theme uri, documentation link and forum link
 * Localization of theme
 * Generate pot file
 * RTL support
