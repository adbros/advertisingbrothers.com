<?php
	if ( is_active_sidebar( 'comercial-sidebar' ) ) :
		dynamic_sidebar( 'comercial-sidebar' ); 
	else:
		the_widget('featuresWidget', 'title1='.__("First box","premium-code-pro").'&title2='.__("Second box","premium-code-pro").'&title3='.__("Third box","premium-code-pro").'&text1='.__("Text goes here","premium-code-pro").'&text2='.__("Text goes here","premium-code-pro").'&text3='.__("Text goes here","premium-code-pro"));

		the_widget('priceTablesWidget', 'widget_text=medicenter_turquoise');

		the_widget('columnsWidget', 'title1='.__("First box","premium-code-pro").'&title2='.__("Second box","premium-code-pro").'&title3='.__("Third box","premium-code-pro").'&title4='.__("Fourth box","premium-code-pro").'&text1='.__("Text goes here","premium-code-pro").'&text2='.__("Text goes here","premium-code-pro").'&text3='.__("Text goes here","premium-code-pro").'&text4='.__("Text goes here",'premium-code-pro'));

		echo do_shortcode('[half_width title=""][tabs][tab title="tab1" content="content1"][/tab][tab title="tab2" content="content2"][/tab][/tabs][/half_width]');

		the_widget('testimonialsWidget', 'nr_of_testimonials=2');
	endif;
?>	