<?php 	
	/*		
	Template Name: Portofolio 2-3 cols	
	*/
?>
<?php get_header(); ?>
<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>		
<div class="generalheadline">			
	<h3><?php the_title(); ?></h3>		
</div><!--/generalheadline-->		
<div id="wrap">			
			<?php
				$cpi_portofolio_title_option = get_post_meta($id, 'cpi_portofolio_title_option');
				$text_portofolio = cwp('text_portofolio');
				$button_portofolio = cwp('button_portofolio');
				$button_portofolio_link = cwp('button_portofolio_link');
				
				if((isset($cpi_portofolio_title_option[0]) && $cpi_portofolio_title_option[0] != '') || (isset($button_portofolio) && $button_portofolio == 'button_portofolio_show') || (isset($button_portofolio) && $button_portofolio == 'button_portofolio_show')):
				
					echo '<div class="portfoliohead">';		
						
						if(isset($cpi_portofolio_title_option[0]) && $cpi_portofolio_title_option[0] != '')
							echo '<h4>'.$cpi_portofolio_title_option[0].'</h4>';
						
						if(isset($text_portofolio) && $text_portofolio == 'text_portofolio_show')
							the_content();
						
						if(isset($button_portofolio) && $button_portofolio == 'button_portofolio_show'):
							if(isset($button_portofolio_link) && $button_portofolio_link != ''):
								echo '<div class="ordernow"><a href="'.$button_portofolio_link.'" target="_blank">'.__('Order Now','premium-code-pro').'</a></div>';
							endif;
						endif;	
					echo '</div>';	
				endif;	
			?>			
	<div id="portfolio-two">							
				<?php
					global $paged, $wp_query, $wp;
					if  ( empty($paged) ) {
							if ( !empty( $_GET['paged'] ) ) {
									$paged = $_GET['paged'];
							} elseif ( !empty($wp->matched_query) && $args = wp_parse_args($wp->matched_query) ) {
									if ( !empty( $args['paged'] ) ) {
											$paged = $args['paged'];
									}
							}
							if ( !empty($paged) )
									$wp_query->set('paged', $paged);
					}      
					$temp = $wp_query;
					$wp_query= null;
					$wp_query = new WP_Query();
					$wp_query->query('paged='.$paged.'&post_type=product&showposts=16');

					while ($wp_query->have_posts()) : $wp_query->the_post();
						?>
							<div class="item">								
								<div class="imghover">									
									<div class="plink"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></div><!--/plink-->									
									<div class="plinkarr"><a href="<?php the_permalink(); ?>"> </a></div>																		<?php										if ( has_post_thumbnail($post->ID) ) :											$url = wp_get_attachment_url( get_post_thumbnail_id($post->ID,'lightbox-full') );											echo '<div class="pzoom"><a href="'.$url.'" data-lightbox="'.$post->ID.'" title=""></a></div>';											 										else:											echo '<div class="pzoom"><a href="'.get_template_directory_uri().'/images/portofolio1.png" data-lightbox="'.$post->ID.'" title=""></a></div>';										endif;									?>							
								</div><!--/imghover-->								
								<?php									
									if ( has_post_thumbnail($post->ID) ) {										
										echo get_the_post_thumbnail($post->ID, 'portofolio-style2-thumb'); 									
									}	
									else
										echo '<img src="'.get_template_directory_uri().'/images/portofolio2.png'.'">';
								?>							
							</div>		
						<?php
					endwhile;	
				?>
	</div><!-- #portfolio-two -->	
	<div id="generalnavi">
		<?php previous_posts_link('<span class="prev">'.__('Prev','premium-code-pro').'</span>') ?>
        <?php next_posts_link('<span class="next">'.__('Next','premium-code-pro').'</span>') ?>
		<?php $wp_query = null; $wp_query = $temp;?>
	</div><!--/generalnavi-->	
</div><!--/wrap-->				
	<div id="clients">			
		<div class="clientscenter">				
			<?php dynamic_sidebar('portofolio_area'); ?>
			<div class="clearfix"></div>		
		</div><!--/clientscenter-->		
	</div><!--/clients-->
<?php endwhile; endif; ?>		
<?php get_footer(); ?>