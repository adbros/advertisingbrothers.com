<?php
/*
  SHORTCODES
*/

/* tabs */
function tabs_group( $atts, $content = null ) {  
 
    $code = do_shortcode($content);

    return $code;  
}  
 
add_shortcode("tabs", "tabs_group");
 

 
function tab($atts, $content = null) {  
    extract(shortcode_atts(array(  
		'title' => 'title',
		'content'=>'content' 
    ), $atts));  
	
	$code = "";
	
	$code .= '<div class="toggle">';
	if(isset($title) && $title != "" && isset($content) && $content != ""):
		$code .= '<div class="toggle-title">';
			$code .= '<div class="icon"><img src="'.get_template_directory_uri().'/images/demo/toggle1.png" alt=""></div>';
				$code .= '<h3>'.$title.'</h3>';
			$code .= '</div>';

			$code .= '<div class="toggle-content">'.$content.'</div>';
	endif;
	$code .= '</div>';
   
    return $code;
}
add_shortcode("tab", "tab");

/* END - tabs */



/* simple buttons */
function cwp_simple_button( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'label' => 'label',
		'link' => 'url',
		'color' => 'red'
	), $atts ) );
 
	$code = '<div class="simplebutton '.$color.' fleft marginright"><a href="' . $link . '">' . $label . '</a></div>'; 
		
	return $code;
}
add_shortcode('simple_button', 'cwp_simple_button');

/* icons buttons */
function cwp_icons_button( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'type' => 'anchor',
		'link' => 'url',
		'color' => 'red',
		'caption' => 'caption'
 
	), $atts ) );
 
	$code = '<div class="simplebutton iconbutton '.$color.' fleft marginright"><a href="' . $link . '"><span class="'.$color.' fleft sicon '.$type.'"></span>' . $caption . '</a></div>'; 
		
	return $code;
}
add_shortcode('icons_button', 'cwp_icons_button');

/* call-to-action buttons */
function cwp_call_to_action_button( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'style' => '1',
		'link' => 'url',
		'color' => 'red',
		'caption' => 'caption'
 
	), $atts ) );
 
	switch ($style) {
		case 1:
			$button_style = 'style-one';
			break;
		case 2:
	 		$button_style = 'style-two';
			break;
		case 3:
	 		$button_style = 'style-three';
			break;										
	}
 
	if($style == '3')
		$code = '<div class="cta-button t'.$color.' '.$button_style.' fleft marginright"><a href="' . $link . '">' . $caption . '</a></div>'; 
	else
		$code = '<div class="cta-button '.$color.' '.$button_style.' fleft marginright"><a href="' . $link . '">' . $caption . '</a></div>';
		
	return $code;
}
add_shortcode('call_to_action_button', 'cwp_call_to_action_button');

/* Icons */
function cwp_icons( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'type' => 'anchor',
		'color' => 'red',
		'hover_effect' => '1'
 
	), $atts ) );
	
	switch ($hover_effect) {
		case 1:
			$hover_effect = 'sieffone';
			break;
		case 2:
	 		$hover_effect = 'siefftwo';
			break;
		case 3:
	 		$hover_effect = 'sieffthree';
			break;		
		case 4:
			$hover_effect = 'siefffour';
			break;
	}

	$code = '<span class="'.$color.' '.$type.' '.$hover_effect.' fleft sicon"></span>';
		
	return $code;
}
add_shortcode('icons', 'cwp_icons');

/* Round icons */
function cwp_round_icons( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'type' => 'anchor',
		'color' => 'red',
		'hover_effect' => '1'
 
	), $atts ) );

	switch ($hover_effect) {
		case 1:
			$hover_effect = 'sieffone';
			break;
		case 2:
	 		$hover_effect = 'siefftwo';
			break;
		case 3:
	 		$hover_effect = 'sieffthree';
			break;		
		case 4:
			$hover_effect = 'siefffour';
			break;
	}
	
	$code = '<span class="'.$color.' '.$type.' '.$hover_effect.' fleft sicon siround"></span>';
		
	return $code;
}
add_shortcode('round_icons', 'cwp_round_icons');

/* Dropcap */
function cwp_dropcap( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'style' => '1',
		'text' => 'text',
		'first_letter' => 'first_letter'
 
	), $atts ) );
	
	switch ($style) {
		case 1:
			$button_style = 'dropcapone';
			break;
		case 2:
	 		$button_style = 'dropcaptwo';
			break;
		case 3:
	 		$button_style = 'dropcapthree';
			break;					
		case 4:
	 		$button_style = 'dropcapfour';
			break;					
	}

	if($style == '1' || $style == '3') 
		$code = '<p class="'.$button_style.'">
						'.$first_letter.$text.'
					</p>';
	else 
		$code = '<p class="'.$button_style.'">
						<span>'.$first_letter.'</span>'.$text.'
					</p>';
	
	return $code;
}
add_shortcode('dropcap', 'cwp_dropcap');

/* Full width text */
function cwp_full_width( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'title' => 'title'
	), $atts ) );
	
	if(isset($title) && $title != '')
		$code = '<div class="headingone">'.$title.'</div><p>'.do_shortcode($content).'</p>';
	else	
		$code = '<p>'.do_shortcode($content).'</p>';
	return $code;
}
add_shortcode('full_width', 'cwp_full_width');

/* Half width text */
function cwp_half_width( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'title' => 'title'
	), $atts ) );
	
	if(isset($title) && $title != '')
		$code = '<div class="twohalf"><div class="headingone">'.$title.'</div><p>'.do_shortcode($content).'</p></div>';
	else	
		$code = '<div class="twohalf"><p>'.do_shortcode($content).'</p></div>';
	return $code;
}
add_shortcode('half_width', 'cwp_half_width');

/* Third width text */
function cwp_third_width( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'title' => 'title'
	), $atts ) );
	
	if(isset($title) && $title != '')
		$code = '<div class="threequarter"><div class="headingone">'.$title.'</div><p>'.do_shortcode($content).'</p></div>';
	else	
		$code = '<div class="threequarter"><p>'.do_shortcode($content).'</p></div>';
	return $code;
}
add_shortcode('third_width', 'cwp_third_width');

/* Fourth width text */
function cwp_fourth_width( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'title' => 'title'
	), $atts ) );
	
	if(isset($title) && $title != '')
		$code = '<div class="fourquarter"><div class="headingone">'.$title.'</div><p>'.do_shortcode($content).'</p></div>';
	else	
		$code = '<div class="fourquarter"><p>'.do_shortcode($content).'</p></div>';
	return $code;
}
add_shortcode('fourth_width', 'cwp_fourth_width');

/* 3 Fourths width text */
function cwp_three_fourths_width( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'title' => 'title'
	), $atts ) );
	
	if(isset($title) && $title != '')
		$code = '<div class="threefourth"><div class="headingone">'.$title.'</div><p>'.do_shortcode($content).'</p></div>';
	else	
		$code = '<div class="threefourth"><p>'.do_shortcode($content).'</p></div>';
	return $code;
}
add_shortcode('three_fourths_width', 'cwp_three_fourths_width');

/* buy now buttons */
function cwp_buynow_button( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'style' => '1',
		'link' => 'url',
		'color' => 'red',
		'caption' => 'Buy now!'
 
	), $atts ) );
 
	switch ($style) {
		case 1:
			$button_style = '';
			break;
		case 2:
	 		$button_style = 'styletwo';
			break;
		case 3:
	 		$button_style = 'stylethree';
			break;					
		case 4:
	 		$button_style = 'stylefour';
			break;					
	}
	
	switch ($color) {
		case 'red':
			$button_color = 'buyred';
			break;
		case 'orange':
	 		$button_color = 'buyorange';
			break;
		case 'blue':
	 		$button_color = 'buyblue';
			break;					
		case 'cyan':
	 		$button_color = 'buycyan';
			break;
		case 'green':
	 		$button_color = 'buygreen';
			break;	
		case 'pink':
	 		$button_color = 'buypink';
			break;	
		case 'light-gray':
	 		$button_color = 'buylight-gray';
			break;
		case 'gray':
	 		$button_color = 'buygray';
			break;		
	}
 
	$code = '<div class="buynowb ' . $button_style . ' '.$button_color.' fleft marginright"><a href="' . $link . '">' . $caption . '</a><span class="price"></span></div>'; 
		
	return $code;
}
add_shortcode('buy_now_button', 'cwp_buynow_button');

/* social icons */
function cwp_social_icons( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'profile' => 'profile',
		'link' => 'url',
		'social_network' => 'Facebook'
 
	), $atts ) );
	
	$sn = $social_network;
	
	switch ($social_network) {
		case 'Facebook':
			$social_network = 'facebook';
			break;
		case 'Twitter':
	 		$social_network = 'twitter';
			break;
		case 'Pinterest':
	 		$social_network = 'pinterest';
			break;					
		case 'Youtube':
	 		$social_network = 'youtube';
			break;
		case 'Linkedin':
	 		$social_network = 'linkedin';
			break;	
		case 'Flickr':
	 		$social_network = 'flickr';
			break;	
		case 'Googleplus':
	 		$social_network = 'googleplus';
			break;
		case 'Rss':
	 		$social_network = 'rss';
			break;		
	}
 
	$code = '<div class="fleft marginright socialmb '.$social_network.'">
				<div class="icon"></div>
				<a href="'.$link.'" target="_blank">
					'.$sn.'
					<br><span>'.$profile.'</span>
				</a>
			</div>'; 
		
	return $code;
}
add_shortcode('social_icons', 'cwp_social_icons');


/*
*	Alerts
*/

function cwp_alerts( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'style' => '1',
		'text' => 'text'
	), $atts ) );
 
	switch ($style) {
	 case 1:
			$alert_style = 'alert';
			break;
	 case 2:
	 		$alert_style = 'warning';
			break;
	 case 3:
	 		$alert_style = 'information';
			break;					
	}
	
	$code =  '<div class="co-alertbox '.$alert_style.'">'.$text.'</div>';
 	
	return $code;
}
add_shortcode('alert', 'cwp_alerts');

/*
*	Blockquotes
*/

function cwp_blockquote( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'style' => '1',
		'text' => 'text'
	), $atts ) );
 
	switch ($style) {
	 case 1:
			$blockquote_style = 'simple';
			break;
	 case 2:
	 		$blockquote_style = 'simpletwo';
			break;				
	}
	
	$code =  '<blockquote class="'.$blockquote_style.'">'.$text.'</blockquote>';
 	
	return $code;
}
add_shortcode('blockquote', 'cwp_blockquote');

/*
*	Circle blockquotes
*/

function cwp_circle_blockquote( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'title' => 'title',
		'style' => '1',
		'circle_text' => 'text in circle',
		'text' => 'text'
	), $atts ) );
 
	switch ($style) {
		case 1:
			$blockquote_style = 'round';
			break;
		case 2:
	 		$blockquote_style = 'roundcomma';
			break;				
	}
	
	$code = "";
	
	if(isset($title) && $title != '')
		$code .= '<div class="headingone">'.$title.'</div>';
	
	$code .=  '<blockquote class="'.$blockquote_style.'">'.$circle_text.'</blockquote>';
	
	$code .= $text;
 	
	return $code;
}
add_shortcode('circle_blockquote', 'cwp_circle_blockquote');

/*
*	Line
*/

function cwp_line( $atts, $content = null ) {
 	
	$code =  '<div class="pagebreakeone"></div>';
 	
	return $code;
}
add_shortcode('line', 'cwp_line');

/*
*	Normal headings
*/

function cwp_normal_headings( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'type' => '1',
		'text' => 'text'
	), $atts ) );
 
	switch ($type) {
		case 1:
			$code = '<h1>'.$text.'</h1>';
			break;
		case 2:
	 		$code = '<h2>'.$text.'</h2>';
			break;	
		case 3:
	 		$code = '<h3>'.$text.'</h3>';
			break;		
		case 4:
	 		$code = '<h4>'.$text.'</h4>';
			break;	
		case 5:
	 		$code = '<h5>'.$text.'</h5>';
			break;	
		case 6:
	 		$code = '<h6>'.$text.'</h6>';
			break;	
	}
	
	return $code;
}
add_shortcode('normal_headings', 'cwp_normal_headings');

/*
*	Headings with style
*/

function cwp_style_headings( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'type' => '1',
		'text' => 'text',
		'icon' => 'cloud'
	), $atts ) );
 
	switch ($type) {
		case 1:
			$type = 'headingone';
			break;	
		case 2:
			$type = 'headingtwo';
			break;
		case 3:
	 		$type = 'headingthree';
			break;	
		case 4:
	 		$type = 'headingfour';
			break;		
	}
	
	if(isset($icon) && $icon != '')
		$code = '<div class="'.$type.'"><span class="blue fleft sicon '.$icon.'"></span>'.$text.'</div>';
	else
		$code = '<div class="'.$type.'">'.$text.'</div>';
	
	return $code;
}
add_shortcode('style_headings', 'cwp_style_headings');

/* Image with bottom text */
function cwp_image_bottom_text( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'width' => 'full-with',
		'image' => 'image',
		'title' => 'title',
		'text' => 'text'
	), $atts ) );
 
	switch ($width) {
		case 'full-width':
			$width = 'fullwidhtext';
			break;	
		case 'half-width':
			$width = 'twohalf_imagelist';
			break;
		case 'third-width':
	 		$width = 'threequarter_imagelist';
			break;	
		case 'fourth-width':
	 		$width = 'fourquarter_imagelist';
			break;		
	}
	
	$code = '<div class="imglistv '.$width.'">';
	if(isset($image) && $image != '')
	$code .= '<img src="'.$image.'" alt="">';
	if(isset($title) && $title != '')
		$code .= '<h3>'.$title.'</h3>';
	if(isset($text) && $text != '')
		$code .= '<p>'.$text.'</p>';
	$code .= '</div>';
	
	return $code;
}
add_shortcode('image_bottom_text', 'cwp_image_bottom_text');


/* Image with right text */
function cwp_image_right_text( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'image' => 'image',
		'title' => 'title',
		'text' => 'text'
	), $atts ) );


	$code = '<div class="imglisth">';
	if(isset($image) && $image != '')
	$code .= '<div class="img" style="background-image: url('.$image.');"></div>';
	$code .= '<article>';
	if(isset($title) && $title != '')
		$code .= '<h3>'.$title.'</h3>';
	if(isset($text) && $text != '')
		$code .= $text;
	$code .= '</article>';	
	$code .= '</div>';
	
	return $code;
}
add_shortcode('image_right_text', 'cwp_image_right_text');

/* Go to top op page */
function cwp_go_to_top( $atts, $content = null ) {

	$code = '<div class="pagebreaketwo"><a href="#top"></a></div>';
	
	return $code;
}
add_shortcode('go_to_top', 'cwp_go_to_top');
 
 
/* image frames */
function cwp_image_frames( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'type' => 1,
		'image' => 'image',
		'caption' => 'caption'
	), $atts ) );
	
	switch ($type) {
		case 1:
			$type = 'imgframeone';
			break;	
		case 2:
			$type = 'imgframetwo';
			break;	
	}
	
	$code = '<div class="'.$type.' fullWidth">';
	if($type == 'imgframeone') {
		if(isset($image) && $image != '')
			$code .= '<div class="img"><img src="'.$image.'" alt=""></div>';
		if(isset($caption) && $caption != '')	
			$code .= '<p>'.$caption.'</p>';
	}		
	else {
		if(isset($image) && $image != '')
			$code .= '<img src="'.$image.'" alt="">';
		if(isset($caption) && $caption != '')
			$code .= '<div class="hover">'.$caption.'</div>';
	}
	
	$code .= '</div>';
	
	return $code;
}
add_shortcode('image_frames', 'cwp_image_frames');

/* image frames plus text */
function cwp_image_frames_text( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'type' => 1,
		'image' => 'image',
		'caption' => 'caption',
		'text' => 'text'
	), $atts ) );
	
	$code = "";
	
	if($type == 1){
		$code .= '<div class="imgframetwo imgframetwo-leftalign">';
		
		if(isset($image) && $image != '')
			$code .= '<img src="'.$image.'" alt="">';
		if(isset($caption) && $caption != '')
			$code .= '<div class="hover">'.$caption.'</div>';

		$code .= '</div>';
		
		if(isset($text) && $text != '')	
			$code .= $text;
	}		
	else {
		$code .= '<div class="imageframethree">';

		if(isset($image) && $image != '')
			$code .= '<div class="img" style="background-image: url('.$image.');"></div>';
			$code .= '<div class="details">';

			if(isset($caption) && $caption != '')
				$code .= $caption;	
			
			$code .= '</div>';

		$code .= '</div>';

		if(isset($text) && $text != '')	
			$code .= $text;
	}
	
	$code .= '<div class="clearfix"></div>';
	
	return $code;
}
add_shortcode('image_frames_text', 'cwp_image_frames_text');

/* lists */

function cwp_lists ( $atts, $content = null ) {

	$code = '<li>'.$content.'</li>';
	
	return $code;
}
add_shortcode('list', 'cwp_lists');

function cwp_typography_list( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'title' => 'title',
		'type' => 1
	), $atts ) );
	
	switch ($type) {
		case 1:
			$type_class = '';
			break;	
		case 2:
			$type_class = 'lstyle lstyleone';
			break;	
		case 3:
			$type_class = 'lstyle lstyletwo';
			break;
		case 4:
			$type_class = 'lstyle lstylethree';
			break;
	}
	
	$code = "";
	
	if(isset($title) && $title != '')
		$code .= '<div class="headingone">'.$title.'</div>';
		
	$code .= '<ul class="'.$type_class.'">';

	$code .= do_shortcode($content);

	$code .= '</ul>';
	
	return $code;
}
add_shortcode('typography_list', 'cwp_typography_list');

/* ordered lists */
function cwp_typography_ordered_list( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'title' => 'title',
		'type' => 1
	), $atts ) );
	
	switch ($type) {
		case 1:
			$type_class = 'decimal';
			break;	
		case 2:
			$type_class = 'decimal-zero';
			break;	
		case 3:
			$type_class = 'latin';
			break;
		case 4:
			$type_class = 'roman';
			break;
		case 5:
			$type_class = 'armenian';
			break;	
		case 6:
			$type_class = 'georgian';
			break;		
		case 7:
			$type_class = 'hebrew';
			break;		
		case 8:
			$type_class = 'hiragana';
			break;		
		case 9:
			$type_class = 'hiragana-iroha';
			break;		
		case 10:
			$type_class = 'katakana';
			break;		
		case 11:
			$type_class = 'katakana-iroha';
			break;		
		case 12:
			$type_class = 'lower-greek';
			break;		
	}
	
	$code = "";
	
	if(isset($title) && $title != '')
		$code .= '<div class="headingone">'.$title.'</div>';
		
	$code .= '<ol class="'.$type_class.'">';

	$code .= do_shortcode($content);

	$code .= '</ol>';
	
	return $code;
}
add_shortcode('typography_ordered_list', 'cwp_typography_ordered_list');
 
 
/*
* ADD SHORTCODES TO THE WP EDITOR	
*/
 
 
add_action('media_buttons','cwp_add_sc_select',11);
function cwp_add_sc_select(){
    echo '&nbsp;<select id="sc_select">';
            
            echo "<option value=''>".__("List of shortcodes","premium-code-pro")."</option>";
    
			echo "<option value='[buy_now_button style=\"1 , 2 , 3 or 4\" caption=\"Buy now!\" link=\"button_url\" color=\"red, orange, blue, cyan, green, pink, light-gray or gray\"]'>".__("Buy now buttons","premium-code-pro")."</option>";
			
			echo "<option value='[social_icons profile=\"profile\" link=\"url\" social_network=\"Facebook, Twitter, Pinterest, Youtube, Linkedin, Flickr, Googleplus or Rss\"]'>".__("Social icons","premium-code-pro")."</option>";
			
			echo "<option value='[alert text=\"text\" style=\"1, 2 or 3\"]'>".__("Alerts","premium-code-pro")."</option>";
			
			echo "<option value='[blockquote style=\"1 or 2\" text=\"text\"]'>".__("Blockquote","premium-code-pro")."</option>";
			
			echo "<option value='[circle_blockquote title=\"title\" style=\"1 or 2\" circle_text=\"Text in the circle\" text=\"text\"]'>".__("Circle blockquotes","premium-code-pro")."</option>";
			
			
			echo "<option value='[simple_button label=\"label\" link=\"url\" color=\"red, orange, blue, cyan, green, pink, light-gray or gray\"]'>".__("Simple buttons","premium-code-pro")."</option>";
			
			echo "<option value='[icons_button type=\"anchor, book, cloud, rightarrow, monitor, signal, wifi or settings\" color=\"red, orange, blue, cyan, green, pink, light-gray or gray\" caption=\"caption\"]'>".__("Icons buttons","premium-code-pro")."</option>";
			
			echo "<option value='[call_to_action_button style=\"1, 2 or 3\" color=\"red, orange, blue, cyan, green, pink, light-gray or gray\" caption=\"caption\" link=\"url\"]'>".__("Call to action buttons","premium-code-pro")."</option>";
			
			echo "<option value='[icons type=\"anchor, bag, book, bookmark, camera, cart, chat, clock, date, cloud, cup, document, emptystart, star, glass, heart, home, leftarrow, rightarrow, location, look, mail, monitor, music, ok, ok2, pacman, pencil, picture, refresh, security, settings, settings2, signal, statistics, statistics2, volume or wifi \" color=\"red, orange, blue, cyan, green, pink, light-gray or gray\" hover_effect=\"1, 2, 3 or 4\"]'>".__("Icons","premium-code-pro")."</option>";
			
			echo "<option value='[round_icons type=\"anchor, bag, book, bookmark, camera, cart, chat, clock, date, cloud, cup, document, emptystart, star, glass, heart, home, leftarrow, rightarrow, location, look, mail, monitor, music, ok, ok2, pacman, pencil, picture, refresh, security, settings, settings2, signal, statistics, statistics2, volume or wifi \" color=\"red, orange, blue, cyan, green, pink, light-gray or gray\" hover_effect=\"1, 2, 3 or 4\"]'>".__("Round icons","premium-code-pro")."</option>";
			
			echo "<option value='[dropcap style=\"1, 2, 3 or 4\" text=\"text\" first_letter=\"first_letter\"]'>".__("Dropcap","premium-code-pro")."</option>";
			
			echo "<option value='[full_width title=\"title\"]content goes here[/full_width]'>".__("Full width section","premium-code-pro")."</option>";
			
			echo "<option value='[half_width title=\"title\"]content goes here[/half_width]'>".__("Half width section","premium-code-pro")."</option>";
			
			echo "<option value='[third_width title=\"title\"]content goes here[/third_width]'>".__("Third width section","premium-code-pro")."</option>";
			
			echo "<option value='[fourth_width title=\"title\"]content goes here[/fourth_width]'>".__("Fourth width section","premium-code-pro")."</option>";
			
			echo "<option value='[three_fourths_width title=\"title\"][/three_fourths_width]'>".__("3 Fourths width section","premium-code-pro")."</option>";
			
			echo "<option value='[line]'>".__("Line","premium-code-pro")."</option>";
			
			echo "<option value='[normal_headings type=\"1, 2, 3, 4, 5 or 6\" text=\"text\"]'>".__("Simple headings","premium-code-pro")."</option>";
			
			echo "<option value='[style_headings type=\"1, 2, 3 or 4\" icon=\"anchor, bag, book, bookmark, camera, cart, chat, clock, date, cloud, cup, document, emptystart, star, glass, heart, home, leftarrow, rightarrow, location, look, mail, monitor, music, ok, ok2, pacman, pencil, picture, refresh, security, settings, settings2, signal, statistics, statistics2, volume or wifi\" text=\"text\"]'>".__("Styled headings","premium-code-pro")."</option>";
			
			echo "<option value='[image_bottom_text width=\"full-with, half-width, third-width or fourth-width\" image=\"path to image\" title=\"title\" text=\"text\"]'>".__("Image with text at bottom",'premium-code-pro')."</option>";
			echo "<option value='[image_right_text image=\"path to image\" title=\"title\" text=\"text\"]'>".__("Image with text in the right","premium-code-pro")."</option>";
			
			echo "<option value='[go_to_top]'>".__("Go to top of the page","premium-code-pro")."</option>";
			
			echo "<option value='[image_frames type=\"1 or 2\" image=\"path to image\" caption=\"caption\"]'>".__("Image frames","premium-code-pro")."</option>";
			
			echo "<option value='[image_frames_text type=\"1 or 2\" image=\"path to image\" caption=\"caption\" text=\"text\"]'>".__("Image frames plus text","premium-code-pro")."</option>";
			
			echo "<option value='[typography_list title=\"title\" type=\"1, 2, 3 or 4\"][list]List 1[/list][list]List 2[/list][/typography_list]'>".__("Lists","premium-code-pro")."</option>";
			
            echo "<option value='[typography_ordered_list title=\"title\" type=\"1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11 or 12\"][list]List 1[/list][list]List 2[/list][/typography_ordered_list]'>".__("Ordered Lists","premium-code-pro")."</option>";  
			
			
			echo "<option value='[tabs][tab title=\"tab1\" content=\"content1\"][/tab][tab title=\"tab2\" content=\"content2\"][/tab][/tabs]'>".__("Tabs","premium-code-pro")."</option>";
    echo '</select>';
}
 
?>