<?php get_header(); ?>
<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
	<div class="generalheadline">
		<h3><?php the_title(); ?></h3>
	</div><!--/generalheadline-->
	<div id="wrap">

				<?php
				
				/* featured image */
				$featured_image_products = cwp('featured_image_products');
				if(isset($featured_image_products) && $featured_image_products == "featured_image_products_yes"):
					if ( has_post_thumbnail() ): 
						echo '<div id="portfolio-slider">';
							the_post_thumbnail();
						echo '</div>';
					endif;
				endif;
				
				echo '<h3 class="headlinethree">';
					the_title();
				echo '</h3>';
				
				echo '<p class="fullwidhtext">';
					the_content();
				echo '</p>';	
				
				/* RELATED PRODUCTS */
				$idd = get_the_ID();
				
				$related_products = cwp('related_products');
				if(isset($related_products) && $related_products == "related_products_yes"):
					echo '<div class="headlinetwo">';
						echo '<h2>'.__('Related Projects','premium-code-pro').'</h2>';
						$related_products_text = cwp('related_products_text');
						if(isset($related_products_text) && $related_products_text != '')
							echo '<p>'.$related_products_text.'</p>';
					echo '</div>';
					
					echo '<div class="ourworkitems portfoliorelated">';		
		
					$done = array();
				
					$taguri = get_the_tags();	
					$count = 0;
					if ($taguri):			
						$tag_ids = array();			
						foreach($taguri as $individual_tag) :				
							$tag_ids[] = $individual_tag->term_id;			
						endforeach;	
						
						$args=array(				
							'tag__in' => $tag_ids,							
							'posts_per_page'=> 6,
							'post_type' => 'product',
							'post__not_in' => array($idd)
						);			
						$query = new WP_Query( $args );
						if ( $query->have_posts() ):
						
							
							while ( $query->have_posts() ):
							
								$count++;
								$query->the_post();
								$done[] = get_the_ID();
								$id = get_the_ID();
								$items = get_the_terms($id, 'categories');
								if(!empty($items)) {
									foreach ( $items as $item ) {
										$cat = $item->name;
										$slug = $item->slug;
										$cat_id = $item->term_id;
									}
								}
								?>
								<a href="<?php the_permalink(); ?>" class="item">

									<span class="hover"></span>
									<?php
										if ( has_post_thumbnail() ): 
											the_post_thumbnail();
										else:
											echo '<img src="'.get_template_directory_uri().'/images/default-product.png">';	
										endif;
									?>

								</a>
								<?php
							endwhile;
							?>
							
							<?php
						endif;
					endif;		
					wp_reset_query(); 
					if($count < 6):
						array_push($done,$idd);
						$needed = 6 - $count;
						$items = get_the_terms(get_the_ID(), 'categories');
						if(!empty($items)) {
							$cats = array();
							foreach ( $items as $item ) {
								$cats[] = $item->term_id;
							}
						
						$args = array( 'post__not_in' => $done , 'post_type' => 'product', 'posts_per_page' => $needed,'tax_query' => array(
									array(
										'taxonomy' => 'categories',
										'field' => 'id',
										'terms' => $cats
									)
								));
						$query = new WP_Query( $args );
						if ( $query->have_posts() ):		
							while ( $query->have_posts() ):
								$query->the_post();
								$id = get_the_ID();
								$items = get_the_terms($id, 'categories');
								if(!empty($items)) {
									foreach ( $items as $item ) {
										$cat = $item->name;
										$slug = $item->slug;
										$cat_id = $item->term_id;
									}
								}
								?>
								<a href="<?php the_permalink(); ?>" class="item">

									<span class="hover"></span>

									<?php
										if ( has_post_thumbnail() ): 
											the_post_thumbnail();
										else:
											echo '<img src="'.get_template_directory_uri().'/images/default-product.png">';
										endif;
									?>
								</a>
								<?php
							endwhile;
						endif;
						wp_reset_query(); 
						}
					endif;
					echo '</div>';
				endif;
			?>

		</div><!--/wrap-->
<?php endwhile; endif; ?>		
<?php get_footer(); ?>