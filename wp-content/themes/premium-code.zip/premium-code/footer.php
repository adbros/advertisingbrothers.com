<?php

/**

 * The template for displaying the footer.

 *

 * @package premium-code

 */

?>



		<footer>

			<div class="fcenter footer-top">

				<?php

					$logo_footer = cwp('logo_footer');

					if(isset($logo_footer) && $logo_footer != ''):

						echo '<div class="flogo">';

						echo '<img src="'.$logo_footer.'" alt="'.get_bloginfo('name').'">';

						echo '</div>';

					endif;

				dynamic_sidebar('footer_area'); 



				echo '<div class="clearfix"></div>';

			echo '</div>';

			echo '<div class="footer-bottom">';

			echo '<div class="fcenter">';	

				echo '<div class="socialmedia">';

				

					$facebook_link = cwp('facebook_link');

					$twitter_link = cwp('twitter_link');

					$pinterest_link = cwp('pinterest_link');

					$youtube_link = cwp('youtube_link');

					$linkedin_link = cwp('linkedin_link');

					$flickr_link = cwp('flickr_link');

					$googleplus_link = cwp('googleplus_link');

					$rss_link = cwp('rss_link');

					

					if( (isset($facebook_link) && $facebook_link != '') || (isset($twitter_link) && $twitter_link != '') || (isset($pinterest_link) && $pinterest_link != '') || (isset($youtube_link) && $youtube_link != '') || (isset($linkedin_link) && $linkedin_link != '') || (isset($flickr_link) && $flickr_link != '') || (isset($googleplus_link) && $googleplus_link != '') || (isset($rss_link) && $rss_link != '')):

					

					echo '<div class="rwdfsocial">';

					if(isset($facebook_link) && $facebook_link != ''):

						echo '<div class="item"><a href="'.$facebook_link.'"><img src="'.get_template_directory_uri().'/images/social/facebookh.png" alt=""></a></div>';

					endif;

					if(isset($twitter_link) && $twitter_link != ''):

						echo '<div class="item"><a href="'.$twitter_link.'"><img src="'.get_template_directory_uri().'/images/social/twitterh.png" alt=""></a></div>';

					endif;

					if(isset($pinterest_link) && $pinterest_link != ''):

						echo '<div class="item"><a href="'.$pinterest_link.'"><img src="'.get_template_directory_uri().'/images/social/pinteresth.png" alt=""></a></div>';

					endif;

					if(isset($youtube_link) && $youtube_link != ''):

						echo '<div class="item"><a href="'.$youtube_link.'"><img src="'.get_template_directory_uri().'/images/social/youtubeh.png" alt=""></a></div>';

					endif;

					if(isset($linkedin_link) && $linkedin_link != ''):

						echo '<div class="item"><a href="'.$linkedin_link.'"><img src="'.get_template_directory_uri().'/images/social/linkedinh.png" alt=""></a></div>';

					endif;

					if(isset($flickr_link) && $flickr_link != ''):

						echo '<div class="item"><a href="'.$flickr_link.'"><img src="'.get_template_directory_uri().'/images/social/flickrh.png" alt=""></a></div>';

					endif;

					if(isset($googleplus_link) && $googleplus_link != ''):

						echo '<div class="item"><a href="'.$googleplus_link.'"><img src="'.get_template_directory_uri().'/images/social/googleplush.png" alt=""></a></div>';

					endif;

					if(isset($rss_link) && $rss_link != ''):

						echo '<div class="item"><a href="'.$rss_link.'"><img src="'.get_template_directory_uri().'/images/social/rssh.png" alt=""></a></div>';;

					endif;

					echo '</div>';

					endif;

					

					echo '<div class="clearfix"></div>';

					$copyright = cwp('copyright');

					if(isset($copyright) && $copyright != '')

						echo '<div class="copyright">'.$copyright.'</div>';

					echo '<div class="clearfix"></div>
					<div class="copyright">
					<a href="http://themeisle.com/themes/premium-code-pro/?utm_source=premium-code-pro&amp;utm_medium=link&amp;utm_campaign=themefooter" target="_blank">Premium Code Pro</a> powered by <a href="http://wordpress.org/" target="_blank">WordPress</a>
					</div>';

					echo '</div>';

				?>



			</div><!--/fcenter-->

			</div>

		</footer>



<?php wp_footer(); ?>



</body>

</html>