<?php 	
	/*		
	Template Name: Portofolio 3-1 cols	
	*/
?>
<?php get_header(); ?>
<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
<div class="generalheadline">			
	<h3><?php the_title(); ?></h3>		
</div><!--/generalheadline-->		
<div id="wrap">			
			<?php
				$cpi_portofolio_title_option = get_post_meta($id, 'cpi_portofolio_title_option');
				$text_portofolio = cwp('text_portofolio');
				$button_portofolio = cwp('button_portofolio');
				$button_portofolio_link = cwp('button_portofolio_link');
				
				
				if((isset($cpi_portofolio_title_option[0]) && $cpi_portofolio_title_option[0] != '') || (isset($button_portofolio) && $button_portofolio == 'button_portofolio_show') || (isset($button_portofolio) && $button_portofolio == 'button_portofolio_show')):
				
					echo '<div class="portfoliohead">';		
						
						if(isset($cpi_portofolio_title_option[0]) && $cpi_portofolio_title_option[0] != '')
							echo '<h4>'.$cpi_portofolio_title_option[0].'</h4>';
						
						if(isset($text_portofolio) && $text_portofolio == 'text_portofolio_show')
							the_content();
						
						if(isset($button_portofolio) && $button_portofolio == 'button_portofolio_show'):
							if(isset($button_portofolio_link) && $button_portofolio_link != ''):
								echo '<div class="ordernow"><a href="'.$button_portofolio_link.'" target="_blank">'.__('Order Now','premium-code-pro').'</a></div>';
							endif;
						endif;	
					echo '</div>';	
				endif;	
			?>		
	<div id="portfolio-three">				
				<?php
					global $paged, $wp_query, $wp;
					if  ( empty($paged) ) {
							if ( !empty( $_GET['paged'] ) ) {
									$paged = $_GET['paged'];
							} elseif ( !empty($wp->matched_query) && $args = wp_parse_args($wp->matched_query) ) {
									if ( !empty( $args['paged'] ) ) {
											$paged = $args['paged'];
									}
							}
							if ( !empty($paged) )
									$wp_query->set('paged', $paged);
					}      
					$temp = $wp_query;
					$wp_query= null;
					$wp_query = new WP_Query();
					$wp_query->query('paged='.$paged.'&post_type=product&showposts=16');

					while ($wp_query->have_posts()) : $wp_query->the_post();
						?>
							<div class="item">								
								<div class="img">									
									<?php										
									if ( has_post_thumbnail($post->ID) ) {											
										echo get_the_post_thumbnail($post->ID, 'portofolio-style3-thumb'); 										
									}		
									else
										echo '<img src="'.get_template_directory_uri().'/images/portofolio3.png'.'">';
									?>								
								</div>								
								<div class="pthreecontent">									
									<h3><?php the_title(); ?></h3>									
									<?php the_content(); ?>									
									<div class="readmore"><a href="<?php the_permalink(); ?>"><?php _e('read more','premium-code-pro'); ?></a></div>								
								</div>							
							</div>	
						<?php
					endwhile;	
				?>		
	</div><!--/portfolio-three-->			
	<div id="generalnavi">
		<?php previous_posts_link('<span class="prev">'.__('Prev','premium-code-pro').'</span>') ?>
        <?php next_posts_link('<span class="next">'.__('Next','premium-code-pro').'</span>') ?>
		<?php $wp_query = null; $wp_query = $temp;?>
	</div><!--/generalnavi-->		
</div><!--/wrap-->				
<div id="clients">			
	<div class="clientscenter">				
		<?php dynamic_sidebar('portofolio_area'); ?>
		<div class="clearfix"></div>	
	</div><!--/clientscenter-->		
</div><!--/clients-->
<?php endwhile; endif; ?>	
<?php get_footer(); ?>