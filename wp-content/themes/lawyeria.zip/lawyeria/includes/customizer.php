<?php

function lawyeria_customizer( $wp_customize ) {
	
	function lawyeria_check_not_fronpage() {
		
		if( is_front_page() ):
			return false;
		else:
			return true;
		endif;
		
	}
	
	
	
    $wp_customize->get_setting( 'blogname' )->transport = 'postMessage';
    $wp_customize->get_setting( 'blogdescription' )->transport = 'postMessage';
    $wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';
    $wp_customize->get_setting( 'background_color' )->transport = 'postMessage';
	
	$wp_version_nr = get_bloginfo('version');
	
	/****************************************/
	/*************  COLORS ******************/
	/****************************************/
	
	if( $wp_version_nr >= 4.0 ):
	
		$wp_customize->add_panel( 'panel_colors', array(
			'priority' => 29,
			'capability' => 'edit_theme_options',
			'theme_supports' => '',
			'title' => __( 'Colors', 'ti' )
		) );
		
		
		/******************************************/
		/************** Menu colors **************/
		/*****************************************/
		
		
		$wp_customize->add_section( 'lawyeria_menu_colors_section' , array(
					'title'       => __( 'Menu', 'ti' ),
					'priority'    => 29,
					'panel' => 'panel_colors'
		));
		
		/************** Menu background color **************/
		
		$wp_customize->add_setting(
			'lawyeria_menu_background',
			array(
				'default'     => '#f3f3f3'
			)
		);
		$wp_customize->add_control(
				new WP_Customize_Color_Control(
					$wp_customize,
					'lawyeria_menu_background',
					array(
						'label'      => __( 'Background color', 'ti' ),
						'section'    => 'lawyeria_menu_colors_section',
						'settings'   => 'lawyeria_menu_background',
						'priority'   => 1
					)
				)
		);
		
		/************** Menu text color **************/
		
		$wp_customize->add_setting(
			'lawyeria_menu_text_color',
			array(
				'default'     => '#394753'
			)
		);
		$wp_customize->add_control(
				new WP_Customize_Color_Control(
					$wp_customize,
					'lawyeria_menu_text_color',
					array(
						'label'      => __( 'Text color', 'ti' ),
						'section'    => 'lawyeria_menu_colors_section',
						'settings'   => 'lawyeria_menu_text_color',
						'priority'   => 2
					)
				)
		);
		
		/************** Menu border color **************/
		
		$wp_customize->add_setting(
			'lawyeria_menu_border_color',
			array(
				'default'     => '#dee0e2'
			)
		);
		$wp_customize->add_control(
				new WP_Customize_Color_Control(
					$wp_customize,
					'lawyeria_menu_border_color',
					array(
						'label'      => __( 'Hover border color', 'ti' ),
						'section'    => 'lawyeria_menu_colors_section',
						'settings'   => 'lawyeria_menu_border_color',
						'priority'   => 3
					)
				)
		);
		/*******************************************/
		/************** Header colors **************/
		/*******************************************/
		
		
		$wp_customize->add_section( 'lawyeria_header_colors_section' , array(
					'title'       => __( 'Header', 'ti' ),
					'priority'    => 30,
					'panel' => 'panel_colors'
					
		));
		
		/************** Background color(if not front page) **************/
		
		$wp_customize->add_setting(
			'lawyeria_header_background',
			array(
				'default'     => '#445d70'
			)
		);
		$wp_customize->add_control(
				new WP_Customize_Color_Control(
					$wp_customize,
					'lawyeria_header_background',
					array(
						'label'      => __( 'Background color', 'ti' ),
						'section'    => 'lawyeria_header_colors_section',
						'settings'   => 'lawyeria_header_background',
						'priority'   => 1,
						'active_callback' => 'lawyeria_check_not_fronpage'
					)
				)
		);
		
		/************** Headings color **************/
		
		$wp_customize->add_setting(
			'lawyeria_header_headings_color',
			array(
				'default'     => '#fff'
			)
		);
		$wp_customize->add_control(
				new WP_Customize_Color_Control(
					$wp_customize,
					'lawyeria_header_headings_color',
					array(
						'label'      => __( 'Headings color', 'ti' ),
						'section'    => 'lawyeria_header_colors_section',
						'settings'   => 'lawyeria_header_headings_color',
						'priority'   => 2
					)
				)
		);
		
		/************** Text color(if front page) **************/
		
		$wp_customize->add_setting(
			'lawyeria_header_text_color',
			array(
				'default'     => '#a8adb1'
			)
		);
		$wp_customize->add_control(
				new WP_Customize_Color_Control(
					$wp_customize,
					'lawyeria_header_text_color',
					array(
						'label'      => __( 'Text color', 'ti' ),
						'section'    => 'lawyeria_header_colors_section',
						'settings'   => 'lawyeria_header_text_color',
						'priority'   => 3,
						'active_callback' => 'is_front_page'
					)
				)
		);
		
		/*******************************************/
		/************** Footer colors **************/
		/*******************************************/
		
		
		$wp_customize->add_section( 'lawyeria_footer_colors_section' , array(
					'title'       => __( 'Footer', 'ti' ),
					'priority'    => 31,
					'panel' => 'panel_colors'
		));
		
		/************** Footer background color **************/
		
		$wp_customize->add_setting(
			'lawyeria_footer_background',
			array(
				'default'     => '#4a5c6b'
			)
		);
		$wp_customize->add_control(
				new WP_Customize_Color_Control(
					$wp_customize,
					'lawyeria_footer_background',
					array(
						'label'      => __( 'Background color', 'ti' ),
						'section'    => 'lawyeria_footer_colors_section',
						'settings'   => 'lawyeria_footer_background',
						'priority'   => 1
					)
				)
		);
		
		/************** Footer headings color **************/
		
		$wp_customize->add_setting(
			'lawyeria_footer_heading_color',
			array(
				'default'     => '#fff'
			)
		);
		$wp_customize->add_control(
				new WP_Customize_Color_Control(
					$wp_customize,
					'lawyeria_footer_heading_color',
					array(
						'label'      => __( 'Headings color', 'ti' ),
						'section'    => 'lawyeria_footer_colors_section',
						'settings'   => 'lawyeria_footer_heading_color',
						'priority'   => 2
					)
				)
		);
		
		/************** Footer text color **************/
		
		$wp_customize->add_setting(
			'lawyeria_footer_text_color',
			array(
				'default'     => '#BFC8D1'
			)
		);
		$wp_customize->add_control(
				new WP_Customize_Color_Control(
					$wp_customize,
					'lawyeria_footer_text_color',
					array(
						'label'      => __( 'Text color', 'ti' ),
						'section'    => 'lawyeria_footer_colors_section',
						'settings'   => 'lawyeria_footer_text_color',
						'priority'   => 3
					)
				)
		);
		
		/****************************************************/
		/************** Frontpage boxes colors **************/
		/****************************************************/
		
		
		$wp_customize->add_section( 'lawyeria_fp_boxes_colors_section' , array(
					'title'       => __( 'Frontpage boxes', 'ti' ),
					'priority'    => 32,
					'panel' => 'panel_colors'
		));
		
		/************** Background color **************/
		
		$wp_customize->add_setting(
			'lawyeria_fp_boxes_background',
			array(
				'default'     => '#fff'
			)
		);
		$wp_customize->add_control(
				new WP_Customize_Color_Control(
					$wp_customize,
					'lawyeria_fp_boxes_background',
					array(
						'label'      => __( 'Background color', 'ti' ),
						'section'    => 'lawyeria_fp_boxes_colors_section',
						'settings'   => 'lawyeria_fp_boxes_background',
						'priority'   => 1,
						'active_callback' => 'is_front_page'
					)
				)
		);
		
		/************** Headings color **************/
		
		$wp_customize->add_setting(
			'lawyeria_fp_boxes_headings_color',
			array(
				'default'     => '#394753'
			)
		);
		$wp_customize->add_control(
				new WP_Customize_Color_Control(
					$wp_customize,
					'lawyeria_fp_boxes_headings_color',
					array(
						'label'      => __( 'Headings color', 'ti' ),
						'section'    => 'lawyeria_fp_boxes_colors_section',
						'settings'   => 'lawyeria_fp_boxes_headings_color',
						'priority'   => 2,
						'active_callback' => 'is_front_page'
					)
				)
		);
		
		/************** Text color **************/
		
		$wp_customize->add_setting(
			'lawyeria_fp_boxes_text_color',
			array(
				'default'     => '#394753'
			)
		);
		$wp_customize->add_control(
				new WP_Customize_Color_Control(
					$wp_customize,
					'lawyeria_fp_boxes_text_color',
					array(
						'label'      => __( 'Text color', 'ti' ),
						'section'    => 'lawyeria_fp_boxes_colors_section',
						'settings'   => 'lawyeria_fp_boxes_text_color',
						'priority'   => 3,
						'active_callback' => 'is_front_page'
					)
				)
		);
		
	else:
	
		$wp_customize->add_section( 'lawyeria_colors_section' , array(

					'title'       => __( 'Colors', 'ti' ),

					'priority'    => 29

		));
		
		/************** Menu background color **************/
		
		$wp_customize->add_setting(
			'lawyeria_menu_background',
			array(
				'default'     => '#f3f3f3'
			)
		);
		$wp_customize->add_control(
				new WP_Customize_Color_Control(
					$wp_customize,
					'lawyeria_menu_background',
					array(
						'label'      => __( 'Menu background color', 'ti' ),
						'section'    => 'lawyeria_colors_section',
						'settings'   => 'lawyeria_menu_background',
						'priority'   => 1
					)
				)
		);
		
		/************** Menu text color **************/
		
		$wp_customize->add_setting(
			'lawyeria_menu_text_color',
			array(
				'default'     => '#394753'
			)
		);
		$wp_customize->add_control(
				new WP_Customize_Color_Control(
					$wp_customize,
					'lawyeria_menu_text_color',
					array(
						'label'      => __( 'Menu text color', 'ti' ),
						'section'    => 'lawyeria_colors_section',
						'settings'   => 'lawyeria_menu_text_color',
						'priority'   => 2
					)
				)
		);
		
		/************** Menu border color **************/
		
		$wp_customize->add_setting(
			'lawyeria_menu_border_color',
			array(
				'default'     => '#dee0e2'
			)
		);
		$wp_customize->add_control(
				new WP_Customize_Color_Control(
					$wp_customize,
					'lawyeria_menu_border_color',
					array(
						'label'      => __( 'Hover border color', 'ti' ),
						'section'    => 'lawyeria_colors_section',
						'settings'   => 'lawyeria_menu_border_color',
						'priority'   => 3
					)
				)
		);
		
		/************** Background color **************/
		
		$wp_customize->add_setting(
			'lawyeria_header_background',
			array(
				'default'     => '#445d70'
			)
		);
		$wp_customize->add_control(
				new WP_Customize_Color_Control(
					$wp_customize,
					'lawyeria_header_background',
					array(
						'label'      => __( 'Header - Background color', 'ti' ),
						'section'    => 'lawyeria_colors_section',
						'settings'   => 'lawyeria_header_background',
						'priority'   => 4
					)
				)
		);
		
		/************** Headings color **************/
		
		$wp_customize->add_setting(
			'lawyeria_header_headings_color',
			array(
				'default'     => '#fff'
			)
		);
		$wp_customize->add_control(
				new WP_Customize_Color_Control(
					$wp_customize,
					'lawyeria_header_headings_color',
					array(
						'label'      => __( 'Header - Headings color', 'ti' ),
						'section'    => 'lawyeria_colors_section',
						'settings'   => 'lawyeria_header_headings_color',
						'priority'   => 5
					)
				)
		);
		
		/************** Text color **************/
		
		$wp_customize->add_setting(
			'lawyeria_header_text_color',
			array(
				'default'     => '#a8adb1'
			)
		);
		$wp_customize->add_control(
				new WP_Customize_Color_Control(
					$wp_customize,
					'lawyeria_header_text_color',
					array(
						'label'      => __( 'Frontpage Header - Text color', 'ti' ),
						'section'    => 'lawyeria_colors_section',
						'settings'   => 'lawyeria_header_text_color',
						'priority'   => 6
					)
				)
		);
		
		/************** Footer background color **************/
		
		$wp_customize->add_setting(
			'lawyeria_footer_background',
			array(
				'default'     => '#4a5c6b'
			)
		);
		$wp_customize->add_control(
				new WP_Customize_Color_Control(
					$wp_customize,
					'lawyeria_footer_background',
					array(
						'label'      => __( 'Footer background color', 'ti' ),
						'section'    => 'lawyeria_colors_section',
						'settings'   => 'lawyeria_footer_background',
						'priority'   => 7
					)
				)
		);
		
		/************** Footer headings color **************/
		
		$wp_customize->add_setting(
			'lawyeria_footer_heading_color',
			array(
				'default'     => '#fff'
			)
		);
		$wp_customize->add_control(
				new WP_Customize_Color_Control(
					$wp_customize,
					'lawyeria_footer_heading_color',
					array(
						'label'      => __( 'Footer headings color', 'ti' ),
						'section'    => 'lawyeria_colors_section',
						'settings'   => 'lawyeria_footer_heading_color',
						'priority'   => 8
					)
				)
		);
		
		/************** Footer text color **************/
		
		$wp_customize->add_setting(
			'lawyeria_footer_text_color',
			array(
				'default'     => '#BFC8D1'
			)
		);
		$wp_customize->add_control(
				new WP_Customize_Color_Control(
					$wp_customize,
					'lawyeria_footer_text_color',
					array(
						'label'      => __( 'Footer text color', 'ti' ),
						'section'    => 'lawyeria_colors_section',
						'settings'   => 'lawyeria_footer_text_color',
						'priority'   => 9
					)
				)
		);
		
		/************** Frontpage box Background color **************/
		
		$wp_customize->add_setting(
			'lawyeria_fp_boxes_background',
			array(
				'default'     => '#fff'
			)
		);
		$wp_customize->add_control(
				new WP_Customize_Color_Control(
					$wp_customize,
					'lawyeria_fp_boxes_background',
					array(
						'label'      => __( 'Frontpage boxes - Background color', 'ti' ),
						'section'    => 'lawyeria_colors_section',
						'settings'   => 'lawyeria_fp_boxes_background',
						'priority'   => 10
					)
				)
		);
		
		/************** Frontpage box Headings color **************/
		
		$wp_customize->add_setting(
			'lawyeria_fp_boxes_headings_color',
			array(
				'default'     => '#394753'
			)
		);
		$wp_customize->add_control(
				new WP_Customize_Color_Control(
					$wp_customize,
					'lawyeria_fp_boxes_headings_color',
					array(
						'label'      => __( 'Frontpage boxes - Headings color', 'ti' ),
						'section'    => 'lawyeria_colors_section',
						'settings'   => 'lawyeria_fp_boxes_headings_color',
						'priority'   => 11
					)
				)
		);
		
		/************** Text color **************/
		
		$wp_customize->add_setting(
			'lawyeria_fp_boxes_text_color',
			array(
				'default'     => '#394753'
			)
		);
		$wp_customize->add_control(
				new WP_Customize_Color_Control(
					$wp_customize,
					'lawyeria_fp_boxes_text_color',
					array(
						'label'      => __( 'Text color', 'ti' ),
						'section'    => 'lawyeria_colors_section',
						'settings'   => 'lawyeria_fp_boxes_text_color',
						'priority'   => 12
					)
				)
		);
		
	endif;
	
	
	
	
	

    /*
    ** Header Customizer
    */
    $wp_customize->add_section( 'lawyers_header' , array(
    	'title'       => __( 'Header', 'ti' ),
    	'priority'    => 200,
	) );

		/* Header - Logo */
		$wp_customize->add_setting( 'ti_header_logo' );
		$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'ti_header_logo', array(
		    'label'    => __( 'Logo:', 'ti' ),
		    'section'  => 'lawyers_header',
		    'settings' => 'ti_header_logo',
		    'priority' => '1',
		) ) );

		/* Header - Title */
		$wp_customize->add_setting( 'ti_header_title' );
		$wp_customize->add_control( 'ti_header_title', array(
		    'label'    => __( 'Contact Title:', 'ti' ),
		    'section'  => 'lawyers_header',
		    'settings' => 'ti_header_title',
			'priority' => '2',
		) );

		/* Header - Subtitle */
		$wp_customize->add_setting( 'ti_header_subtitle' );
		$wp_customize->add_control( 'ti_header_subtitle', array(
		    'label'    => __( 'Contact telephone:', 'ti' ),
		    'section'  => 'lawyers_header',
		    'settings' => 'ti_header_subtitle',
			'priority' => '3',
		) );

    /*
    ** Front Page Customizer
    */
    $wp_customize->add_section( 'lawyers_frontpage' , array(
    	'title'       => __( 'Front Page', 'ti' ),
    	'priority'    => 250,
	) );

		/* Front Page - Contact Form 7 - Title */
		$wp_customize->add_setting( 'ti_frontpage_contactform7_title' );
		$wp_customize->add_control( 'ti_frontpage_contactform7_title', array(
		    'label'    => __( 'Contact Form 7 - Title:', 'ti' ),
		    'section'  => 'lawyers_frontpage',
		    'settings' => 'ti_frontpage_contactform7_title',
			'priority' => '1',
		) );

		/* Front Page - Contact Form 7 - Shortcode */
		$wp_customize->add_setting( 'ti_frontpage_contactform7_shortcode' );
		$wp_customize->add_control( new Example_Customize_Textarea_Control( $wp_customize, 'ti_frontpage_contactform7_shortcode', array(
		            'label' 	=> __( 'Contact Form 7 - Shortcode:', 'ti' ),
		            'section' 	=> 'lawyers_frontpage',
		            'settings' 	=> 'ti_frontpage_contactform7_shortcode',
		            'priority' 	=> '2'
		        )
		    )
		);

		/* Front Page - Header Title */
		$wp_customize->add_setting( 'ti_frontpage_header_title' );
		$wp_customize->add_control( 'ti_frontpage_header_title', array(
		    'label'    => __( 'Subheader Title:', 'ti' ),
		    'section'  => 'lawyers_frontpage',
		    'settings' => 'ti_frontpage_header_title',
			'priority' => '3',
		) );

		/* Front Page - Header Content */
		$wp_customize->add_setting( 'ti_frontpage_header_content' );
		$wp_customize->add_control( new Example_Customize_Textarea_Control( $wp_customize, 'ti_frontpage_header_content', array(
		            'label' 	=> __( 'Subheader Content:', 'ti' ),
		            'section' 	=> 'lawyers_frontpage',
		            'settings' 	=> 'ti_frontpage_header_content',
		            'priority' 	=> '4'
		        )
		    )
		);

		/* Front Page - Subheader Title */
		$wp_customize->add_setting( 'ti_frontpage_subheader_title' );
		$wp_customize->add_control( 'ti_frontpage_subheader_title', array(
		    'label'    => __( 'Quote Title:', 'ti' ),
		    'section'  => 'lawyers_frontpage',
		    'settings' => 'ti_frontpage_subheader_title',
			'priority' => '5',
		) );

		/* Front Page - Subheader Background */
		$wp_customize->add_setting( 'ti_frontpage_subheader_bg' );
		$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'ti_frontpage_subheader_bg', array(
		    'label'    => __( 'Subheader Background:', 'ti' ),
		    'section'  => 'lawyers_frontpage',
		    'settings' => 'ti_frontpage_subheader_bg',
		    'priority' => '6',
		) ) );

		/* Front Page - Firstly Box - Icon */
		$wp_customize->add_setting( 'ti_frontpage_firstlybox_icon' );
		$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'ti_frontpage_firstlybox_icon', array(
		    'label'    => __( 'Box (first) - Icon:', 'ti' ),
		    'section'  => 'lawyers_frontpage',
		    'settings' => 'ti_frontpage_firstlybox_icon',
		    'priority' => '7',
		) ) );

		/* Front Page - Firstly Box - Title */
		$wp_customize->add_setting( 'ti_frontpage_firstlybox_title' );
		$wp_customize->add_control( 'ti_frontpage_firstlybox_title', array(
		    'label'    => __( 'Box (first) - Title:', 'ti' ),
		    'section'  => 'lawyers_frontpage',
		    'settings' => 'ti_frontpage_firstlybox_title',
			'priority' => '8',
		) );

		/* Front Page - Firstly Box - Content */
		$wp_customize->add_setting( 'ti_frontpage_firstlybox_content' );
		$wp_customize->add_control( new Example_Customize_Textarea_Control( $wp_customize, 'ti_frontpage_firstlybox_content', array(
		            'label' 	=> __( 'Box (first) - Content:', 'ti' ),
		            'section' 	=> 'lawyers_frontpage',
		            'settings' 	=> 'ti_frontpage_firstlybox_content',
		            'priority' 	=> '9'
		        )
		    )
		);

		/* Front Page - Secondly Box - Icon */
		$wp_customize->add_setting( 'ti_frontpage_secondlybox_icon' );
		$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'ti_frontpage_secondlybox_icon', array(
		    'label'    => __( 'Box (two) - Icon:', 'ti' ),
		    'section'  => 'lawyers_frontpage',
		    'settings' => 'ti_frontpage_secondlybox_icon',
		    'priority' => '10',
		) ) );

		/* Front Page - Secondly Box - Title */
		$wp_customize->add_setting( 'ti_frontpage_secondlybox_title' );
		$wp_customize->add_control( 'ti_frontpage_secondlybox_title', array(
		    'label'    => __( 'Box (two) - Title:', 'ti' ),
		    'section'  => 'lawyers_frontpage',
		    'settings' => 'ti_frontpage_secondlybox_title',
			'priority' => '11',
		) );

		/* Front Page - Secondly Box - Content */
		$wp_customize->add_setting( 'ti_frontpage_secondlybox_content' );
		$wp_customize->add_control( new Example_Customize_Textarea_Control( $wp_customize, 'ti_frontpage_secondlybox_content', array(
		            'label' 	=> __( 'Box (two) - Content:', 'ti' ),
		            'section' 	=> 'lawyers_frontpage',
		            'settings' 	=> 'ti_frontpage_secondlybox_content',
		            'priority' 	=> '12'
		        )
		    )
		);

		/* Front Page - Thirdly Box - Icon */
		$wp_customize->add_setting( 'ti_frontpage_thirdlybox_icon' );
		$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'ti_frontpage_thirdlybox_icon', array(
		    'label'    => __( 'Box (three) - Icon:', 'ti' ),
		    'section'  => 'lawyers_frontpage',
		    'settings' => 'ti_frontpage_thirdlybox_icon',
		    'priority' => '13',
		) ) );

		/* Front Page - Thirdly Box - Title */
		$wp_customize->add_setting( 'ti_frontpage_thirdlybox_title' );
		$wp_customize->add_control( 'ti_frontpage_thirdlybox_title', array(
		    'label'    => __( 'Box (three) - Title:', 'ti' ),
		    'section'  => 'lawyers_frontpage',
		    'settings' => 'ti_frontpage_thirdlybox_title',
			'priority' => '14',
		) );

		/* Front Page - Thirdly Box - Content */
		$wp_customize->add_setting( 'ti_frontpage_thirdlybox_content' );
		$wp_customize->add_control( new Example_Customize_Textarea_Control( $wp_customize, 'ti_frontpage_thirdlybox_content', array(
		            'label' 	=> __( 'Box (three) - Content:', 'ti' ),
		            'section' 	=> 'lawyers_frontpage',
		            'settings' 	=> 'ti_frontpage_thirdlybox_content',
		            'priority' 	=> '15'
		        )
		    )
		);

		/* Front Page - The Content - Image */
		$wp_customize->add_setting( 'ti_frontpage_thecontent_image' );
		$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'ti_frontpage_thecontent_image', array(
		    'label'    => __( 'The Content - Image:', 'ti' ),
		    'section'  => 'lawyers_frontpage',
		    'settings' => 'ti_frontpage_thecontent_image',
		    'priority' => '16',
		) ) );

		/* Front Page - The Content - Title */
		$wp_customize->add_setting( 'ti_frontpage_thecontent_title' );
		$wp_customize->add_control( 'ti_frontpage_thecontent_title', array(
		    'label'    => __( 'The Content - Title:', 'ti' ),
		    'section'  => 'lawyers_frontpage',
		    'settings' => 'ti_frontpage_thecontent_title',
			'priority' => '17',
		) );

		/* Front Page - The Content - Content */
		$wp_customize->add_setting( 'ti_frontpage_thecontent_content' );
		$wp_customize->add_control( new Example_Customize_Textarea_Control( $wp_customize, 'ti_frontpage_thecontent_content', array(
		            'label' 	=> __( 'The Content - Content:', 'ti' ),
		            'section' 	=> 'lawyers_frontpage',
		            'settings' 	=> 'ti_frontpage_thecontent_content',
		            'priority' 	=> '18'
		        )
		    )
		);

		/* Front Page - Practice Areas - Title */
		$wp_customize->add_setting( 'ti_frontpage_practiceareas_title' );
		$wp_customize->add_control( 'ti_frontpage_practiceareas_title', array(
		    'label'    => __( 'Practice Areas - Title:', 'ti' ),
		    'section'  => 'lawyers_frontpage',
		    'settings' => 'ti_frontpage_practiceareas_title',
			'priority' => '19',
		) );

		/* Front Page - Our Lawyers - Title */
		$wp_customize->add_setting( 'ti_frontpage_ourlawyers_title' );
		$wp_customize->add_control( 'ti_frontpage_ourlawyers_title', array(
		    'label'    => __( 'Our Lawyers - Title:', 'ti' ),
		    'section'  => 'lawyers_frontpage',
		    'settings' => 'ti_frontpage_ourlawyers_title',
			'priority' => '20',
		) );

		/* Front Page - Testimonials - Title */
		$wp_customize->add_setting( 'ti_frontpage_testimonials_title' );
		$wp_customize->add_control( 'ti_frontpage_testimonials_title', array(
		    'label'    => __( 'Testimonials - Title:', 'ti' ),
		    'section'  => 'lawyers_frontpage',
		    'settings' => 'ti_frontpage_testimonials_title',
			'priority' => '21',
		) );

		/* Front Page - Testimonials - Number of posts */
		$wp_customize->add_setting( 'ti_frontpage_testimonials_numberofposts' );
		$wp_customize->add_control( 'ti_frontpage_testimonials_numberofposts', array(
		    'label'    => __( 'Testimonials - Number of posts:', 'ti' ),
		    'section'  => 'lawyers_frontpage',
		    'settings' => 'ti_frontpage_testimonials_numberofposts',
			'priority' => '22',
		) );

		/* Front Page - Testimonials - Offset */
		$wp_customize->add_setting( 'ti_frontpage_testimonials_offset' );
		$wp_customize->add_control( 'ti_frontpage_testimonials_offset', array(
		    'label'    => __( 'Testimonials - Offset:', 'ti' ),
		    'section'  => 'lawyers_frontpage',
		    'settings' => 'ti_frontpage_testimonials_offset',
			'priority' => '23',
		) );

    /*
    ** Practice Areas Customizer
    */
    $wp_customize->add_section( 'lawyers_practiceareas' , array(
    	'title'       => __( 'Practice Areas', 'ti' ),
    	'priority'    => 300,
	) );

		/* Practice Areas - Navigation Title */
		$wp_customize->add_setting( 'ti_practicearea_navigation_title' );
		$wp_customize->add_control( 'ti_practicearea_navigation_title', array(
		    'label'    => __( 'Navigation Title:', 'ti' ),
		    'section'  => 'lawyers_practiceareas',
		    'settings' => 'ti_practicearea_navigation_title',
			'priority' => '1',
		) );

	    /* Practice Areas - Content */
		$wp_customize->add_setting( 'ti_practicearea_content' );
		$wp_customize->add_control( new Example_Customize_Textarea_Control( $wp_customize, 'ti_practicearea_content', array(
		            'label' 	=> __( 'The Content:', 'ti' ),
		            'section' 	=> 'lawyers_practiceareas',
		            'settings' 	=> 'ti_practicearea_content',
		            'priority' 	=> '2'
		        )
		    )
		);

		/* Practice Areas - Categories Title */
		$wp_customize->add_setting( 'ti_practicearea_categories_title' );
		$wp_customize->add_control( 'ti_practicearea_categories_title', array(
		    'label'    => __( 'Categories Title:', 'ti' ),
		    'section'  => 'lawyers_practiceareas',
		    'settings' => 'ti_practicearea_categories_title',
			'priority' => '3',
		) );

	$wp_customize->add_section( 'lawyers_lawyer_single' , array(
    	'title'       => __( 'Lawyer - Single Page', 'ti' ),
    	'priority'    => 350,
	) );

		/* Lawyer - Single Lawyer */
		$wp_customize->add_setting( 'ti_lawyer_categories_title' );
		$wp_customize->add_control( 'ti_lawyer_categories_title', array(
		    'label'    => __( 'Lawyer Single - Categories:', 'ti' ),
		    'section'  => 'lawyers_lawyer_single',
		    'settings' => 'ti_lawyer_categories_title',
			'priority' => '1',
		) );

	/*
    ** Testimonials - Page
    */
    $wp_customize->add_section( 'lawyers_testimonials_page' , array(
    	'title'       => __( 'Testimonials - Page', 'ti' ),
    	'priority'    => 400,
	) );

	    /* Testimonials - Page - Number of posts */
		$wp_customize->add_setting( 'ti_testimonials_page_numberofposts' );
		$wp_customize->add_control( 'ti_testimonials_page_numberofposts', array(
		    'label'    => __( 'Number of posts:', 'ti' ),
		    'section'  => 'lawyers_testimonials_page',
		    'settings' => 'ti_testimonials_page_numberofposts',
			'priority' => '1',
		) );

	/*
    ** 404 Customizer
    */
    $wp_customize->add_section( 'constructzine_404' , array(
    	'title'       => __( '404 Page', 'ti' ),
    	'priority'    => 450,
	) );

		/* 404 - Title */
		$wp_customize->add_setting( 'ti_404_title' );
		$wp_customize->add_control( 'ti_404_title', array(
		    'label'    => __( '404 - Title:', 'ti' ),
		    'section'  => 'constructzine_404',
		    'settings' => 'ti_404_title',
			'priority' => '1',
		) );

		/* 404 - Content */
		$wp_customize->add_setting( 'ti_404_content' );
		$wp_customize->add_control( new Example_Customize_Textarea_Control( $wp_customize, 'ti_404_content', array(
		            'label' 	=> __( '404 - Content', 'ti' ),
		            'section' 	=> 'constructzine_404',
		            'settings' 	=> 'ti_404_content',
		            'priority' 	=> '2'
		        )
		    )
		);


}
add_action( 'customize_register', 'lawyeria_customizer' );

if( class_exists( 'WP_Customize_Control' ) ):
	class Example_Customize_Textarea_Control extends WP_Customize_Control {
	    public $type = 'textarea';

	    public function render_content() { ?>

	        <label>
	        	<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
	        	<textarea rows="5" style="width:100%;" <?php $this->link(); ?>><?php echo esc_textarea( $this->value() ); ?></textarea>
	        </label>

	        <?php
	    }
	}
endif;

?>