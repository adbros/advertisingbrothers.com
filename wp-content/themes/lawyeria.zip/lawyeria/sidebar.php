<?php
/**
 *  The template for displaying Sidebar.
 *
 *  @package ThemeIsle.
 */
?>
<aside id="sidebar-right">
	<?php dynamic_sidebar( 'right-sidebar' ); ?>
</aside><!--/aside #sidebar-right-->