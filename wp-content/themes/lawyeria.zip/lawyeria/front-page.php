		<?php
		/**
		 *  The template for displaying Front Page.
		 *
		 *  @package ThemeIsle.
		 */
		get_header();
		?>
			<div id="subheader" style="background-image: url('<?php
				if ( get_theme_mod( 'ti_frontpage_subheader_bg' ) != false ) {
				    echo get_theme_mod( 'ti_frontpage_subheader_bg' );
			     } else {
				    echo get_template_directory_uri() . "/images/full-header.jpg";
			    }
			 ?>');">
				<div class="subheader-color cf">
					<div class="wrapper cf">
						<div class="full-header-content <?php if ( get_theme_mod( 'ti_frontpage_contactform7_shortcode' ) ) { } else { echo 'full-header-content-no-sidebar'; } ?>">
							<h3>
								<?php
									if ( get_theme_mod( 'ti_frontpage_header_title' ) != false ) {
										echo get_theme_mod( 'ti_frontpage_header_title' );
									} else {
										echo _e( 'Lorem ipsum dolor sit amet, consectetur adipscing elit.', 'ti' );
									}
								?>
							</h3><!--/h3-->
							<p>
								<?php
									if ( get_theme_mod( 'ti_frontpage_header_content' ) != false ) {
										echo get_theme_mod( 'ti_frontpage_header_content' );
									} else {
										echo _e( 'Ut fermentum aliquam neque, sit amet molestie orci porttitor sit amet. Mauris venenatis et tortor ut ultrices. Nam a neque venenatis, tristique lacus id, congue augue. In id tellus lacus. In porttitor sagittis tellus nec iaculis. Nunc sem odio, placerat a diam vel, varius.', 'ti' );
									}
								?>
							</p><!--/p-->
						</div><!--/div .header-content-->
						<?php
						if ( get_theme_mod( 'ti_frontpage_contactform7_shortcode' ) ) {
							echo '<div class="header-form">';

							if ( get_theme_mod( 'ti_frontpage_contactform7_title' ) ) {
								echo '<p>'. get_theme_mod( 'ti_frontpage_contactform7_title' ) .'</p>';
							}

							echo do_shortcode( get_theme_mod( 'ti_frontpage_contactform7_shortcode' ) );
							echo '</div>';
						}
						?>
					</div><!--/div .wrapper-->
				</div><!--/div .full-header-color-->
				<div class="second-subheader">
					<div class="wrapper">
						<h3>
							<?php
								if ( get_theme_mod( 'ti_frontpage_subheader_title' ) != false ) {
									echo get_theme_mod( 'ti_frontpage_subheader_title' );
								} else {
									echo _e( 'Lorem Ipsum is simply dummy text of the printing and type setting industry.', 'ti' );
								}
							?>
						</h3><!--/h3-->
					</div><!--/div .wrapper-->
				</div><!--/div .second-subheader-->
			</div><!--/div #subheader-->
		</header><!--/header-->
		<section id="features">
			<div class="wrapper cf">
				<div class="features-box">
					<div class="features-box-icon">
						<?php
							if ( get_theme_mod( 'ti_frontpage_firstlybox_icon' ) != false ) { ?>
								<img src="<?php echo get_theme_mod( 'ti_frontpage_firstlybox_icon' ); ?>" alt="<?php echo get_theme_mod( 'ti_frontpage_firstlybox_title' ); ?>" title="<?php echo get_theme_mod( 'ti_frontpage_firstlybox_title' ); ?>" />
							<?php } else { ?>
								<img src="<?php echo get_template_directory_uri(); ?>/images/features-box-icon-one.png" alt="<?php echo get_theme_mod( 'ti_frontpage_firstlybox_title' ); ?>" title="<?php echo get_theme_mod( 'ti_frontpage_firstlybox_title' ); ?>" />
							<?php } ?>
					</div><!--/div .features-box-icon-->
					<h4>
						<?php
							if ( get_theme_mod( 'ti_frontpage_firstlybox_title' ) != false ) {
								echo get_theme_mod( 'ti_frontpage_firstlybox_title' );
							} else {
								echo _e( 'Lorem', 'ti' );
							}
						?>
					</h4><!--/h4-->
					<p>
						<?php
							if ( get_theme_mod( 'ti_frontpage_firstlybox_content' ) != false ) {
								echo get_theme_mod( 'ti_frontpage_firstlybox_content' );
							} else {
								echo _e( 'Go to Appearance - Customize, to add content.', 'ti' );
							}
						?>
					</p><!--/p-->
				</div><!--/div .features-box-->
				<div class="features-box">
					<div class="features-box-icon">
						<?php
							if ( get_theme_mod( 'ti_frontpage_secondlybox_icon' ) != false ) { ?>
								<img src="<?php echo get_theme_mod( 'ti_frontpage_secondlybox_icon' ); ?>" alt="<?php echo get_theme_mod( 'ti_frontpage_secondlybox_title' ); ?>" title="<?php echo get_theme_mod( 'ti_frontpage_secondlybox_title' ); ?>" />
							<?php } else { ?>
								<img src="<?php echo get_template_directory_uri(); ?>/images/features-box-icon-two.png" alt="<?php echo get_theme_mod( 'ti_frontpage_secondlybox_title' ); ?>" title="<?php echo get_theme_mod( 'ti_frontpage_secondlybox_title' ); ?>" />
							<?php } ?>
						<?php ?>
					</div><!--/div .features-box-icon-->
					<h4>
						<?php
							if ( get_theme_mod( 'ti_frontpage_secondlybox_title' ) != false ) {
								echo get_theme_mod( 'ti_frontpage_secondlybox_title' );
							} else {
								echo _e( 'Ipsum', 'ti' );
							}
						?>
					</h4><!--/h4-->
					<p>
						<?php
							if ( get_theme_mod( 'ti_frontpage_secondlybox_content' ) != false ) {
								echo get_theme_mod( 'ti_frontpage_secondlybox_content' );
							} else {
								echo _e( 'Go to Appearance - Customize, to add content.', 'ti' );
							}
						?>
					</p><!--/p-->
				</div><!--/div .features-box-->
				<div class="features-box">
					<div class="features-box-icon">
						<?php
							if ( get_theme_mod( 'ti_frontpage_thirdlybox_icon' ) != false ) { ?>
								<img src="<?php echo get_theme_mod( 'ti_frontpage_thirdlybox_icon' ); ?>" alt="<?php echo get_theme_mod( 'ti_frontpage_thirdlybox_title' ); ?>" title="<?php echo get_theme_mod( 'ti_frontpage_thirdlybox_title' ); ?>" />
							<?php } else { ?>
								<img src="<?php echo get_template_directory_uri(); ?>/images/features-box-three.png" alt="<?php echo get_theme_mod( 'ti_frontpage_thirdlybox_title' ); ?>" title="<?php echo get_theme_mod( 'ti_frontpage_thirdlybox_title' ); ?>" />
							<?php } ?>
						<?php ?>
					</div><!--/div .features-box-icon-->
					<h4>
						<?php
							if ( get_theme_mod( 'ti_frontpage_thirdlybox_title' ) != false ) {
								echo get_theme_mod( 'ti_frontpage_thirdlybox_title' );
							} else {
								echo _e( 'Dolor', 'ti' );
							}
						?>
					</h4><!--/h4-->
					<p>
						<?php
							if ( get_theme_mod( 'ti_frontpage_thirdlybox_content' ) != false ) {
								echo get_theme_mod( 'ti_frontpage_thirdlybox_content' );
							} else {
								echo _e( 'Go to Appearance - Customize, to add content.', 'ti' );
							}
						?>
					</p><!--/p-->
				</div><!--/div .features-box-->
			</div><!--/div .wrapper-->
		</section><!--/section #features-->
		<section id="content">
			<div class="wrapper">
				<div class="content-article cf" role="main">
					<div class="content-article-image">
						<?php
							if ( get_theme_mod( 'ti_frontpage_thecontent_image' ) != false ) { ?>
								<img src="<?php echo get_theme_mod( 'ti_frontpage_thecontent_image' ); ?>" alt="<?php echo get_theme_mod( 'ti_frontpage_thecontent_title' ); ?>" title="<?php echo get_theme_mod( 'ti_frontpage_thecontent_title' ); ?>" />
							<?php } else { ?>
								<img src="<?php echo get_template_directory_uri(); ?>/images/content-article-image.png" alt="<?php echo get_theme_mod( 'ti_frontpage_thecontent_title' ); ?>" title="<?php echo get_theme_mod( 'ti_frontpage_thecontent_title' ); ?>" />
							<?php } ?>
						<?php ?>
					</div><!--/div .content-article-image-->
					<h3>
						<?php
							if ( get_theme_mod( 'ti_frontpage_thecontent_title' ) != false ) {
								echo get_theme_mod( 'ti_frontpage_thecontent_title' );
							} else {
								echo _e( 'Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis.', 'ti' );
							}
						?>
					</h3><!--/h3-->
					<p>
						<?php
							if ( get_theme_mod( 'ti_frontpage_thecontent_content' ) != false ) {
								echo get_theme_mod( 'ti_frontpage_thecontent_content' );
							} else {
								echo _e( 'Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris. Morbi accumsan ipsum velit. Nam nec tellus a odio tincidunt auctor a ornare odio. Sed non  mauris vitae erat consequat auctor eu in elit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Mauris in erat justo. Nullam ac urna eu felis dapibus condimentum sit amet a augue. Sed non neque elit. Sed ut imperdiet nisi. Proin condimentum fermentum nunc. Etiam pharetra, erat sed fermentum feugiat, velit mauris egestas quam, ut aliquam massa nisl quis neque. Suspendisse in orci enim.', 'ti' );
							}
						?>
					</p><!--/p-->
				</div><!--/div .content-article .cf-->
				<div class="content-about cf">
					<div class="practice-area">
						<div class="content-about-title">
							<?php
								if ( get_theme_mod( 'ti_frontpage_practiceareas_title' ) != false ) {
									echo get_theme_mod( 'ti_frontpage_practiceareas_title' );
								} else {
									echo _e( 'Practice Areas', 'ti' );
								}
							?>
						</div><!--/div .content-about-title-->
						<ul>
							<?php
								$get_taxonomy = get_terms( 'practiceareas' );
								foreach ( $get_taxonomy as $taxonomy_category ) {
									$taxonomy_category = sanitize_term( $taxonomy_category, 'lawyers' );
									$term_link = get_term_link( $taxonomy_category, 'lawyers' ); ?>
									<li>
										<a href="<?php echo esc_url( $term_link ); ?>" title="<?php echo $taxonomy_category->name; ?>">
											<?php echo $taxonomy_category->name; ?>
										</a><!--/a-->
									</li><!--/li-->
								<?php } ?>
							<?php ?>
						</ul><!--/ul-->
					</div><!--/div .practice-area-->
					<div class="our-lawyers">
						<div class="content-about-title">
							<?php
								if ( get_theme_mod( 'ti_frontpage_ourlawyers_title' ) != false ) {
									echo get_theme_mod( 'ti_frontpage_ourlawyers_title' );
								} else {
									echo _e( 'Our Lawyers', 'ti' );
								}
							?>
						</div><!--/div .content-about-title-->

						<?php
							$args = array (
								'post_type'              => 'lawyers',
								'posts_per_page'         => '5',
								'ignore_sticky_posts'    => true,
								'paged'					 => $paged,
							);

							$lawyers = new WP_Query( $args );

							if ( $lawyers->have_posts() ) : while ( $lawyers->have_posts() ) : $lawyers->the_post();
							$featured_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'single-post-thumbnail' );
						?>

						<?php
						    if ( $featured_image != NULL ) { ?>
                                <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" class="lawyer" style="background-image: url('<?php echo $featured_image[0]; ?>'); ?>">
                                    <div class="widget-our-lawyers-mask">
                                    </div><!--/div .widget-our-lawyers-mask-->
                                </a><!--/a.lawyer-->
                            <?php } else { ?>
                                <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" class="lawyer lawyer-no-image">
                                    <div class="widget-our-lawyers-mask">
                                    </div><!--/div .widget-our-lawyers-mask-->
                                </a><!--/a .lawyer .lawyer-no-image-->
                            <?php }
						?>

						<?php endwhile; else: ?>
							<p><?php _e('Sorry, no posts matched your criteria.', 'ti'); ?></p>
						<?php endif; ?>
						<?php wp_reset_postdata(); ?>

					</div><!--/div .our-lawyers-->
				</div><!--/div .content-about-->
				<div class="content-testimonials">
					<div class="testimonials-title">
						<?php
							if ( get_theme_mod( 'ti_frontpage_testimonials_title' ) != false ) {
								echo get_theme_mod( 'ti_frontpage_testimonials_title' );
							} else {
								echo _e( 'What customers say', 'ti' );
							}
						?>
					</div><!--/div .testimonials-title-->
					<div class="list_carousel">
						<ul id="foo2">

							<?php
							    $offset = get_theme_mod( 'ti_frontpage_testimonials_offset' );
							    $numberofposts = get_theme_mod( 'ti_frontpage_testimonials_numberofposts' );
								$args = array (
								    'offset'                 => $offset,
									'post_type'              => 'testimonials',
									'posts_per_page'         => $numberofposts,
									'ignore_sticky_posts'    => true,
									'paged'					 => $paged,
								);

								$testimonials = new WP_Query( $args );

								if ( $testimonials->have_posts() ) : while ( $testimonials->have_posts() ) : $testimonials->the_post();

								$testimonials_position = get_post_meta($post->ID, 'ti_testimonials_position', true);
								$testimonials_company_name = get_post_meta($post->ID, 'ti_testimonials_company_name', true);
								$testimonials_company_url = get_post_meta($post->ID, 'ti_testimonials_company_url', true);

								if ( ( $testimonials_position && $testimonials_company_name ) == NULL ) {
								    $at = '';
								} else {
								    $at = ' at ';
								}

								if ( ( $testimonials_position && $testimonials_company_name ) == NULL ) {
								    $line = '';
								} else {
								    $line = '-';
								}
							?>

							<li>
								<div class="list_carousel_entry">
									<?php echo testimonials_excerpt(65); ?>
								</div><!--/div .list_carousel_entry-->
								<div class="list_carousel_customer">
									<span><?php the_title(); ?> <?php echo $line; ?> </span>
									<?php echo $testimonials_position; ?> <?php echo $at; ?>
									<?php
									if ( $testimonials_company_url != false ) {
									    echo '<a href="'. $testimonials_company_url .'" title="'. $testimonials_company_name .'">'. $testimonials_company_name .'</a>';
									} else {
									    echo $testimonials_company_name;
									}
									?>
								</div><!--/div .list_carousel_customer-->
							</li><!--/li-->

							<?php endwhile; else: ?>
								<p><?php _e('Sorry, no posts matched your criteria.', 'ti'); ?></p>
							<?php endif; ?>
							<?php wp_reset_postdata(); ?>

						</ul><!--/ul-->
						<div class="clearfix"></div>
						<a id="prev2" class="prev" href="#"></a>
						<a id="next2" class="next" href="#"></a>
					</div><!--/div .list_carousel-->
				</div><!--/div .content-testimonials-->
			</div><!--/div .wrapper-->
		</section><!--/section #content-->
		<?php get_footer(); ?>