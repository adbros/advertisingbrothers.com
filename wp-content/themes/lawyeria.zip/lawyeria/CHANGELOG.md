

### 1.2.3 - 22/01/2015

 Changes: 


 * Add customize colors for menu, header, footer, and frontpage boxes
 * Update style.css


### 1.2.2 - 20/10/2014

 Changes: 


 * Fixed contact form sending from front page
 * Updated theme version to 1.2.2


### 1.2.1 - 17/10/2014

 Changes: 


 * initial commit
 * Update functions.php
 * small test
 * Merge branch 'development' of https://github.com/Codeinwp/laweria into development
 * remove latest
 * small fix
 * Updated theme uri, documentation link and forum link
 * small fix, documentation link
 * testimonials fix and translate, rtl
 * fix testimonials
 * Update functions.php
 * Logo customizer fix.

I added field on customizer for logo.
 * Increased theme version
 * Issue #3. Problema fonts in style.css issue fixed.

Rezolvat.
 * Issue #5. Adaugat contact form 7 issue fixed.

Rezolvat.
 * Issue #6. Title best practices issue fixed.

Rezolvat.
