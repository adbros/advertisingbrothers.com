<?php
/**
 *  The template for displaying Header.
 *
 *  @package ThemeIsle.
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
		<meta http-equiv="<?php echo get_template_directory_uri();?>/content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
		<meta charset="UTF-8">
		<title><?php echo cwp_wp_title( $title, $sep ); ?></title>
		<!--[if lt IE 9]>
		    <style>
		        #subheader {
                    filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(
                        src='<?php echo get_template_directory_uri(); ?>/images/full-header.jpg',
                        sizingMethod='scale'
                    );
                    -ms-filter: "progid:DXImageTransform.Microsoft.AlphaImageLoader(
                        src='<?php echo get_template_directory_uri(); ?>/images/full-header.jpg',
                        sizingMethod='scale'
                    )";
                }
		    </style>
		    <link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri(); ?>/css/ie8.css" />
			<script src="<?php echo get_template_directory_uri(); ?>/js/html5shiv.js"></script>
		<![endif]-->
		<?php wp_head(); ?>
	</head>
	<body <?php body_class( $class ); ?>>
		<header>
			<div class="wide-header">
				<div class="wrapper cf">
					<div class="header-left cf">
						<a class="logo" href="<?php echo home_url(); ?>" title="<?php wp_title('|', true, 'right'); bloginfo('name'); ?>">
                            <?php
                            if ( get_theme_mod( 'ti_header_logo' ) ) {
                                echo '<img src="'. get_theme_mod( 'ti_header_logo' ) .'" alt="'. get_bloginfo( 'name' ) .'" title="'. get_bloginfo( 'name' ) .'" />';
                            } else {
                                echo '<img src="'. get_template_directory_uri() .'/images/header-logo.png" alt="'. get_bloginfo( 'name' ) .'" title="'. get_bloginfo( 'name' ) .'" />';
                            }
                            ?>
						</a><!--/a .logo-->
					</div><!--/div .header-left .cf-->
					<div class="header-contact">
    					<?php
    						if ( get_theme_mod( 'ti_header_title' ) != false ) {
    							echo get_theme_mod( 'ti_header_title' );
    						} else {
    							echo 'Contact us now';
    						}
    					?>
    					<br />
    					<span>
    						<?php
    							if ( get_theme_mod( 'ti_header_subtitle' ) != false ) { ?>
                                    <a href="tel: <?php echo get_theme_mod( 'ti_header_subtitle' ); ?>" title="<?php echo get_theme_mod( 'ti_header_subtitle' ); ?>"><?php echo get_theme_mod( 'ti_header_subtitle' ); ?></a>
    							<?php } else { ?>
    							    <a href="tel: <?php _e( '+1-888-846-1732', 'ti' ); ?>" title="<?php echo get_theme_mod( 'ti_header_subtitle' ); ?>"><?php _e( '+1-888-846-1732', 'ti' ); ?></a>
    							<?php }
    						?>
    					</span><!--/span-->
					</div><!--/.header-contact-->
				</div><!--/div .wrapper-->
			</div><!--/div .wide-header-->
			<div class="wrapper cf">
			    <nav>
    				<div class="openresponsivemenu">
    					Open Menu
    				</div><!--/div .openresponsivemenu-->
    				<div class="container-menu cf">
        				<?php
        					wp_nav_menu(
        					    array(
        						        'theme_location' => 'header-menu',
        							)
        						);
        					?>
    				</div><!--/div .container-menu .cf-->
    			</nav><!--/nav .navigation-->
		    </div>