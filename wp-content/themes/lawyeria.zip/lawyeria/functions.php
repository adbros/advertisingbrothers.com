<?php

/**
 *  Require Once
 */
require_once( 'includes/custom-functions.php' );
require_once( 'includes/metaboxes/example-functions.php' );
require_once( 'includes/customizer.php' );
require_once( 'includes/widgets.php' );
require_once( 'includes/tgm-plugin-activation/tgm-plugin-activation.php' );

/**
 *  CWP WP Title
 */
function cwp_wp_title( $title, $sep ) {
    global $paged, $page;

    if ( is_feed() )
        return $title;

    // Add the site name.
    $title .= get_bloginfo( 'name' );

    // Add the site description for the home/front page.
    $site_description = get_bloginfo( 'description', 'display' );
    if ( $site_description && ( is_home() || is_front_page() ) )
        $title = "$title $sep $site_description";

    // Add a page number if necessary.
    if ( $paged >= 2 || $page >= 2 )
        $title = "$title $sep " . sprintf( __( 'Page %s', 'metrox' ), max( $paged, $page ) );

    return $title;
}
add_filter( 'wp_title', 'cwp_wp_title', 10, 2 );

/**
 *  Content Width
 */
if ( ! isset( $content_width ) ) $content_width = 634;

add_theme_support( 'automatic-feed-links' );

/**
 *  WP Enqueue Style
 */
function wp_enqueue_style_lawyeria() {
    wp_enqueue_style( 'style', get_stylesheet_uri(), array(), '1.0' );
    wp_enqueue_style( 'fancybox', get_template_directory_uri() . '/css/jquery.fancybox.css', array(), '1.0' );
}

add_action( 'wp_enqueue_scripts', 'wp_enqueue_style_lawyeria' );

/**
 *  WP Enqueue Script
 */
function wp_enqueue_scripts_lawyeria() {
    wp_enqueue_script( 'jquery');
    wp_enqueue_script( 'carouFredSel', get_template_directory_uri() . '/js/jquery.carouFredSel-6.2.1-packed.js', array( 'jquery' ), '6.2.1', true );
    wp_enqueue_script( 'fancybox', get_template_directory_uri() . '/js/jquery.fancybox.js', array( 'jquery' ), '1.0', true );
    wp_enqueue_script( 'masonry', get_template_directory_uri() . '/js/jquery.masonry.js', array( 'jquery' ), '1.0', true );
    wp_enqueue_script( 'scripts', get_template_directory_uri() . '/js/scripts.js', array( 'jquery' ), '1.0', true );
    if ( is_singular() ) wp_enqueue_script( "comment-reply" );
}

add_action( 'wp_enqueue_scripts', 'wp_enqueue_scripts_lawyeria' );

/**
 *  Header Menu
 */
function header_menu() {

	$locations = array(
		'header-menu' => __( 'This menu will appear in header.', 'ti' ),
	);
	register_nav_menus( $locations );

}

add_action( 'init', 'header_menu' );

/**
 *  Post Thumbnail
 */
add_theme_support( 'post-thumbnails' );

/**
 *  Add classes for next and previous navigation
 */
add_filter('next_posts_link_attributes', 'posts_link_attributes_prev');
add_filter('previous_posts_link_attributes', 'posts_link_attributes_next');

function posts_link_attributes_prev() {
    return 'class="left-navigation"';
}

function posts_link_attributes_next() {
    return 'class="right-navigation"';
}

/**
 *  Add classes for next and previous post
 */
function posts_link_next_class($format){
     $format = str_replace('href=', 'class="next-post" href=', $format);
     return $format;
}
add_filter('next_post_link', 'posts_link_next_class');

function posts_link_prev_class($format) {
     $format = str_replace('href=', 'class="previous-post" href=', $format);
     return $format;
}
add_filter('previous_post_link', 'posts_link_prev_class');

/**
 *  Right Sidebar
 */
function right_sidebar() {

	$args = array(
		'id'            => 'right-sidebar',
		'name'          => __( 'General Sidebar', 'ti' ),
		'description'   => __( 'Use this sidebar to display widgets in your website, including posts and pages.', 'ti' ),
		'before_title'  => '<div class="title-widget">',
		'after_title'   => '</div>',
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget'  => '</div>',
	);
	register_sidebar( $args );

}

add_action( 'widgets_init', 'right_sidebar' );

/**
 *  Footer Sidebar - One
 */
function footer_sidebar() {

    $args = array(
        'id'            => 'footer-sidebar',
        'name'          => __( 'Footer Sidebar', 'ti' ),
        'description'   => __( 'In this sidebar you cand add max. three widgets.', 'ti' ),
        'before_title'  => '<div class="footer-box-title">',
        'after_title'   => '</div>',
        'before_widget' => '<div id="%1$s" class="footer-box %2$s">',
        'after_widget'  => '</div>',
    );
    register_sidebar( $args );

}

add_action( 'widgets_init', 'footer_sidebar' );

/**
 *  Shape Comment
 */
if ( ! function_exists( 'shape_comment' ) ) :

function shape_comment( $comment, $args, $depth ) {
    $GLOBALS['comment'] = $comment;
    switch ( $comment->comment_type ) :
        case 'pingback' :
        case 'trackback' :
    ?>
    <li class="post pingback">
        <p><?php _e( 'Pingback:', 'shape' ); ?> <?php comment_author_link(); ?><?php edit_comment_link( __( '(Edit)', 'shape' ), ' ' ); ?></p>
    <?php
            break;
        default :
    ?>
    <li <?php comment_class(); ?> id="li-comment-<?php comment_ID(); ?>">
        <article id="comment-<?php comment_ID(); ?>" class="comment">
            <?php echo get_avatar( $comment, 120 ); ?>
            <div class="comment-entry">
                <div class="comment-entry-head">
                    <?php printf( __( '<span>%s</span>', 'shape' ), sprintf( '%s', get_comment_author_link() ) ); ?> -
                    <a href="<?php echo esc_url( get_comment_link( $comment->comment_ID ) ); ?>" class="comment-entry-head-date">
                        <time pubdate datetime="<?php comment_time( 'c' ); ?>">
                            <?php printf( __( '%1$s at %2$s', 'shape' ), get_comment_date(), get_comment_time() ); ?>
                        </time>
                    </a><!--/a .comment-entry-head-date-->
                    <?php edit_comment_link( __( 'Edit', 'shape' ), '- ' ); ?>
                </div><!--/div .comment-entry-head-->
                <div class="comment-entry-content">
                    <?php comment_text(); ?>
                </div><!--/div .comment-entry-content-->
                <?php if ( $comment->comment_approved == '0' ) : ?>
                    <em class="awaiting-moderation cf"><?php _e( 'Your comment is awaiting moderation.', 'shape' ); ?></em><br />
                <?php endif; ?>
                <div class="coment-reply-link-div cf">
                    <?php comment_reply_link( array_merge( $args, array( 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?>
                </div><!--/div .coment-reply-link-div-->
            </div><!--/div .comment-entry-->
        </article><!--/article-->

    <?php
            break;
    endswitch;
}
endif;

/**
 *  Post Gallery
 */
add_filter('post_gallery', 'my_post_gallery', 10, 2);
function my_post_gallery($output, $attr) {
    global $post;

    if (isset($attr['orderby'])) {
        $attr['orderby'] = sanitize_sql_orderby($attr['orderby']);
        if (!$attr['orderby'])
            unset($attr['orderby']);
    }

    extract(shortcode_atts(array(
        'order' => 'ASC',
        'orderby' => 'menu_order ID',
        'id' => $post->ID,
        'itemtag' => 'dl',
        'icontag' => 'dt',
        'captiontag' => 'dd',
        'columns' => 3,
        'size' => 'thumbnail',
        'include' => '',
        'exclude' => ''
    ), $attr));

    $id = intval($id);
    if ('RAND' == $order) $orderby = 'none';

    if (!empty($include)) {
        $include = preg_replace('/[^0-9,]+/', '', $include);
        $_attachments = get_posts(array('include' => $include, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $order, 'orderby' => $orderby));

        $attachments = array();
        foreach ($_attachments as $key => $val) {
            $attachments[$val->ID] = $_attachments[$key];
        }
    }

    if (empty($attachments)) return '';
    // Here's your actual output, you may customize it to your need
    $output = "<div id='custom-gallery gallery-". $post->ID ."' class='gallery galleryid-". $post->ID ." gallery-columns-". $columns ."'>\n";

    // Now you loop through each attachment
    foreach ($attachments as $id => $attachment) {
        // Fetch the thumbnail (or full image, it's up to you)
//      $img = wp_get_attachment_image_src($id, 'medium');
//      $img = wp_get_attachment_image_src($id, 'my-custom-image-size');
        $img = wp_get_attachment_image_src($id, 'full');

        $output .= "<dl class='gallery-item gallery-columns-". $columns ."'>";
        $output .= "<a href=\"{$img[0]}\" rel='post-". $post->ID ."' class=\"fancybox\" title='". $attachment->post_excerpt ."'>\n";
        $output .= "<div class='gallery-item-thumb'><img src=\"{$img[0]}\" alt='". $attachment->post_excerpt ."' /></div>\n";
        $output .= "<div class='wp-caption-text'>";
        $output .= $attachment->post_excerpt;
        $output .= "</div>";
        $output .= "</a>\n";
        $output .= "</dl>";
    }

    $output .= "</div>\n";

    return $output;
}

/**
 *  Custom Post Type: Testimonials
 */
function testimonials() {

    $labels = array(
        'name'                => _x( 'Testimonials', 'Post Type General Name', 'ti' ),
        'singular_name'       => _x( 'Testimonial', 'Post Type Singular Name', 'ti' ),
        'menu_name'           => __( 'Testimonials', 'ti' ),
        'parent_item_colon'   => __( 'Parent Testimonial:', 'ti' ),
        'all_items'           => __( 'All Testimonials', 'ti' ),
        'view_item'           => __( 'View Testimonial', 'ti' ),
        'add_new_item'        => __( 'Add New Testimonial', 'ti' ),
        'add_new'             => __( 'Add New Testimonial', 'ti' ),
        'edit_item'           => __( 'Edit Testimonial', 'ti' ),
        'update_item'         => __( 'Update Testimonial', 'ti' ),
        'search_items'        => __( 'Search Testimonial', 'ti' ),
        'not_found'           => __( 'Not found Testimonial', 'ti' ),
        'not_found_in_trash'  => __( 'Not found Testimonial in Trash', 'ti' ),
    );
    $args = array(
        'label'               => __( 'testimonials', 'ti' ),
        'description'         => __( 'Description for testimonials.', 'ti' ),
        'labels'              => $labels,
        'supports'            => array( 'title', 'editor', 'custom-fields', ),
        'taxonomies'          => array(),
        'hierarchical'        => false,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'show_in_nav_menus'   => true,
        'show_in_admin_bar'   => true,
        'menu_position'       => 5,
        'menu_icon'           => 'dashicons-admin-comments',
        'can_export'          => true,
        'has_archive'         => true,
        'exclude_from_search' => false,
        'publicly_queryable'  => true,
        'capability_type'     => 'page',
    );
    register_post_type( 'testimonials', $args );

}

add_action( 'init', 'testimonials', 0 );

/**
 *  Custom Post Type: Lawyer
 */
function lawyers() {

    $labels = array(
        'name'                => _x( 'Lawyers', 'Post Type General Name', 'ti' ),
        'singular_name'       => _x( 'Lawyer', 'Post Type Singular Name', 'ti' ),
        'menu_name'           => __( 'Lawyers', 'ti' ),
        'parent_item_colon'   => __( 'Parent Lawyer:', 'ti' ),
        'all_items'           => __( 'All Lawyers', 'ti' ),
        'view_item'           => __( 'View Lawyer', 'ti' ),
        'add_new_item'        => __( 'Add New Lawyer', 'ti' ),
        'add_new'             => __( 'Add New Lawyer', 'ti' ),
        'edit_item'           => __( 'Edit Lawyer', 'ti' ),
        'update_item'         => __( 'Update Lawyer', 'ti' ),
        'search_items'        => __( 'Search Lawyer', 'ti' ),
        'not_found'           => __( 'Not found Lawyer', 'ti' ),
        'not_found_in_trash'  => __( 'Not found Lawyer in Trash', 'ti' ),
    );
    $args = array(
        'label'               => __( 'lawyers', 'ti' ),
        'description'         => __( 'Description for lawyers.', 'ti' ),
        'labels'              => $labels,
        'supports'            => array( 'title', 'editor', 'custom-fields', 'thumbnail' ),
        'taxonomies'          => array(),
        'hierarchical'        => false,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'show_in_nav_menus'   => true,
        'show_in_admin_bar'   => true,
        'menu_position'       => 5,
        'menu_icon'           => 'dashicons-admin-users',
        'can_export'          => true,
        'has_archive'         => true,
        'exclude_from_search' => false,
        'publicly_queryable'  => true,
        'capability_type'     => 'page',
    );
    register_post_type( 'lawyers', $args );

}

add_action( 'init', 'lawyers', 0 );

/**
 *  Taxonomy: Lawyers Categories
 */
function lawyers_categories() {
    $labels = array(
        'name'              => _x( 'Practice Areas', 'taxonomy general name', 'ti' ),
        'singular_name'     => _x( 'Practice Areas', 'taxonomy singular name', 'ti' ),
        'search_items'      => __( 'Search Practice Areas', 'ti' ),
        'all_items'         => __( 'All Practice Areas', 'ti' ),
        'parent_item'       => __( 'Parent Practice Area', 'ti' ),
        'parent_item_colon' => __( 'Parent Practice Area:', 'ti' ),
        'edit_item'         => __( 'Edit Practice Area', 'ti' ),
        'update_item'       => __( 'Update Practice Area', 'ti' ),
        'add_new_item'      => __( 'Add New Practice Area', 'ti' ),
        'new_item_name'     => __( 'New Practice Area', 'ti' ),
        'menu_name'         => __( 'Practice Areas', 'ti' ),
        'rewrite' => array('slug' => 'practiceareas', 'with_front' => true),
    );
    $args = array(
        'labels' => $labels,
        'hierarchical' => true,
        'public' => true,
        'show_ui'           => true,
        'exclude_from_search' => false,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => false
    );
    register_taxonomy( 'practiceareas', 'lawyers', $args );
}
add_action( 'init', 'lawyers_categories', 0 );

/**
 *  Testimonials Widget
 */
add_action( 'widgets_init', 'testimonials_widget' );

function testimonials_widget() {
    register_widget( 'Testimonials_Widget' );
}

class Testimonials_Widget extends WP_Widget {

    function Testimonials_Widget() {
        $widget_ops = array( 'classname' => 'example', 'description' => __('A widget that displays the latest testimonials.', 'ti') );

        $control_ops = array( 'width' => 300, 'height' => 350, 'id_base' => 'testimonials_widget' );

        $this->WP_Widget( 'testimonials_widget', __('Testimonials', 'ti'), $widget_ops, $control_ops );
    }

    function widget( $args, $instance ) {
        extract( $args );

        //Our variables from the widget settings.
        $title = apply_filters('widget_title', $instance['title'] );
        $testimonials_number_posts = $instance['testimonials_number_posts'];

        echo $before_widget;

        // Display the widget title
        if ( $title )
            echo $before_title . $title . $after_title; ?>

        <div class="widget-testimonials cf">
            <div class="list_carousel">
                <ul id="foo2">
                    <?php
                        $args = array (
                            'post_type'              => 'testimonials',
                            'posts_per_page'         => $testimonials_number_posts,
                            'ignore_sticky_posts'    => true,
                            'paged'                  => $paged,
                        );

                        $testimonials = new WP_Query( $args );

                        if ( $testimonials->have_posts() ) : while ( $testimonials->have_posts() ) : $testimonials->the_post();
                        global $post;

                        $testimonials_position = get_post_meta($post->ID, 'ti_testimonials_position', true);
                        $testimonials_company_name = get_post_meta($post->ID, 'ti_testimonials_company_name', true);
                        $testimonials_company_url = get_post_meta($post->ID, 'ti_testimonials_company_url', true);

                        if ( ( $testimonials_position && $testimonials_company_name ) == NULL ) {
						    $at = '';
					    } else {
						    $at = ' at ';
					    }
                        ?>
                    <li>
                        <div class="list_carousel_entry">
                            <?php echo testimonials_excerpt(50); ?>
                        </div><!--/div .list_carousel_entry-->
                        <div class="list_carousel_customer">
                            <span><?php the_title(); ?></span><br />
                            <?php echo $testimonials_position; ?> <?php echo $at; ?>
                            <?php
        					if ( $testimonials_company_url != false ) {
        						echo '<a href="'. $testimonials_company_url .'" title="'. $testimonials_company_name .'">'. $testimonials_company_name .'</a>';
        					} else {
        						echo $testimonials_company_name;
        					}
					        ?>
                        </div><!--/div .list_carousel_customer-->
                    </li><!--/li-->

                    <?php endwhile; else: ?>
                        <p><?php _e('Sorry, no posts matched your criteria.', 'ti'); ?></p>
                    <?php endif; ?>
                    <?php wp_reset_postdata(); ?>
                </ul><!--/ul-->
                <div class="clearfix"></div>
                <a id="prev2" class="prev" href="#"></a>
                <a id="next2" class="next" href="#"></a>
            </div><!--/div .list_carousel-->

        </div><!--/div .widget-testimonials-->

        <?php echo $after_widget;
    }

    //Update the widget

    function update( $new_instance, $old_instance ) {
        $instance = $old_instance;

        //Strip tags from title and name to remove HTML
        $instance['title'] = strip_tags( $new_instance['title'] );
        $instance['testimonials_number_posts'] = strip_tags( $new_instance['testimonials_number_posts'] );

        return $instance;
    }


    function form( $instance ) {

        //Set up some default widget settings.
        $defaults = array( 'title' => __('Testimonials', 'ti'), 'testimonials_number_posts' => __('2', 'ti') );
        $instance = wp_parse_args( (array) $instance, $defaults ); ?>

        <p>
            <label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e('Title:', 'ti'); ?></label>
            <input id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" style="width:100%;" />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id( 'testimonials_number_posts' ); ?>"><?php _e('Number of testimonials:', 'ti'); ?></label>
            <input id="<?php echo $this->get_field_id( 'testimonials_number_posts' ); ?>" name="<?php echo $this->get_field_name( 'testimonials_number_posts' ); ?>" value="<?php echo $instance['testimonials_number_posts']; ?>" style="width:100%;" />
        </p>

    <?php
    }
}

/**
 *  Practice Areas Widget
 */
add_action( 'widgets_init', 'practiceareas_widget' );


function practiceareas_widget() {
    register_widget( 'PracticeAreas_Widget' );
}

class PracticeAreas_Widget extends WP_Widget {

    function PracticeAreas_Widget() {
        $widget_ops = array( 'classname' => 'example', 'description' => __('A widget that displays the Practice Areas.', 'ti') );

        $control_ops = array( 'width' => 300, 'height' => 350, 'id_base' => 'practiceareas_widget' );

        $this->WP_Widget( 'practiceareas_widget', __('Practice Areas', 'ti'), $widget_ops, $control_ops );
    }

    function widget( $args, $instance ) {
        extract( $args );

        //Our variables from the widget settings.
        $title = apply_filters('widget_title', $instance['title'] );

        echo $before_widget;

        // Display the widget title
        if ( $title )
            echo $before_title . $title . $after_title; ?>

        <div class="widget-practice-area">
            <ul>
                <?php
                    $get_taxonomy = get_terms( 'practiceareas' );
                    foreach ( $get_taxonomy as $taxonomy_category ) {
                        $taxonomy_category = sanitize_term( $taxonomy_category, 'lawyers' );
                        $term_link = get_term_link( $taxonomy_category, 'lawyers' ); ?>
                        <li>
                            <a href="<?php echo esc_url( $term_link ); ?>" title="<?php echo $taxonomy_category->name; ?>" class="tooltip">
                                <?php echo $taxonomy_category->name; ?>
                                <span>
                                    <?php echo $taxonomy_category->description; ?>
                                </span><!--/span-->
                            </a><!--/a-->
                        </li><!--/li-->
                    <?php } ?>
                <?php ?>
            </ul><!--/ul-->
        </div><!--/div .widget-practice-area-->

        <?php echo $after_widget;
    }

    //Update the widget

    function update( $new_instance, $old_instance ) {
        $instance = $old_instance;

        //Strip tags from title and name to remove HTML
        $instance['title'] = strip_tags( $new_instance['title'] );

        return $instance;
    }


    function form( $instance ) {

        //Set up some default widget settings.
        $defaults = array( 'title' => __('Practice Areas', 'ti') );
        $instance = wp_parse_args( (array) $instance, $defaults ); ?>

        <p>
            <label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e('Title:', 'ti'); ?></label>
            <input id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" style="width:100%;" />
        </p>

    <?php
    }
}

/**
 *  Our Lawyers Widget
 */
add_action( 'widgets_init', 'ourlawyers_widget' );


function ourlawyers_widget() {
    register_widget( 'OurLawyers_Widget' );
}

class OurLawyers_Widget extends WP_Widget {

    function OurLawyers_Widget() {
        $widget_ops = array( 'classname' => 'example', 'description' => __('A widget that displays the latest lawyers.', 'ti') );

        $control_ops = array( 'width' => 300, 'height' => 350, 'id_base' => 'ourlawyers_widget' );

        $this->WP_Widget( 'ourlawyers_widget', __('Our Lawyers', 'ti'), $widget_ops, $control_ops );
    }

    function widget( $args, $instance ) {
        extract( $args );

        //Our variables from the widget settings.
        $title = apply_filters('widget_title', $instance['title'] );
        $ourlawyers_number_posts = $instance['ourlawyers_number_posts'];

        echo $before_widget;

        // Display the widget title
        if ( $title )
            echo $before_title . $title . $after_title; ?>

        <div class="widget-our-lawyers cf">

            <?php
                $args = array (
                    'post_type'              => 'lawyers',
                    'posts_per_page'         => $ourlawyers_number_posts,
                    'ignore_sticky_posts'    => true,
                    'paged'                  => $paged,
                );

                $lawyers = new WP_Query( $args );

                if ( $lawyers->have_posts() ) : while ( $lawyers->have_posts() ) : $lawyers->the_post();
                $featured_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'single-post-thumbnail' );
            ?>

            <?php
                if ( $featured_image != NULL ) { ?>
                    <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" class="lawyer" style="background-image: url('<?php echo $featured_image[0]; ?>'); ?>">
                        <div class="widget-our-lawyers-mask">
                        </div><!--/div .widget-our-lawyers-mask-->
                    </a><!--/a.lawyer-->
                <?php } else { ?>
                    <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" class="lawyer lawyer-no-image">
                        <div class="widget-our-lawyers-mask">
                        </div><!--/div .widget-our-lawyers-mask-->
                    </a><!--/a .lawyer .lawyer-no-image-->
                <?php }
            ?>

            <?php endwhile; else: ?>
                <p><?php _e('Sorry, no posts matched your criteria.', 'ti'); ?></p>
            <?php endif; ?>
            <?php wp_reset_postdata(); ?>

        </div><!--/div .widget-our-lawyers-->

        <?php echo $after_widget;
    }

    //Update the widget

    function update( $new_instance, $old_instance ) {
        $instance = $old_instance;

        //Strip tags from title and name to remove HTML
        $instance['title'] = strip_tags( $new_instance['title'] );
        $instance['ourlawyers_number_posts'] = strip_tags( $new_instance['ourlawyers_number_posts'] );

        return $instance;
    }


    function form( $instance ) {

        //Set up some default widget settings.
        $defaults = array( 'title' => __('Our Lawyers', 'ti'), 'ourlawyers_number_posts' => __('4', 'ti') );
        $instance = wp_parse_args( (array) $instance, $defaults ); ?>

        <p>
            <label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e('Title:', 'ti'); ?></label>
            <input id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" style="width:100%;" />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id( 'ourlawyers_number_posts' ); ?>"><?php _e('Number of posts:', 'ti'); ?></label>
            <input id="<?php echo $this->get_field_id( 'ourlawyers_number_posts' ); ?>" name="<?php echo $this->get_field_name( 'ourlawyers_number_posts' ); ?>" value="<?php echo $instance['ourlawyers_number_posts']; ?>" style="width:100%;" />
        </p>

    <?php
    }
}

/**
 *  About Us Widget
 */
add_action( 'widgets_init', 'aboutus_widget' );


function aboutus_widget() {
    register_widget( 'AboutUs_Widget' );
}

class AboutUs_Widget extends WP_Widget {

    function AboutUs_Widget() {
        $widget_ops = array( 'classname' => 'example', 'description' => __('A widget that displays the "about us".', 'ti') );

        $control_ops = array( 'width' => 300, 'height' => 350, 'id_base' => 'aboutus_widget_one' );

        $this->WP_Widget( 'aboutus_widget_one', __('About us', 'ti'), $widget_ops, $control_ops );
    }

    function widget( $args, $instance ) {
        extract( $args );

        //Our variables from the widget settings.
        $title = apply_filters('widget_title', $instance['title'] );
        $aboutus_content = $instance['aboutus_content'];

        echo $before_widget;

        // Display the widget title
        if ( $title )
            echo $before_title . $title . $after_title; ?>

        <div class="footer-box-entry">
            <?php echo $aboutus_content; ?>
        </div><!--/div .footer-box-entry-->

        <?php echo $after_widget;
    }

    //Update the widget

    function update( $new_instance, $old_instance ) {
        $instance = $old_instance;

        //Strip tags from title and name to remove HTML
        $instance['title'] = strip_tags( $new_instance['title'] );
        $instance['aboutus_content'] = strip_tags( $new_instance['aboutus_content'] );

        return $instance;
    }


    function form( $instance ) {

        //Set up some default widget settings.
        $defaults = array( 'title' => __('About us', 'ti'), 'aboutus_content' => __('Lorem Ipsum description.', 'ti') );
        $instance = wp_parse_args( (array) $instance, $defaults ); ?>

        <p>
            <label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e('Title:', 'ti'); ?></label>
            <input id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" style="width:100%;" />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id( 'aboutus_content' ); ?>"><?php _e('Content:', 'ti'); ?></label>
            <textarea id="<?php echo $this->get_field_id( 'aboutus_content' ); ?>" name="<?php echo $this->get_field_name( 'aboutus_content' ); ?>" value="<?php echo $instance['aboutus_content']; ?>" style="width:100%; height: 200px;">
                <?php echo $aboutus_content; ?>
            </textarea>
        </p>

    <?php
    }
}

/**
 *  Contact Us Widget
 */
add_action( 'widgets_init', 'contactus_widget' );


function contactus_widget() {
    register_widget( 'ContactUs_Widget' );
}

class ContactUs_Widget extends WP_Widget {

    function ContactUs_Widget() {
        $widget_ops = array( 'classname' => 'example', 'description' => __('A widget that displays the "contact us".', 'ti') );

        $control_ops = array( 'width' => 300, 'height' => 350, 'id_base' => 'contactus_widget_two' );

        $this->WP_Widget( 'contactus_widget_two', __('Contact Us', 'ti'), $widget_ops, $control_ops );
    }

    function widget( $args, $instance ) {
        extract( $args );

        //Our variables from the widget settings.
        $title = apply_filters('widget_title', $instance['title'] );
        $contactus_address_one = $instance['contactus_address_one'];
        $contactus_address_two = $instance['contactus_address_two'];
        $contactus_address_telephone = $instance['contactus_address_telephone'];
        $contactus_address_email = $instance['contactus_address_email'];
        $contactus_linkedin_link = $instance['contactus_linkedin_link'];
        $contactus_twitter_link = $instance['contactus_twitter_link'];
        $contactus_facebook_link = $instance['contactus_facebook_link'];
        $contactus_googleplus_link = $instance['contactus_googleplus_link'];
        $contactus_vime_link = $instance['contactus_vimeo_link'];

        echo $before_widget;

        // Display the widget title
        if ( $title )
            echo $before_title . $title . $after_title; ?>

        <div class="footer-box-entry">
            <span>
                <?php
                    if ( $contactus_address_one != false ) {
                        echo $contactus_address_one . '<br />';
                    }

                    if ( $contactus_address_two != false) {
                        echo $contactus_address_two;
                    }
                ?>
            </span><!--/p-->
            <span>
                <?php
                    if ( $contactus_address_telephone != false ) {
                        echo $contactus_address_telephone . '<br />';
                    }

                    if ( $contactus_address_email != false ) {
                        echo $contactus_address_email;
                    }
                ?>
            </span><!--/p-->
            <div class="footer-socials">
                <?php
                    if ( $contactus_linkedin_link != false ) {
                        echo '<a href="' . $contactus_linkedin_link . '" title="LinkedIn" class="social-button icon-linkedin" target="_blank"></a>';
                    }

                    if ( $contactus_twitter_link != fasle ) {
                        echo '<a href="' . $contactus_twitter_link . '" title="Twitter" class="social-button icon-twitter" target="_blank"></a>';
                    }

                    if ( $contactus_facebook_link != false ) {
                        echo '<a href="' . $contactus_facebook_link . '" title="Facebook" class="social-button icon-facebook" target="_blank"></a>';
                    }

                    if ( $contactus_googleplus_link != false ) {
                        echo '<a href="' . $contactus_googleplus_link . '" title="Google+" class="social-button icon-googleplus" target="_blank"></a>';
                    }

                    if ( $contactus_vime_link != false ) {
                        echo '<a href="' . $contactus_vime_link . '" title="Vimeo" class="social-button icon-vimeo" target="_blank"></a>';
                    }
                ?>
            </div><!--/div .footer-socials-->
        </div><!--/div .footer-box-entry-->

        <?php echo $after_widget;
    }

    //Update the widget

    function update( $new_instance, $old_instance ) {
        $instance = $old_instance;

        //Strip tags from title and name to remove HTML
        $instance['title'] = strip_tags( $new_instance['title'] );
        $instance['contactus_address_one'] = strip_tags( $new_instance['contactus_address_one'] );
        $instance['contactus_address_two'] = strip_tags( $new_instance['contactus_address_two'] );
        $instance['contactus_address_telephone'] = strip_tags( $new_instance['contactus_address_telephone'] );
        $instance['contactus_address_email'] = strip_tags( $new_instance['contactus_address_email'] );
        $instance['contactus_linkedin_link'] = strip_tags( $new_instance['contactus_linkedin_link'] );
        $instance['contactus_twitter_link'] = strip_tags( $new_instance['contactus_twitter_link'] );
        $instance['contactus_facebook_link'] = strip_tags( $new_instance['contactus_facebook_link'] );
        $instance['contactus_googleplus_link'] = strip_tags( $new_instance['contactus_googleplus_link'] );
        $instance['contactus_vimeo_link'] = strip_tags( $new_instance['contactus_vimeo_link'] );

        return $instance;
    }


    function form( $instance ) {

        //Set up some default widget settings.
        $defaults = array(
                'title' => __('Contact', 'ti'),
                'contactus_address_one'         => __('Romania, Bucuresti', 'ti'),
                'contactus_address_two'         => __( 'Str. Lorem Ipsum, nr. 2', 'ti' ),
                'contactus_address_telephone'   => __( 'Tel: (+4) 0746123456', 'ti' ),
                'contactus_address_email'       => __( 'E-mail: office@themeisle.com', 'ti' ),
                'contactus_linkedin_link'       => __( 'http://www.linkedin.com', 'ti' ),
                'contactus_twitter_link'        => __( 'http://www.twitter.com', 'ti' ),
                'contactus_facebook_link'       => __( 'http://www.facebook.com', 'ti' ),
                'contactus_googleplus_link'     => __( 'http://www.google.com', 'ti' ),
                'contactus_vimeo_link'          => __( 'http://www.vimeo.com', 'ti' )
            );
        $instance = wp_parse_args( (array) $instance, $defaults ); ?>

        <p>
            <label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e('Title:', 'ti'); ?></label>
            <input id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" style="width:100%;" />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id( 'contactus_address_one' ); ?>"><?php _e('Address 1:', 'ti'); ?></label>
            <input id="<?php echo $this->get_field_id( 'contactus_address_one' ); ?>" name="<?php echo $this->get_field_name( 'contactus_address_one' ); ?>" value="<?php echo $instance['contactus_address_one']; ?>" style="width:100%;" />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id( 'contactus_address_two' ); ?>"><?php _e('Address 2:', 'ti'); ?></label>
            <input id="<?php echo $this->get_field_id( 'contactus_address_two' ); ?>" name="<?php echo $this->get_field_name( 'contactus_address_two' ); ?>" value="<?php echo $instance['contactus_address_two']; ?>" style="width:100%;" />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id( 'contactus_address_telephone' ); ?>"><?php _e('Telephone:', 'ti'); ?></label>
            <input id="<?php echo $this->get_field_id( 'contactus_address_telephone' ); ?>" name="<?php echo $this->get_field_name( 'contactus_address_telephone' ); ?>" value="<?php echo $instance['contactus_address_telephone']; ?>" style="width:100%;" />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id( 'contactus_address_email' ); ?>"><?php _e('E-mail:', 'ti'); ?></label>
            <input id="<?php echo $this->get_field_id( 'contactus_address_email' ); ?>" name="<?php echo $this->get_field_name( 'contactus_address_email' ); ?>" value="<?php echo $instance['contactus_address_email']; ?>" style="width:100%;" />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id( 'contactus_linkedin_link' ); ?>"><?php _e('LinkedIn link:', 'ti'); ?></label>
            <input id="<?php echo $this->get_field_id( 'contactus_linkedin_link' ); ?>" name="<?php echo $this->get_field_name( 'contactus_linkedin_link' ); ?>" value="<?php echo $instance['contactus_linkedin_link']; ?>" style="width:100%;" />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id( 'contactus_twitter_link' ); ?>"><?php _e('Twitter link:', 'ti'); ?></label>
            <input id="<?php echo $this->get_field_id( 'contactus_twitter_link' ); ?>" name="<?php echo $this->get_field_name( 'contactus_twitter_link' ); ?>" value="<?php echo $instance['contactus_twitter_link']; ?>" style="width:100%;" />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id( 'contactus_facebook_link' ); ?>"><?php _e('Facebook link:', 'ti'); ?></label>
            <input id="<?php echo $this->get_field_id( 'contactus_facebook_link' ); ?>" name="<?php echo $this->get_field_name( 'contactus_facebook_link' ); ?>" value="<?php echo $instance['contactus_facebook_link']; ?>" style="width:100%;" />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id( 'contactus_googleplus_link' ); ?>"><?php _e('Google+ link:', 'ti'); ?></label>
            <input id="<?php echo $this->get_field_id( 'contactus_googleplus_link' ); ?>" name="<?php echo $this->get_field_name( 'contactus_googleplus_link' ); ?>" value="<?php echo $instance['contactus_googleplus_link']; ?>" style="width:100%;" />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id( 'contactus_vimeo_link' ); ?>"><?php _e('Vimeo link:', 'ti'); ?></label>
            <input id="<?php echo $this->get_field_id( 'contactus_vimeo_link' ); ?>" name="<?php echo $this->get_field_name( 'contactus_vimeo_link' ); ?>" value="<?php echo $instance['contactus_vimeo_link']; ?>" style="width:100%;" />
        </p>

    <?php
    }
}

/*************************************************/
/*********** Custom colors **********************/
/************************************************/

add_action('wp_print_scripts','lawyeria_php_style');

function lawyeria_php_style() {
	
	echo ' <style type="text/css">';
	
	/********* footer colors ********/
	echo ' #footer { background: '. get_theme_mod('lawyeria_footer_background') .'}';
	echo ' #footer .footer-box .footer-box-title {color: '.get_theme_mod('lawyeria_footer_heading_color').' }';
	echo ' #footer .footer-box ul li a, #footer .footer-box ul li {color: '.get_theme_mod('lawyeria_footer_text_color').' }';
	
	/******* menu colors ***********/
	echo ' header { background: '.get_theme_mod('lawyeria_menu_background').' }';
	echo ' nav li a { color: '.get_theme_mod('lawyeria_menu_text_color').' }';
	echo ' nav li a:hover { border-color: '.get_theme_mod('lawyeria_menu_border_color').' }';
	
	/******* header colors ***********/
	echo ' #subheader .subheader-color .full-header-content h3, .wide-nav h3 { color: '.get_theme_mod('lawyeria_header_headings_color').' }';
	echo ' .wide-nav { background: '.get_theme_mod('lawyeria_header_background').' }';
	echo ' #subheader .subheader-color .full-header-content p { color: '.get_theme_mod('lawyeria_header_text_color').' }';
	
	/******* fp boxes colors ***********/
	echo ' #features .features-box { background: '.get_theme_mod('lawyeria_fp_boxes_background').' }';
	echo ' #features .features-box h4 { color: '.get_theme_mod('lawyeria_fp_boxes_headings_color').' }';
	echo ' #features .features-box p { color: '.get_theme_mod('lawyeria_fp_boxes_text_color').' }';
	
	echo '</style>';
}

 require 'inc/cwp-update.php'; 

