

### 1.1.3 - 19/02/2015

 Changes: 


 * Fixed #3 Static Frontpage in customizer
 * Static Frontpage issue in customizer


### 1.1.1 - 17/10/2014

 Changes: 


 * Update style.css
