

### 1.1.2 - 17/10/2014

 Changes: 


 * Merge pull request #4 from Codeinwp/production

s
 * Update style.css
