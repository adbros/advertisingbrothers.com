# Theme options panel 1.0
=============

Theme options framework to include in wordpress themes.

# GitHub link : https://github.com/mariusalex20/theme-options

