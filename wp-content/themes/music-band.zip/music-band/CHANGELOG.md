

### 1.0.5 - 17/10/2014

 Changes: 


 * Create  CHANGELOG
 * Update CHANGELOG
 * Update style.css
 * Small fix - correct metabox for buy album and get on itunes links in sidebar widget latest album
 * Changed link in footer
 * Updated theme uri, documentation link and forum link
 * Localization and generating pot file
 * Optimized images, fixed wordpress 4.0 error in admin   improvements
 * Improvments   change color in theme options
 * Added more colors to change from theme options   other improvments
 * Updated .pot file and theme version
