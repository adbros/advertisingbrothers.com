= Music Band PRO =
Author: codeinwp
Tags: black, blue, brown, gray, green, orange, pink, purple, red, white, yellow, two-columns, custom-background, custom-header, right-sidebar, responsive-layout, custom-menu, editor-style, featured-images, sticky-post, theme-options, threaded-comments, translation-ready
Requires at least:	3.3.0
Tested up to:		4.0
Music Band PRO
== Description ==
Music Band PRO is a easily customizable WordPress Theme with an elegant design for your band.  
= License =
Unless otherwise specified, all the theme files, scripts and images are licensed under GNU General Public License v2.
The exceptions to this license are as follows: 
* SlidesJS is licensed under the Apache license. © 2013 Nathan Searles. All rights reserved.
* Lato font is licensed under the SIL Open Font License, 1.1 http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL
	
/*!
 * jQuery Tools v1.2.7 - The missing UI library for the Web
 * 
 * tabs/tabs.js
 * 
 * NO COPYRIGHTS OR LICENSES. DO WHAT YOU LIKE.
 * 
 * http://flowplayer.org/tools/
 * 
 */