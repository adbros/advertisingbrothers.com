 
<article id="post-<?php the_ID(); ?>" <?php post_class('post-box contact-page'); ?>>
					<div class="holder">
	<header class="entry-header  heading ">
		
								 
    
	                            	<h2 class="title-post"><span><?php the_title(); ?></span></h2>
	
	 
	</header> 
	<div class="entry-content content">
		 
	
								<div class="text-box-s">
											<div class="text-holder-s post-body">
											 
										
												 <?php 
												the_content();
												 
												?> 
                                                
											</div>
								</div> 
		 
	</div> 
	
                        <div class="clear"  ></div>
		</div>
		 
                        <div class="clear" ></div> 
	
</article>  
