= CreativeMag =

Author: themeisle

Tags: blue,white,yellow,light,one-column, two-columns, fixed-width , custom-menu, theme-options, featured-images, right-sidebar,custom-background,custom-menu,editor-style,full-width-template,sticky-post,translation-ready

Requires at least:	3.3.0

Tested up to:		3.8

CreativeMag

== Description ==

CreativeMag is a colorful WordPress Theme made for people who want to add some color to their blog.
Along with the elegant design the theme is easily customizable with numerous theme options, for example you will 
be able to easily edit logo, menus, social profiles links and banners. 
Designed by Alex Roman.
------------------

Dear friends,

thank you for downloading this file.

This freebie has been brought to you by icanbeCREATIVE.com.
You can freely use it for both your private and commercial projects, including software, online services, templates and themes.
Please link to the article in which this freebie was released if you would like to spread the word.

http://www.icanbecreative.com/creativemag-free-wordpress-theme.html

= License =

Unless otherwise specified, all the theme files, scripts and images are licensed under GNU General Public License v2.

The theme uses a custom version of  Feedburner Email widget - http://wordpress.org/plugins/feedburner-email-widget/ (http://www.gnu.org/licenses/old-licenses/gpl-2.0.html) 
