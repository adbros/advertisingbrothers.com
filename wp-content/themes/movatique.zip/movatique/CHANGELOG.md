

### 1.2.1 - 07/01/2015

 Changes: 


 * Fixed unresponsive logo and subheader


### 1.2.1 - 17/10/2014

 Changes: 


 * First version of movatique theme
 * Update style.css
 * multiple improvements
 * optimized images
 * removed enclosing php tag from function.php file
 * increased theme version
