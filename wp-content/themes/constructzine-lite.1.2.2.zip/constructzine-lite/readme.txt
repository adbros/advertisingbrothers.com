=== Constructzine Lite ===
Contributors:		codeinwp
Tags:				two-columns, right-sidebar, custom-menu, featured-images, sticky-post, translation-ready, responsive-layout, custom-menu, theme-options,threaded-comments,
featured-images, right-sidebar 
Requires at least:	3.3.0
Tested up to:		4.0

Constructzine Lite
== Description ==
Constructzine Lite is a free responsive, business, high-resolution theme featuring a pixel perfect design, large images, and easy to read typography that scales to fit all screens. Other features include optional social menu, sidebar and footer widgets and blog template.

= License =
Constructzine Lite WordPress theme, Copyright (C) 2013 themeisle.com
Constructzine Lite WordPress theme is licensed under the GPL3.

Unless otherwise specified, all the theme files, scripts and images are licensed under GNU General Public License.
The exceptions to this license are as follows: 

carouFredSel
License: Dual licensed under the MIT and GPL licenses. 
Copyright: (c) 2013 Fred Heusschen (caroufredsel.dev7studios.com)
 
Source Sans Pro Font
License: Distributed under the terms of SIL Open Font License (OFL) ( http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL )
Copyright: Paul D. Hunt
 
Yanone Kaffeesatz Font
License:  Distributed free under a Creative Commons License ( http://creativecommons.org/licenses/by/2.0/de/deed.en )
Copyright: Yanone
 
 