

### 1.5.2 - 16/02/2015

 Changes: 


 * Merge pull request #10 from Codeinwp/production

merge back-ward
 * Increased version


### 1.5.1 - 25/01/2015

 Changes: 


 * Prefix for add_image_size and fized mobile menu
 * Added forum link in description and theme link in footer


### 1.4.8 - 04/12/2014

 Changes: 


 * Fixed debug errors and first page looks at first install
 * Fixed wp review: translations, documentation, hard coded urls
 * removed sections from single page, added option for hiding latest posts, added comments on page


### 1.4.5 - 17/10/2014

 Changes: 


 * Small fix,on front page to be able to select a page or posts list
 * Updated theme uri, documentation link and forum link
 * removing ?> from end of file
 * wporg fixes

wporg fixes   optimized images
 * Fixed ticket 19906 review from wordpress.org
 * Fixed localization
 * Fixed include of wp-load
