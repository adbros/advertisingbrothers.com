# Theme options panel 1.0
=============

Theme options framework to include in wordpress themes.

# Documentation  
	https://docs.google.com/a/vertistudio.com/document/d/1fOa4EJG8jqcXjF32XyuuYOk1fvfLQgPZr-sXx3_VPYw

