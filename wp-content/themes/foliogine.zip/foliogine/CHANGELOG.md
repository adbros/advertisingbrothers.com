

### 1.0.6 - 05/01/2015

 Changes: 


 * Fixed child theme support bug


### 1.0.5 - 05/01/2015

 Changes: 


 * Added support for child themes


### 1.0.4 - 02/01/2015

 Changes: 


 * Update style.css


### 1.0.3 - 31/12/2014

 Changes: 


 * Merge pull request #11 from Codeinwp/production

back merge


### 1.0.3 - 20/11/2014

 Changes: 


 * Fixed wordress 4.0 theme option error


### 1.0.2 - 17/10/2014

 Changes: 


 * Create CHANGELOG
 * Update CHANGELOG
 * Update style.css
 * Update functions.php
 * Small fix - added metaboxes for hover link on portofolio page and single product page, in the related items section
 * Changed link in footer
 * Updated theme uri, documentation link and forum link
 * Fix internalization and location , plus started the rtl language support
 * Finished RTL support language
