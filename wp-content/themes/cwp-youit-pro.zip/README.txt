= CWP-YouIT =
Contributors:
codeinwp.com

Tags: gray, black, one-column, two-columns, right-sidebar, fixed-layout, custom-background, custom-header, custom-menu, editor-style, featured-images, flexible-header, threaded-comments, post-formats, sticky-post
Requires at least:	3.3.0

Tested up to:		3.8.1
CWP-YouIT

== Description ==
YouIT is a wordpress theme created for gaming or IT news websites which wants a modern look.
= License =

Unless otherwise specified, all the theme files, scripts and images are licensed under GNU General Public License v2.

The exceptions to this license are as follows:
* Open Sans font is licensed under Apache License, Version 2.0 http://www.apache.org/licenses/LICENSE-2.0.html , http://www.google.com/fonts/specimen/Open+Sans

* Nobile Font is licensed under SIL Open Font License, 1.1, Copyright Vernon Adams


CWP-YouIT supports a level of two for the menus.
