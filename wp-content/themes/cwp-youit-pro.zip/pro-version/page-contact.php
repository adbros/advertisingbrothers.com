<?php
/*
Template Name: Contact page
*/
?>
 
<?php
if(isset($_POST['submitted'])) {
        if(trim($_POST['contactName']) === '') {
               $nameError = __('Please enter your name.','cwp');
               $hasError = true;
        } else {
               $name = trim($_POST['contactName']);
        }
 
        if(trim($_POST['email']) === '')  {
               $emailError = __('Please enter your email address.','cwp');
               $hasError = true;
        } else if (!preg_match("/^[[:alnum:]][a-z0-9_.-]*@[a-z0-9.-]+\.[a-z]{2,4}$/i", trim($_POST['email']))) {
               $emailError = __('You entered an invalid email address.','cwp');
               $hasError = true;
        } else {
               $email = trim($_POST['email']);
        }
 
        if(trim($_POST['comments']) === '') {
               $commentError = __('Please enter a message.','cwp');
               $hasError = true;
        } else {
               if(function_exists('stripslashes')) {
                       $comments = stripslashes(trim($_POST['comments']));
               } else {
                       $comments = trim($_POST['comments']);
               }
        }
 
        if(!isset($hasError)) {
               $emailTo = get_option('tz_email');
               if (!isset($emailTo) || ($emailTo == '') ){
                       $emailTo = get_option('admin_email');
               }
               $subject = '[PHP Snippets] From '.$name;
               $body = "Name: $name \n\nEmail: $email \n\nComments: $comments";
               $headers = 'From: '.$name.' <'.$emailTo.'>' . "\r\n" . 'Reply-To: ' . $email;
 
               wp_mail($emailTo, $subject, $body, $headers);
               $emailSent = true;
        }
 
} ?>


<?php get_header(); ?>

  <div id="container">
    <div id="content">
 
      <header class="entry-header">
        <h1 class="entry-title"><?php the_title(); ?></h1>
      </header>

      <div class="half-page entry-content">

        <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
          <div <?php post_class() ?> id="post-<?php the_ID(); ?>">
              <div class="contact-form-page">
               <?php if(isset($emailSent) && $emailSent == true) { ?>
                 <div>
                    <p><?php _e('Thanks, your email was sent successfully.','cwp'); ?></p>
                  </div>
                <?php } else { ?>
                  <?php if(isset($hasError) || isset($captchaError)) { ?>
                  <p><?php _e('Sorry, an error occured.','cwp'); ?><p>
                <?php } ?>
                <form action="<?php the_permalink(); ?>" id="contactForm" method="post">
                <ul>
                  <li>
                    <label for="contactName"><?php _e('Name:',''); ?></label>
                      <input type="text" name="contactName" id="contactName" value="<?php if(isset($_POST['contactName'])) echo $_POST['contactName'];?>" />
                        <?php if($nameError != '') { ?>
                          <span><?=$nameError;?></span>
                        <?php } ?>
                        </li>
   
                        <li>
                          <label for="email"><?php _e('Email','cwp'); ?></label>
                          <input type="text" name="email" id="email" value="<?php if(isset($_POST['email']))  echo $_POST['email'];?>" />
                            <?php if($emailError != '') { ?>
                            <span><?=$emailError;?></span>
                          <?php } ?>
                        </li>
  
                        <li>
                          <label for="commentsText"><?php _e('Message:','cwp'); ?></label>
                          <textarea name="comments" id="commentsText" rows="20" cols="30"><?php if(isset($_POST['comments'])) { if(function_exists('stripslashes')) { echo stripslashes($_POST['comments']); } else { echo $_POST['comments']; } } ?></textarea>
                          <?php if($commentError != '') { ?>
                            <span><?=$commentError;?></span>
                          <?php } ?>
                        </li>
   
                        <li>
                          <input type="submit" value="<?php _e('Send email','cwp'); ?>"></input>
                        </li>
                      </ul>
                    <input type="hidden" name="submitted" id="submitted" value="true" />
                 </form>
              <?php } ?>
            </div><!-- .entry-content -->
         </div><!-- .post -->
      <?php endwhile; endif; ?>

    </div>
    <div class="half-page entry-content">
      <?php the_content(); ?>
    </div>
    <div class="clear"></div>
  </div><!-- #content -->
</div><!-- #container -->
 

<?php get_footer(); ?>