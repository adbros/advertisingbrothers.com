
jQuery( document ).ready(function(){

  jQuery('#twitter').sharrre({
    share: {
      twitter: true
    },
    enableHover: false,
    enableTracking: false,
    urlCurl: '',
    buttons: { twitter: {via: '_JulienH'}},
    click: function(api, options){
      api.simulateClick();
      api.openPopup('twitter');
    }
  });
  jQuery('#facebook').sharrre({
    share: {
      facebook: true
    },
    enableHover: false,
    enableTracking: false,
    click: function(api, options){
      api.simulateClick();
      api.openPopup('facebook');
    }
  });
  jQuery('#googleplus').sharrre({
    share: {
      googlePlus: true
    },
    enableHover: false,
    enableTracking: false,
    urlCurl: '',
    click: function(api, options){
      api.simulateClick();
      api.openPopup('googlePlus');
    }
  });

});