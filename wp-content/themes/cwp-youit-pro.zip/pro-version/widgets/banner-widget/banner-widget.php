<?php
/*
Plugin Name: Ads widget
Description: add ads images
Version: 1
*/


class CWP_Add_banner extends WP_Widget
{

  function CWP_Add_banner()
  {
    $widget_ops = array('classname' => 'cwp_ddd_banner', 'description' => 'CWP - Add banner' );
    $this->WP_Widget('CWP_Add_banner', 'CWP - Add banner', $widget_ops);
  }


  function form($instance)
  {

    $instance = wp_parse_args( (array) $instance, array( 
	'image_uri' => '',
	'destination_uri' => '',
	'target' => '_blank',
	'title' => ''
	) );
	
	$image_uri = $instance['image_uri'];
	$destination_uri = $instance['destination_uri'];
	$target = $instance['target'];
	$title = $instance['title'];

  
    // removed the for loop, you can create new instances of the widget instead
    ?>
     <p>
        <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Widget title:', 'cw-magazine'); ?></label>
        <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
    </p>

    <p>
      <label for="<?php echo $this->get_field_id('image_uri'); ?>"><?php _e('Image', 'cw-magazine'); ?></label><br />
      <input type="text" class="img" name="<?php echo $this->get_field_name('image_uri'); ?>" id="<?php echo $this->get_field_id('image_uri'); ?>" value="<?php echo $image_uri; ?>" />
      <input type="button" class="select-img" value="Select Image" />
    </p>
    
     <p>
        <label for="<?php echo $this->get_field_id('destination_uri'); ?>"><?php _e('Destination URL:', 'cw-magazine'); ?></label>
        <input class="widefat" id="<?php echo $this->get_field_id('destination_uri'); ?>" name="<?php echo $this->get_field_name('destination_uri'); ?>" type="text" value="<?php echo $destination_uri; ?>" />
    </p> 
    <p>
        <label for="<?php echo $this->get_field_id('target'); ?>"><?php _e('Target:', 'cw-magazine'); ?></label>
        <select name="<?php echo $this->get_field_name('target'); ?>" id="<?php echo $this->get_field_id('target'); ?>" class="widefat" style="width: 100px;">
            <?php
            $options = array('_blank', '_self');
            foreach ($options as $option) {
                echo '<option value="' . $option . '" id="' . $option . '"', $target == $option ? ' selected="selected"' : '', '>', $option, '</option>';
            }
            ?>
        </select>
    </p>
    

<?php

  }

 

  function update($new_instance, $old_instance)
  {
	  
    $instance = $old_instance;
	
    $instance['image_uri'] = $new_instance['image_uri'];
	$instance['destination_uri'] = $new_instance['destination_uri'];
	$instance['target'] = $new_instance['target'];
	$instance['title'] = $new_instance['title'];
	
    return $instance;

  }

 

  function widget($args, $instance)
{
  	extract($args, EXTR_SKIP);

	
	$image_url = empty($instance['image_uri']) ? ' ' : apply_filters('widget_image_url', $instance['image_uri']);
	$destination_uri = empty($instance['destination_uri']) ? ' ' : apply_filters('widget_destination_uri', $instance['destination_uri']);
	$target = empty($instance['target']) ? ' ' : apply_filters('widget_target', $instance['target']);
	$title = empty($instance['title']) ? ' ' : apply_filters('widget_title', $instance['title']);


	echo '<aside class="widget widget_add_banner">';
	
    // basic output just for this example
	if( trim($title) ){
    	echo '<h1 class="widget-title"><span>'.$title.'</span></h1>';
		}
	echo '<div class="banner-wrap">
	  			<a href="'.esc_url($instance['destination_uri']).'" title="'.esc_html($instance['title']).'" style="width: 100%" class="banner-link" target="'.$target.'">
					<img src="'.esc_url($instance['image_uri']).'" alt="'.esc_html($instance['title']).'" style="width: 100%">
				</a>
			</div>';

	echo '</aside>';
	
  }


}

add_action( 'widgets_init', create_function('', 'return register_widget("CWP_Add_banner");') );


// init the widget
add_action( 'widgets_init', create_function('', 'return register_widget("CWP_Add_banner");') );

// queue up the necessary js
function cwp_enqueue()
{
  wp_enqueue_style('thickbox');
  wp_enqueue_script('media-upload');
  wp_enqueue_script('thickbox');
  // moved the js to an external file, you may want to change the path
  wp_enqueue_script('cwp', get_template_directory_uri().'/pro-version/widgets/banner-widget/script.js', null, null, true);
}
add_action('admin_enqueue_scripts', 'cwp_enqueue');


?>
