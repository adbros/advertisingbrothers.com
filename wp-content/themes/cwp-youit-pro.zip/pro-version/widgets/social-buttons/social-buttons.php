<?php
/*
Plugin Name: Ads widget
Description: add ads images
Version: 1
*/


class CWP_Social_Icons extends WP_Widget
{

  function CWP_Social_Icons()
  {
    $widget_ops = array(
    	'classname' 	=> 'CWP_social_icons', 
    	'description' 	=> 'CWP - Social Icons' 
    );
    $this->WP_Widget('CWP_Social_Icons', 'CWP - Social Icons', $widget_ops);
  }


  function form($instance)
  {

    $instance = wp_parse_args( (array) $instance, array( 
	'facebook'	=> '',
	'twitter' 	=> '',
	'google' 	=> '',
	'linkedin' 	=> '',
	'youtube' 	=> '',
	'rss' 		=> '',
	'email' 	=> '',
	) );
	
	$facebook 	= $instance['facebook'];
	$twitter 	= $instance['twitter'];
	$google 	= $instance['google'];
	$linkedin 	= $instance['linkedin'];
	$youtube 	= $instance['youtube'];
	$rss 		= $instance['rss'];
	$email 		= $instance['email'];

    ?>
     <p>
        <label for="<?php echo $this->get_field_id('facebook'); ?>"><?php _e('Facebook:', 'cwp'); ?></label>
        <input class="widefat" id="<?php echo $this->get_field_id('facebook'); ?>" name="<?php echo $this->get_field_name('facebook'); ?>" type="text" value="<?php echo $facebook; ?>" />
    </p>

     <p>
        <label for="<?php echo $this->get_field_id('twitter'); ?>"><?php _e('Twitter:', 'cwp'); ?></label>
        <input class="widefat" id="<?php echo $this->get_field_id('twitter'); ?>" name="<?php echo $this->get_field_name('twitter'); ?>" type="text" value="<?php echo $twitter; ?>" />
    </p>

     <p>
        <label for="<?php echo $this->get_field_id('google'); ?>"><?php _e('Google:', 'cwp'); ?></label>
        <input class="widefat" id="<?php echo $this->get_field_id('google'); ?>" name="<?php echo $this->get_field_name('google'); ?>" type="text" value="<?php echo $google; ?>" />
    </p>

     <p>
        <label for="<?php echo $this->get_field_id('linkedin'); ?>"><?php _e('Linkedin:', 'cwp'); ?></label>
        <input class="widefat" id="<?php echo $this->get_field_id('linkedin'); ?>" name="<?php echo $this->get_field_name('linkedin'); ?>" type="text" value="<?php echo $linkedin; ?>" />
    </p>


     <p>
        <label for="<?php echo $this->get_field_id('youtube'); ?>"><?php _e('Youtube:', 'cwp'); ?></label>
        <input class="widefat" id="<?php echo $this->get_field_id('youtube'); ?>" name="<?php echo $this->get_field_name('youtube'); ?>" type="text" value="<?php echo $youtube; ?>" />
    </p>    

     <p>
        <label for="<?php echo $this->get_field_id('rss'); ?>"><?php _e('RSS:', 'cwp'); ?></label>
        <input class="widefat" id="<?php echo $this->get_field_id('rss'); ?>" name="<?php echo $this->get_field_name('rss'); ?>" type="text" value="<?php echo $rss; ?>" />
    </p>

     <p>
        <label for="<?php echo $this->get_field_id('email'); ?>"><?php _e('Email:', 'cwp'); ?></label>
        <input class="widefat" id="<?php echo $this->get_field_id('email'); ?>" name="<?php echo $this->get_field_name('email'); ?>" type="text" value="<?php echo $email; ?>" />
    </p>

<?php

  }

 

  function update($new_instance, $old_instance)
  {
	  
    $instance = $old_instance;
	
    $instance['facebook'] 	= $new_instance['facebook'];
    $instance['twitter']	= $new_instance['twitter'];
    $instance['google'] 	= $new_instance['google'];
    $instance['linkedin'] 	= $new_instance['linkedin'];
    $instance['youtube'] 	= $new_instance['youtube'];
    $instance['rss'] 		= $new_instance['rss'];
    $instance['email'] 		= $new_instance['email'];
	
    return $instance;

  }

 

  function widget($args, $instance)
{
  	extract($args, EXTR_SKIP);

	
	$facebook 	= empty($instance['facebook']) ? ' ' : apply_filters('widget_facebook', $instance['facebook']);
	$Twitter 	= empty($instance['twitter']) ? ' ' : apply_filters('widget_twitter', $instance['twitter']);
	$google 	= empty($instance['google']) ? ' ' : apply_filters('widget_google', $instance['google']);
	$linkedin 	= empty($instance['linkedin']) ? ' ' : apply_filters('widget_linkedin', $instance['linkedin']);
	$youtube 	= empty($instance['youtube']) ? ' ' : apply_filters('widget_youtube', $instance['youtube']);
	$rss 		= empty($instance['rss']) ? ' ' : apply_filters('widget_rss', $instance['rss']);
	$email 		= empty($instance['email']) ? ' ' : apply_filters('widget_email', $instance['email']);

	
    echo '<ul class="cwp-social-icons">';

		if( isset($facebook) ){
			echo '<li class="icon-fb">';
			echo '<a href="'.esc_url($instance['facebook']).'" title="Facebook"><span class="symbol">&#xe427;</span></p></a>';
			echo '</li>';
		}
		if( isset($twitter) ){
			echo '<li class="icon-tw">';
			echo '<a href="'.esc_url($instance['twitter']).'" title="Twitter"><span class="symbol">&#xe486;</span></p></a>';
			echo '</li>';
		}
		if( isset($google) ){
			echo '<li class="icon-gp">';
			echo '<a href="'.esc_url($instance['google']).'" title="Google plus"><span class="symbol">&#xe439;</span></p></a>';
			echo '</li>';
		}
		if( isset($linkedin) ){
			echo '<li class="icon-in">';
			echo '<a href="'.esc_url($instance['linkedin']).'" title="Linkedin"><span class="symbol">&#xe452;</span></p></a>';
			echo '</li>';
		}
		if( isset($youtube) ){
			echo '<li class="icon-yt">';
			echo '<a href="'.esc_url($instance['youtube']).'" title="Youtube"><span class="symbol">&#xe499;</span></p></a>';
			echo '</li>';
		}
		if( isset($rss) ){
			echo '<li class="icon-rss">';
			echo '<a href="'.esc_url($instance['rss']).'" title="RSS"><span class="symbol">&#xe471;</span></p></a>';
			echo '</li>';
		}
		if( isset($email) ){
			echo '<li class="icon-em">';
			echo '<a href="'.esc_url($instance['email']).'" title="Email"><span class="symbol">&#xe424;</span></p></a>';
			echo '</li>';
		}

	echo '</ul>';	
  }


}

add_action( 'widgets_init', create_function('', 'return register_widget("CWP_Social_Icons");') );


/**
 * Proper way to enqueue scripts and styles
 */
function theme_name_scripts() {

	wp_enqueue_style( 'cwp-style-ss', get_template_directory_uri() . '/pro-version/widgets/social-buttons/stylesheets.css', array(), '20141010' );

}

add_action( 'wp_enqueue_scripts', 'theme_name_scripts' );


?>
