<?php

	
/** 
 * Set the image size by cropping the image 
 */
add_image_size( 'related_img', 100, 100, true );


function cwp_customize_register_pro( $wp_customize ) {

    $wp_customize->add_setting('sidebar_position', array(
    	'default' => 'sidebar-right',
    ));
    $wp_customize->add_control('sidebar_position', array(
     	'label'      => __('Sidebar position', 'cwp'),
      	'section'    => 'layout',
      	'settings'   => 'sidebar_position',
      	'type'       => 'radio',
      	'choices'    => array(
        	'sidebar-right'     => __('Sidebar right','cwp'),
        	'sidebar-left'      => __('Sidebar left','cwp'),
        	'width-full'        => __('Full width','cwp'),
      	),
    ));
    $wp_customize->add_section('layout' , array(
        'title' 	=> __('Layout','cwp'),
        'priority'  => 30
    ));

}
add_action( 'customize_register', 'cwp_customize_register_pro' );


function cwp_scripts_styles_pro() {

	wp_enqueue_script( 'cwp-functions-pro', get_template_directory_uri() . '/pro-version/js/functions.js', array('jquery'), '1.0', true );

	wp_enqueue_script( 'cwp-sharrre', get_template_directory_uri() . '/pro-version/js/jquery.sharrre.min.js', array('jquery'), '1.0', true );

	wp_enqueue_style( 'cwp-style-pro', get_template_directory_uri() . '/pro-version/css/styles-pro.css', array( 'cwp-style' ), '20141010' );	

}
add_action( 'wp_enqueue_scripts', 'cwp_scripts_styles_pro' );


function get_social_icons(){

?>

	<div id="singleSocial">
	  <div id="twitter" data-url="<?php get_permalink(); ?>" data-text="<?php get_permalink(); ?>" data-title="Tweet"></div>
	  <div id="facebook" data-url="<?php get_permalink(); ?>" data-text="<?php get_permalink(); ?>" data-title="Like"></div>
	  <div id="googleplus" data-url="<?php get_permalink(); ?>" data-text="<?php get_permalink(); ?>" data-title="+1"></div>
	</div>

<?php
}

/**
 * Related post (single.php)
 */
function cwp_related_post(){

	$orig_post = $post;
	global $post;
	$tags = wp_get_post_tags($post->ID);

	if ($tags) {
		$tag_ids = array();
		foreach($tags as $individual_tag) $tag_ids[] = $individual_tag->term_id;
		$args=array(
			'tag__in' 			=> $tag_ids,
			'post__not_in' 		=> array($post->ID),
			'posts_per_page'	=> 6, // Number of related posts that will be shown.
			'caller_get_posts'	=> 1
		);
		$my_query = new wp_query( $args );
		if( $my_query->have_posts() ) {

			echo '<div id="relatedposts"><h2>'.__( "Related Posts", "cwp"). '</h2><ul>';

			while( $my_query->have_posts() ) {
				$my_query->the_post(); ?>
				<li>

					<a href="<?php the_permalink()?>" rel="bookmark" title="<?php the_title(); ?>" class="relatedthumb">
						<?php 
								if ( has_post_thumbnail() ) :
									the_post_thumbnail( 'related_img' );
								else:
									echo '<img src="'. get_template_directory_uri() .'/pro-version/images/no-image-related.png" class="no-thumbnail-related">';
								endif; 
						?>
					</a>
					
					<p class="relatedcontent">
						<a href="<?php the_permalink()?>" rel="bookmark" title="<?php the_title(); ?>" ><?php the_title(); ?></a>
					</p>

				</li>

			<?php }
			echo '</ul></div>';

		}
	}
	$post = $orig_post;
	wp_reset_query();

}

require_once dirname( __FILE__ ) . '/widgets/banner-widget/banner-widget.php';

require_once dirname( __FILE__ ) . '/widgets/social-buttons/social-buttons.php';

