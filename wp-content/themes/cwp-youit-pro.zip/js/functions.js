
jQuery( document ).ready( function(){

	sameHeightSmallPost();
	sameHeightBoxSearchPage();
	sameHeightBoxArchivePage();

});


jQuery( window ).resize(function() {

	sameHeightSmallPost();
	sameHeightBoxSearchPage();
	sameHeightBoxArchivePage();

});

/* Sets the same height */
function sameHeightSmallPost(){

	jQuery( '.small-post-area' ).height( 'auto' );

	/* small box area fix height */
	var maxHeight = 0;
	jQuery( '.small-post-area' ).each( function(){
		
		if ( jQuery( this ).height() > maxHeight ){
			maxHeight = jQuery( this ).height() + parseInt( jQuery( this ).css('padding-top') ) + parseInt( jQuery( this ).css('padding-bottom') ) + 13;
		}
		jQuery( '.small-post-area' ).height( maxHeight );
		
	});

}

/* Sets the same height for all boxes in search page */
function sameHeightBoxSearchPage(){

	if ( jQuery( '.search' ).length > 0 ){

		jQuery( '.search .two-columns article' ).height( 'auto' );

		var maxHeight = 0;
		jQuery( '.search .two-columns article' ).each( function(){
			
			if ( jQuery( this ).height() > maxHeight ){
				maxHeight = jQuery( this ).height() + parseInt( jQuery( this ).css('padding-top') ) + parseInt( jQuery( this ).css('padding-bottom') ) + 13;
				console.log( maxHeight );
			}
			jQuery( '.search .two-columns article' ).height( maxHeight );
			
		});

	}
}

/* Sets the same height for all boxes in archive page */
function sameHeightBoxArchivePage(){

	if ( jQuery( '.archive' ).length > 0 ){

		jQuery( '.archive .two-columns article' ).height( 'auto' );

		var maxHeight = 0;
		jQuery( '.archive .two-columns article' ).each( function(){
			
			if ( jQuery( this ).height() > maxHeight ){
				maxHeight = jQuery( this ).height() + parseInt( jQuery( this ).css('padding-top') ) + parseInt( jQuery( this ).css('padding-bottom') ) + 13;
				console.log( maxHeight );
			}
			jQuery( '.archive .two-columns article' ).height( maxHeight );
			
		});

	}
}