<?php
/**
 * The Header for our theme.
 *
 * Displays all of the <head> section and everything up till <div id="content">
 *
 * @package zerif
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php wp_title( '|', true, 'right' ); ?></title>
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
<?php	$zerif_google_anaytics = get_theme_mod('zerif_google_anaytics');	if( !empty($zerif_google_anaytics) ):		echo $zerif_google_anaytics;	endif;	wp_head(); ?>
</head>

<?php if(isset($_POST['scrollPosition'])): ?>
	<body <?php body_class(); ?> onLoad="window.scrollTo(0,<?php echo $_POST['scrollPosition']; ?>)">
<?php else: ?>
	<body <?php body_class(); ?> >
<?php endif; ?><?php	$zerif_slides_array = array();		$zerif_bgslider_1 = get_theme_mod('zerif_bgslider_1');	if( !empty($zerif_bgslider_1) ):		array_push($zerif_slides_array, $zerif_bgslider_1);	endif;		$zerif_bgslider_2 = get_theme_mod('zerif_bgslider_2');	if( !empty($zerif_bgslider_2) ):		array_push($zerif_slides_array, $zerif_bgslider_2);	endif;		$zerif_bgslider_3 = get_theme_mod('zerif_bgslider_3');	if( !empty($zerif_bgslider_3) ):		array_push($zerif_slides_array, $zerif_bgslider_3);	endif;		$count_slides = 0;		if( !empty($zerif_slides_array) && is_home() ):			echo '<div class="zerif_full_site_wrap">';								echo '<div class="carousel slide zerif-carousel-bg-slider" data-ride="carousel">';				echo '<div class="carousel-inner" role="listbox">';									foreach( $zerif_slides_array as $zerif_slide ):						if($count_slides == 0):							$active_slide = 'active';						else:							$active_slide = '';						endif;						echo '<div class="item '.$active_slide.'" style="background:url('.$zerif_slide.');"></div>';						$count_slides++;					endforeach;									echo '</div>';			echo '</div>';						echo '<div class="zerif_full_site">';					endif;?>	
		<!-- =========================
		   PRE LOADER       
		============================== -->		<?php					 global $wp_customize;		 if(is_front_page() && !isset( $wp_customize )): 		 			$zerif_disable_preloader = get_theme_mod('zerif_disable_preloader');						if( isset($zerif_disable_preloader) && ($zerif_disable_preloader != 1)):				 
				echo '<div class="preloader">';
					echo '<div class="status">&nbsp;</div>';
				echo '</div>';							endif;			endif; ?>

		<header id="home" class="header">
			<div id="main-nav" class="navbar navbar-inverse bs-docs-nav" role="banner">
				<div class="container">
					<div class="navbar-header responsive-logo">
						<button class="navbar-toggle collapsed" type="button" data-toggle="collapse" data-target=".bs-navbar-collapse">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						</button>
						
						<?php
							$zerif_logo = get_theme_mod('zerif_logo');
							if(isset($zerif_logo) && $zerif_logo != ""):
								echo '<a href="'.esc_url( home_url( '/' ) ).'" class="navbar-brand">';
									echo '<img src="'.$zerif_logo.'" alt="'.get_bloginfo('title').'">';
								echo '</a>';
							else:
								echo '<div class="header_title">';	
									echo '<h1 class="site-title"><a href="'.esc_url( home_url( '/' ) ).'" title="'.esc_attr( get_bloginfo( 'name', 'display' ) ).'" rel="home">'.get_bloginfo( 'name' ).'</a></h1>';
									echo '<h2 class="site-description"><a href="'.esc_url( home_url( '/' ) ).'" title="'.esc_attr( get_bloginfo( 'name', 'display' ) ).'" rel="home">'.get_bloginfo( 'description' ).'</a></h2>';
								echo '</div>';
							endif;
						?>
						
					</div>
					<nav class="navbar-collapse bs-navbar-collapse collapse" role="navigation" id="site-navigation">
						<?php wp_nav_menu( array('theme_location' => 'primary', 'container' => false, 'menu_class' => 'nav navbar-nav navbar-right responsive-nav main-nav-list' ,'fallback_cb'     => 'zerif_wp_page_menu')); ?>
					</nav>
				</div>
			</div>
			<!-- / END TOP BAR -->