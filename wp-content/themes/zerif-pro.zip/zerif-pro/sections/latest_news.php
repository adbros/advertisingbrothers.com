		<section class="latest-news" id="latestnews">
			<div class="container">

				<!-- SECTION HEADER -->
				<div class="section-header">
				<?php

					$zerif_latestnews_title = get_theme_mod('zerif_latestnews_title','LATEST NEWS');

					if( !empty($zerif_latestnews_title) ):
						echo '<h2 class="dark-text">' . $zerif_latestnews_title . '</h2>';
					endif;


					$zerif_latestnews_subtitle = get_theme_mod('zerif_latestnews_subtitle','Add a subtitle in Customizer, "Latest news section"');

					if( !empty($zerif_latestnews_subtitle) ):

						echo '<h6 class="dark-text">'.$zerif_latestnews_subtitle.'</h6>';

					endif;
				?>
				</div>


				<div class="clear"></div>
				<div id="carousel-homepage-latestnews" class="carousel slide" data-ride="carousel">
					<!-- Indicators -->
				
					<!-- Wrapper for slides -->
					<div class="carousel-inner" role="listbox">


					<?php 
					
						$args = array( 'post_type' => 'post', 'posts_per_page' => '12', 'order' => 'DESC');
						$loop = new WP_Query( $args );

						$newSlideActive = '<div class="item active">';
						$newSlide 		= '<div class="item">';
						$newSlideClose 	= '<div class="clear"></div></div>';
						$i_latest_posts= 0;
						while ( $loop->have_posts() ) : $loop->the_post();

						$i_latest_posts++;

						if ( !wp_is_mobile() ){


								if($i_latest_posts == 1){
									echo $newSlideActive;
								}
								else if($i_latest_posts % 4 == 1){
									echo $newSlide;
								}
							?>
								<div class="col-sm-3 latestnews-box">

									<div class="latestnews-img">
										<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">

											<?php if ( has_post_thumbnail() ) : ?>
												<?php the_post_thumbnail(); ?>
											<?php else: ?>
												<img src="<?php echo get_template_directory_uri(); ?>/images/blank-latestposts.png">
											<?php endif; ?>

										</a>
									</div>

									<div class="latesnews-content">

										<h5 class="latestnews-title"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h5>

										<?php the_excerpt(); ?>

									</div>

								</div><!-- .latestnews-box"> -->

							<?php
								/* after every four posts it must closing the '.item' */
								if($i_latest_posts % 4 == 0){
									echo $newSlideClose;
								}

						} else {

							if( $i_latest_posts == 1 ) $active = 'active'; else $active = ''; 

						?>
	
							<div class="item <?php echo $active; ?>">
								<div class="col-md-3 latestnews-box">
									<div class="latestnews-img">
										<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
											<?php the_post_thumbnail(); ?>
										</a>
									</div>
									<div class="latesnews-content">
										<h5 class="latestnews-title"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h5>
										<?php the_excerpt(); ?>
									</div>
								</div>
							</div>

						<?php
						}
						
					endwhile;
					
					

					if ( !wp_is_mobile() ) {

						// if there are less than 10 posts
						if($i_latest_posts % 4!=0){
							echo $newSlideClose;
						}

					}

					 wp_reset_postdata(); 
					?>	

				    </div>

					<!-- Controls -->
					<a class="left carousel-control" href="#carousel-homepage-latestnews" role="button" data-slide="prev">
						<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
						<span class="sr-only"><?php _e('Previous','zerif'); ?></span>
					</a>
					<a class="right carousel-control" href="#carousel-homepage-latestnews" role="button" data-slide="next">
						<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
						<span class="sr-only"><?php _e('Next','zerif'); ?></span>
					</a>
				</div>

			</div>
		</section>