= CWP Blog =

Author: Codeinwp
Tags: blue, gray, light, white, two-columns, right-sidebar, flexible-width, custom-menu, editor-style, featured-images, theme-options, threaded-comments, translation-ready
Requires at least:	3.3.0
Tested up to:		3.8

CWP Blog
== Description ==
CWP Blog is a easily customizable WordPress Theme with an elegant design. 
 
= License =
Unless otherwise specified, all the theme files, scripts and images are licensed under GNU General Public Licemse.
The exceptions to this license are as follows: 
* Open Sans font is licensed under Apache License, Version 2.0 http://www.apache.org/licenses/LICENSE-2.0.html
* jquery cycle - Dual licensed under the MIT and GPL licenses.	
* Font Awesome
	*  License
	*  ------------------------------------------------------------------------------
	*  - The Font Awesome font is licensed under SIL OFL 1.1 -
	*    http://scripts.sil.org/OFL
	*  - Font Awesome CSS, LESS, and SASS files are licensed under MIT License -
	*    http://opensource.org/licenses/mit-license.html
	*  - Font Awesome documentation licensed under CC BY 3.0 -
	*    http://creativecommons.org/licenses/by/3.0/
	*  - Attribution is no longer required in Font Awesome 3.0, but much appreciated:
	*    "Font Awesome by Dave Gandy - http://fontawesome.io"
	*
	*  Author - Dave Gandy
	*  ------------------------------------------------------------------------------
	*  Email: dave@fontawesome.io
	*  Twitter: http://twitter.com/davegandy
	*  Work: Lead Product Designer @ Kyruus - http://kyruus.com
