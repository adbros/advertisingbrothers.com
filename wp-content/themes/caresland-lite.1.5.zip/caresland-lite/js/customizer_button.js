jQuery( document ).ready(function() {
    jQuery('#customize-footer-actions').append('<a style="position: fixed;bottom: 7px;left: 127px;" href="http://themeisle.com/themes/caresland-pro/" class="button" target="_blank">View PRO version</a>');
});