= Caresland Lite =
Contributors: themeisle
Tags: orange, yellow, green, gray, light, one-column, right-sidebar, responsive-layout, custom-background, custom-header, editor-style, featured-images, sticky-post, threaded-comments, translation-ready
Requires at least:	3.3.0
Tested up to:		3.9

Caresland Lite

== Description ==
Caresland Lite is a a easily customizable WordPress Theme designed for kindergartens or other websites about activities with children.
= License =

Unless otherwise specified, all the theme files, scripts and images are licensed under GNU General Public License v3.

The exceptions to this license are as follows: 

* Scada font is licensed under SIL Open Font License (OFL)
	http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL

* Bootstrap is licensed under
	The MIT License (MIT)
	
* tinynav is licensed under the MIT license.
	Copyright (c) 2011-2014 Viljami Salminen, http://viljamis.com/