<?php
if ( get_theme_mod( 'ti_header_contactform7_shortcode' ) ) {
	$subheader_id = 'subheader';
} else {
	$subheader_id = 'subheader-no-contact-form';
}
?>
<section id="<?php echo $subheader_id; ?>" class="cf">
	<div class="subheader-wrap cf">
		<?php
		if ( is_front_page() ) {
			echo '<div class="subheader-background">';
			echo '</div>';
			echo '<div class="subheader-car">';
			echo '</div>';
		}
		?>
		<nav>
			<?php

			if ( ( get_theme_mod( 'ti_header_youtube' ) || get_theme_mod( 'ti_header_facebook' ) || get_theme_mod( 'ti_header_googleplus' ) || get_theme_mod( 'ti_header_twitter' ) ) == NULL ) { ?>

				<style>
					.navigation {
						width: 100% !important;
					}
				</style>

			<?php } ?>
			<div class="openresponsivemenu">
				<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="32" height="32" viewBox="0 0 32 32">
					<path d="M0 12h22v4h-22v-4zM0 6h22v4h-22v-4zM0 18h22v4h-22v-4zM0 24h22v4h-22v-4zM24 18l4 6 4-6h-8zM32 16l-4-6-4 6h8z" fill="#fff" />
				</svg>
			</div><!--/.openresponsivemenu-->
			<?php
			wp_nav_menu( array(
					'theme_location'	=> 'header-menu',
					'menu_class'		=> 'navigation cf',
					'container'			=> '',
					'container_class'	=> ''
				)
			);

			if ( get_theme_mod( 'ti_header_youtube' ) || get_theme_mod( 'ti_header_facebook' ) || get_theme_mod( 'ti_header_googleplus' ) || get_theme_mod( 'ti_header_twitter' ) ) { ?>

				<div class="socials-box">
					<?php
					if ( get_theme_mod( 'ti_header_youtube' ) ) {
						echo '<a href="'. get_theme_mod( 'ti_header_youtube' ) .'" title="YouTube" class="youtube-icon"></a>';
					}

					if ( get_theme_mod( 'ti_header_facebook' ) ) {
						echo '<a href="'. get_theme_mod( 'ti_header_facebook' ) .'" title="Facebook" class="facebook-icon"></a>';
					}

					if ( get_theme_mod( 'ti_header_googleplus' ) ) {
						echo '<a href="'. get_theme_mod( 'ti_header_googleplus' ) .'" title="Google+" class="googleplus-icon"></a>';
					}

					if ( get_theme_mod( 'ti_header_twitter' ) ) {
						echo '<a href="'. get_theme_mod( 'ti_header_twitter' ) .'" title="Twitter" class="twitter-icon"></a>';
					}
					?>
				</div><!--/.socials-box-->

			<?php }
			?>
		</nav>
		<?php
		if ( is_front_page() ) { ?>

			<div class="subheader-widget">
				<?php
				if ( get_theme_mod( 'ti_header_contactform7_shortcode' ) ) {

					if ( get_theme_mod( 'ti_header_contactform7_title' ) ) {
						echo '<h3>'. get_theme_mod( 'ti_header_contactform7_title' ) .'</h3>';
					}

					echo do_shortcode( get_theme_mod( 'ti_header_contactform7_shortcode' ) );

				}
				?>
			</div><!--/.subheader-widget-->

		<?php }
		?>
	</div><!--/.wrap-->
</section><!--/#subheader-->