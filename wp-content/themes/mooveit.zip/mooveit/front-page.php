<?php
/**
 * 	The template for displaying Front Page.
 *
 * 	@package ThemeIsle
 */
get_header();

get_template_part( 'includes/subheader' );

if ( !get_theme_mod( 'ti_header_contactform7_shortcode' ) ) {
	$h3_class = 'class="h3-no-contact-form"';
} else {
	$h3_class = '';
}
?>
<section id="features-two">
	<div class="wrap">
		<h3 <?php echo $h3_class; ?>>
			<?php
			if ( get_theme_mod( 'ti_frontpage_subheader_title' ) != false ) {
				echo get_theme_mod( 'ti_frontpage_subheader_title' );
			} else {
				echo _e( 'Why Choose Us?', 'ti' );
			}
			?>
		</h3>
		<div class="features-two-container">
			<div class="features-box">
				<div class="features-box-icon">
				</div><!--/.features-box-icon-->
				<?php
				if ( get_theme_mod( 'ti_frontpage_firstlybox_title' ) ) {
					echo '<h4>'. get_theme_mod( 'ti_frontpage_firstlybox_title' ) .'</h4>';
				} else {
					echo '<h4>'. __( 'Title one', 'ti' ) .'</h4>';
				}

				if ( get_theme_mod( 'ti_frontpage_firstlybox_content' ) ) {
					echo '<div class="features-box-entry">'. get_theme_mod( 'ti_frontpage_firstlybox_content' ) .'</div>';
				} else {
					echo '<div class="features-box-entry">'. __( 'Go to Appearance - Customize, to add content.', 'ti' ) .'</div>';
				}
				?>
			</div><!--/.features-box-->
			<div class="features-box">
				<div class="features-box-icon">
				</div><!--/.features-box-icon-->
				<?php
				if ( get_theme_mod( 'ti_frontpage_secondlybox_title' ) ) {
					echo '<h4>'. get_theme_mod( 'ti_frontpage_secondlybox_title' ) .'</h4>';
				} else {
					echo '<h4>'. __( 'Title two', 'ti' ) .'</h4>';
				}

				if ( get_theme_mod( 'ti_frontpage_secondlybox_content' ) ) {
					echo '<div class="features-box-entry">'. get_theme_mod( 'ti_frontpage_secondlybox_content' ) .'</div>';
				} else {
					echo '<div class="features-box-entry">'. __( 'Go to Appearance - Customize, to add content.', 'ti' ) .'</div>';
				}
				?>
			</div><!--/.features-box-->
			<div class="features-box">
				<div class="features-box-icon">
				</div><!--/.features-box-icon-->
				<?php
				if ( get_theme_mod( 'ti_frontpage_thirdlybox_title' ) ) {
					echo '<h4>'. get_theme_mod( 'ti_frontpage_thirdlybox_title' ) .'</h4>';
				} else {
					echo '<h4>'. __( 'Title two', 'ti' ) .'</h4>';
				}

				if ( get_theme_mod( 'ti_frontpage_thirdlybox_content' ) ) {
					echo '<div class="features-box-entry">'. get_theme_mod( 'ti_frontpage_thirdlybox_content' ) .'</div>';
				} else {
					echo '<div class="features-box-entry">'. __( 'Go to Appearance - Customize, to add content.', 'ti' ) .'</div>';
				}
				?>
			</div><!--/.features-box-->
		</div><!--/.features-two-container-->
	</div><!--/.wrap-->
</section><!--/#features-two-->
<div class="wrap">
	<article id="content-article" class="cf">
		<div class="content-article-image">
			<?php
			if ( get_theme_mod( 'ti_frontpage_article_image' ) ) {
				echo '<img src="'. get_theme_mod( 'ti_frontpage_article_image' ) .'" alt="'. get_theme_mod( 'ti_frontpage_article_title' ) .'" title="'. get_theme_mod( 'ti_frontpage_article_title' ) .'" />';
			} else {
				echo '<img src="'. get_template_directory_uri() .'/images/index-article-image.png" alt="'. get_theme_mod( 'ti_frontpage_article_title' ) .'" title="'. get_theme_mod( 'ti_frontpage_article_title' ) .'" />';
			}
			?>
		</div><!--/.content-article-image-->
		<h2>
			<?php
			if ( get_theme_mod( 'ti_frontpage_article_title' ) != false ) {
				echo get_theme_mod( 'ti_frontpage_article_title' );
			} else {
				echo _e( 'About our services', 'ti' );
			}
			?>
		</h2>
		<p>
			<?php
			if ( get_theme_mod( 'ti_frontpage_article_content' ) != false ) {
				echo get_theme_mod( 'ti_frontpage_article_content' );
			} else {
				echo _e( 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt.', 'ti' );
			}
			?>
		</p>
	</article><!--/#content-article-->
</div><!--/.wrap-->
<div class="wrap">
	<section class="content">
		<div class="title-border">
			<h3>
				<?php
				if ( get_theme_mod( 'ti_frontpage_testimonials_title' ) != false ) {
					echo get_theme_mod( 'ti_frontpage_testimonials_title' );
				} else {
					echo _e( 'Testimonials', 'ti' );
				}
				?>
			</h3>
		</div><!--/.title-border-->
		<div class="list_carousel responsive cf">
			<div id="foo4">

				<?php
					$numberofposts = get_theme_mod( 'ti_frontpage_testimonials_numberofposts' );
					$offset = get_theme_mod( 'ti_frontpage_testimonials_offset' );
					$args = array (
					'post_type'              => 'testimonials',
					'posts_per_page'         => $numberofposts,
					'offset'			   	 => $offset,
					'ignore_sticky_posts'    => true,
				);

				$testimonials = new WP_Query( $args );

				if ( $testimonials->have_posts() ) {
					while ( $testimonials->have_posts() ) {
						$testimonials->the_post();

						$testimonials_position = get_post_meta($post->ID, 'ti_testimonials_position', true);
						$testimonials_company_name = get_post_meta($post->ID, 'ti_testimonials_company_name', true);
						$testimonials_company_url = get_post_meta($post->ID, 'ti_testimonials_company_url', true); ?>

						<div class="testimonial-box">
							<?php the_excerpt(); ?>
							<div class="testimonials-meta">
								<h6>
									<span>
										<?php
										if ( ( $testimonials_position && $testimonials_company_name ) == NULL ) {
											$line = '';
										} else {
											$line = ', ';
										}
										the_title(); ?>
										<?php echo $line; ?>
									</span>

									<?php
									if ( ( $testimonials_position && $testimonials_company_name ) == NULL ) {
										$at = '';
									} else {
										$at = ' at ';
									}

									echo $testimonials_position;
									echo $at;

									if ( $testimonials_company_url != false ) {
										echo '<a href="'. $testimonials_company_url .'" title="'. $testimonials_company_name .'">'. $testimonials_company_name .'</a>';
									} else {
										echo $testimonials_company_name;
									}
									?>

								</h6>
							</div><!---/.testimonials-meta-->
						</div><!--/.testimonial-box-->

					<?php }
				} else {
					echo '<p>No posts found.</p>';
				}

				wp_reset_postdata();
				?>

			</div><!--/#foo4-->
			<a href="" class="testimonials-navigation-prev">
				<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="30" height="30" viewBox="0 0 32 32">
					<path d="M16 0c8.837 0 16 7.163 16 16s-7.163 16-16 16-16-7.163-16-16 7.163-16 16-16zM16 29c7.18 0 13-5.82 13-13s-5.82-13-13-13-13 5.82-13 13 5.82 13 13 13zM6.586 14.586l8-8c0.781-0.781 2.047-0.781 2.828 0s0.781 2.047 0 2.828l-4.586 4.586h11.172c1.105 0 2 0.895 2 2s-0.895 2-2 2h-11.172l4.586 4.586c0.781 0.781 0.781 2.047 0 2.829-0.391 0.39-0.902 0.586-1.414 0.586s-1.024-0.195-1.414-0.586l-8-8c-0.781-0.781-0.781-2.047 0-2.828z"></path>
				</svg>
			</a><!--/a .testimonials-navigation-prev-->
			<a href="" class="testimonials-navigation-next">
				<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="30" height="30" viewBox="0 0 32 32">
					<path d="M16 0c-8.837 0-16 7.163-16 16s7.163 16 16 16 16-7.163 16-16-7.163-16-16-16zM16 29c-7.18 0-13-5.82-13-13s5.82-13 13-13 13 5.82 13 13-5.82 13-13 13zM25.414 14.586l-8-8c-0.781-0.781-2.047-0.781-2.828 0s-0.781 2.047 0 2.828l4.586 4.586h-11.172c-1.105 0-2 0.895-2 2s0.895 2 2 2h11.172l-4.586 4.586c-0.781 0.781-0.781 2.047 0 2.829 0.391 0.39 0.902 0.586 1.414 0.586s1.024-0.195 1.414-0.586l8-8c0.781-0.781 0.781-2.047 0-2.828z"></path>
				</svg>
			</a><!--/a .testimonials-navigation-next-->
			<div class="clearfix"></div>
		</div><!--/.list_carousel responsive-->
	</section><!--/.content-->
	<section class="content">
		<div class="title-border">
			<h3>
				<?php
				if ( get_theme_mod( 'ti_frontpage_ourclients_title' ) != false ) {
					echo get_theme_mod( 'ti_frontpage_ourclients_title' );
				} else {
					echo _e( 'Our Clients', 'ti' );
				}
				?>
			</h3>
		</div><!--/.title-border-->
		<div class="our-clients">
			<?php
			if ( get_theme_mod( 'ti_frontpage_ourclients_logo1' ) != false ) { ?>

				<?php
				if ( get_theme_mod( 'ti_frontpage_ourclients_logo1' ) != false ) { ?>
					<img src="<?php echo get_theme_mod( 'ti_frontpage_ourclients_logo1' ); ?>" alt="Sponsor 1" />
				<?php }
				?>

				<?php
				if ( get_theme_mod( 'ti_frontpage_ourclients_logo2' ) != false ) { ?>
					<img src="<?php echo get_theme_mod( 'ti_frontpage_ourclients_logo2' ); ?>" alt="Client 2" />
				<?php }
				?>

				<?php
				if ( get_theme_mod( 'ti_frontpage_ourclients_logo3' ) != false ) { ?>
					<img src="<?php echo get_theme_mod( 'ti_frontpage_ourclients_logo3' ); ?>" alt="Client 3" />
				<?php }
				?>

				<?php
				if ( get_theme_mod( 'ti_frontpage_ourclients_logo4' ) != false ) { ?>
					<img src="<?php echo get_theme_mod( 'ti_frontpage_ourclients_logo4' ); ?>" alt="Client 4" />
				<?php }
				?>

				<?php
				if ( get_theme_mod( 'ti_frontpage_ourclients_logo5' ) != false ) { ?>
					<img src="<?php echo get_theme_mod( 'ti_frontpage_ourclients_logo5' ); ?>" alt="Client 5" />
				<?php }
				?>

				<?php
				if ( get_theme_mod( 'ti_frontpage_ourclients_logo6' ) != false ) { ?>
					<img src="<?php echo get_theme_mod( 'ti_frontpage_ourclients_logo6' ); ?>" alt="Client 6" />
				<?php }
				?>

			<?php } else { ?>

				<?php
				if ( get_theme_mod( 'ti_frontpage_ourclients_logo1' ) != false ) { ?>
					<img src="<?php echo get_theme_mod( 'ti_frontpage_ourclients_logo1' ); ?>" alt="Sponsor 1" />
				<?php } else { ?>
					<img src="<?php echo get_template_directory_uri(); ?>/images/clients-logo1.png" alt="Sponsor 1" />
				<?php }
				?>

				<?php
				if ( get_theme_mod( 'ti_frontpage_ourclients_logo2' ) != false ) { ?>
					<img src="<?php echo get_theme_mod( 'ti_frontpage_ourclients_logo2' ); ?>" alt="Sponsor 2" />
				<?php } else { ?>
					<img src="<?php echo get_template_directory_uri(); ?>/images/clients-logo2.png" alt="Sponsor 2" />
				<?php }
				?>

				<?php
				if ( get_theme_mod( 'ti_frontpage_ourclients_logo3' ) != false ) { ?>
					<img src="<?php echo get_theme_mod( 'ti_frontpage_ourclients_logo3' ); ?>" alt="Sponsor 3" />
				<?php } else { ?>
					<img src="<?php echo get_template_directory_uri(); ?>/images/clients-logo3.png" alt="Sponsor 3" />
				<?php }
				?>

				<?php
				if ( get_theme_mod( 'ti_frontpage_ourclients_logo4' ) != false ) { ?>
					<img src="<?php echo get_theme_mod( 'ti_frontpage_ourclients_logo4' ); ?>" alt="Sponsor 4" />
				<?php } else { ?>
					<img src="<?php echo get_template_directory_uri(); ?>/images/clients-logo4.png" alt="Sponsor 4" />
				<?php }
				?>

				<?php
				if ( get_theme_mod( 'ti_frontpage_ourclients_logo5' ) != false ) { ?>
					<img src="<?php echo get_theme_mod( 'ti_frontpage_ourclients_logo5' ); ?>" alt="Sponsor 5" />
				<?php } else { ?>
					<img src="<?php echo get_template_directory_uri(); ?>/images/clients-logo5.png" alt="Sponsor 5" />
				<?php }
				?>

				<?php
				if ( get_theme_mod( 'ti_frontpage_ourclients_logo6' ) != false ) { ?>
					<img src="<?php echo get_theme_mod( 'ti_frontpage_ourclients_logo6' ); ?>" alt="Sponsor 6" />
				<?php } else { ?>
					<img src="<?php echo get_template_directory_uri(); ?>/images/clients-logo6.png" alt="Sponsor 6" />
				<?php }
				?>

			<?php }
			?>
		</div><!--/.our-clients-->
	</section><!--/.content-->
</div><!--/.wrap-->
<?php get_footer(); ?>