<?php
/**
 * 	The template for displaying Header.
 *
 * 	@package ThemeIsle
 */
?>
<!DOCTYPE html>
<html>
	<head <?php language_attributes(); ?>>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
		<title><?php wp_title('|', true, 'right'); bloginfo('name'); ?></title>
		<!--[if lt IE 9]>
			<script src="js/html5shiv.js"></script>
		<![endif]-->
		<?php wp_head(); ?>
	</head>
	<body <?php body_class(); ?>>
		<header class="cf">
			<div class="wrap cf">
				<a href="<?php echo home_url(); ?>" title="<?php wp_title('|', true, 'right'); bloginfo('name'); ?>" class="logo-box">
					<?php
					if ( get_theme_mod( 'ti_header_logo' ) != false ) { ?>
						<img src="<?php echo get_theme_mod( 'ti_header_logo' ); ?>" alt="<?php wp_title('|', true, 'right'); bloginfo('name'); ?>" title="<?php wp_title('|', true, 'right'); bloginfo('name'); ?>" />
					<?php } else { ?>
						<img src="<?php echo get_template_directory_uri(); ?>/images/logo.png" alt="<?php wp_title('|', true, 'right'); bloginfo('name'); ?>" title="<?php wp_title('|', true, 'right'); bloginfo('name'); ?>" />
					<?php }
					?>
				</a><!--/.logo-box-->
				<?php
				if ( get_theme_mod( 'ti_header_subtitle' ) ) { ?>

					<div class="call-us-box">
						<?php
						if ( get_theme_mod( 'ti_header_title' ) ) {
	    					echo '<span>'. get_theme_mod( 'ti_header_title' ) .'</span>';
	    				}

	    				if ( get_theme_mod( 'ti_header_subtitle' ) ) {
	    					echo '<a href="tel:'. get_theme_mod( 'ti_header_subtitle' ) .'" title="Tel: '. get_theme_mod( 'ti_header_subtitle' ) .'">'. get_theme_mod( 'ti_header_subtitle' ) .'</a>';
	    				}
						?>
					</div><!--/.call-us-box-->

				<?php }
				?>
			</div><!--/.wrap .cf-->
		</header><!--/header-->