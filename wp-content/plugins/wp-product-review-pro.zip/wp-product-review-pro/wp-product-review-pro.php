<?php   
#     /* 
#     Plugin Name: WP Product Review Pro Add-on
#     Plugin URI: https://themeisle.com/plugins/wp-product-review-pro-add-on/
#     Description: Easy preload other posts features with the pro version. Turn your basic posts into in-depth reviews with ratings, pros and cons and affiliate links .
#     Author: Themeisle
#     Version: 1.0.4
#     Author URI: https://themeisle.com
#	  Text Domain: cwppos
#	  Domain Path: /languages
#     */  

// Config Constants
define("WPPRPROPATH", realpath(dirname(__FILE__) ));
define("WPPRPROCSSFILE", plugins_url('css/style.css',__FILE__ ));
define("WPPRPROPLUGINBASENAME", plugin_basename(__FILE__));

// Require core.
require_once(WPPRPROPATH."/inc/core.php");

function cwp_get_rating( $atts ) {
	$a = shortcode_atts( array(
	    'visual' => 'no',
	    'post_id' =>''
	), $atts );
	
	if ($a['visual']=="no"&&$a['post_id']!="") {
	    $r = cwppos_calc_overall_rating($a['post_id']);
	    return round($r['overall']/10);
	}

	if ($a['visual']=="yes"&&$a['post_id']!="") {
	    $r = cwppos_calc_overall_rating($a['post_id']);
	    return '<div class="cwp-review-chart cwp-chart-embed"><div class="cwp-review-percentage" data-percent="'.$r['overall'].'"><span  class="cwp-review-rating">'.$r['overall'].'</span></div></div>';
	}

	if ($a['visual']=="full")
		return cwppos_show_review($a['post_id']);


	}
add_shortcode( 'P_REVIEW', 'cwp_get_rating');


 require 'inc/cwp-plugin-update.php'; 

$MyUpdateChecker = PucFactory::buildUpdateChecker('http://api.themeisle.com/get_metadata/wp-product-review-pro', __FILE__, 'wp-product-review-pro' );